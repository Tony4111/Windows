﻿ using System;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using ClassDspreadSDK;
using System.Collections.Generic;
using System.Threading;
using System.Security.Cryptography;
using System.Text;
using System.Xml;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Math;
using System.Linq;
using Org.BouncyCastle.Asn1.X509;
using Org.BouncyCastle.X509;
using Org.BouncyCastle.Asn1.Pkcs;
using Org.BouncyCastle.Pkcs;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.Crypto;

namespace WindowsDspreadDemo
{

    public partial class FormDemo : Form
    {
        //usb serial port
        private const int WM_DEVICECHANGE = 0x2190;
        private const int DBT_DEVICEARRIVAL = 0x8000;
        private const int DBT_DEVICEREMOVECOMPLETE = 0x8004;
        private static SerialPort g_USB_SerialPort;
        private static String PublicHexString = "";

        private const int EMV_PARAMETERS_BLOCK_SIZE = 512;

        private void DeviceArrival()
        {
            string[] ports;

            Thread.Sleep(200);

            ports = SerialPort.GetPortNames();

            comboBox1.Items.Clear();

            comboBox1.Text = "";

            string tempStr;

            foreach (string portnumber in ports)
            {
                tempStr = portnumber;
                while (true)
                {
                    if (Util.IsNumeric(tempStr.Substring(3, tempStr.Length - 3)))
                    {
                        break;
                    }
                    else
                    {
                        tempStr = tempStr.Substring(0, tempStr.Length - 1);
                    }
                    if (tempStr.Length == 3)
                    {
                        break;
                    }
                }
                comboBox1.Items.Add(tempStr);
            }

            try
            {
                g_USB_SerialPort.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            button1.Text = "OPEN";
            USB_ConfigurableStatus(true);

            if (comboBox1.Items.Count != 0)
            {
                comboBox1.SelectedIndex = 0;
            }
            else
            {

            }
            
        }

        private void DeviceRemoveComplete()
        {
            string[] ports;

            Thread.Sleep(200);

            ports = SerialPort.GetPortNames();

            comboBox1.Items.Clear();

            comboBox1.Text = "";

            string tempStr;

            foreach (string portnumber in ports)
            {
                tempStr = portnumber;
                while (true)
                {
                    if (Util.IsNumeric(tempStr.Substring(3, tempStr.Length - 3)))
                    {
                        break;
                    }
                    else
                    {
                        tempStr = tempStr.Substring(0, tempStr.Length - 1);
                    }
                    if (tempStr.Length == 3)
                    {
                        break;
                    }
                }
                comboBox1.Items.Add(tempStr);
            }

            try
            {
                g_USB_SerialPort.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            button1.Text = "OPEN";
            USB_ConfigurableStatus(true);

            comboBox1.SelectedIndex = 0;
        }

        private byte[] GetKeyByteArray(string strKey)
        {
            ASCIIEncoding Asc = new ASCIIEncoding();

            int tmpStrLen = strKey.Length;
            byte[] tmpByte = new byte[tmpStrLen - 1];

            tmpByte = Asc.GetBytes(strKey);

            return tmpByte;

        }

        private static string ToHexString(byte[] bytes) // 0xae00cf => "AE00CF "
        {
            string hexString = string.Empty;
            if (bytes != null)
            {
                StringBuilder strB = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    strB.Append(bytes[i].ToString("X2"));
                }
                hexString = strB.ToString();
            }
            return hexString;
        }

        private void USB_BaudList()
        {
            comboBox2.Items.Clear();

            comboBox2.Text = "";

            comboBox2.Items.Add("110");
            comboBox2.Items.Add("300");
            comboBox2.Items.Add("600");
            comboBox2.Items.Add("1200");
            comboBox2.Items.Add("2400");
            comboBox2.Items.Add("4800");
            comboBox2.Items.Add("9600");
            comboBox2.Items.Add("14400");
            comboBox2.Items.Add("19200");
            comboBox2.Items.Add("28800");
            comboBox2.Items.Add("38400");
            comboBox2.Items.Add("56000");
            comboBox2.Items.Add("115200");
            comboBox2.Items.Add("128000");
            comboBox2.Items.Add("230400");
            comboBox2.Items.Add("256000");
            comboBox2.Items.Add("460800");
            comboBox2.Items.Add("921600");

            comboBox2.SelectedIndex = 12;
        }

        private void USB_DataBitList()
        {
            comboBox3.Items.Clear();

            comboBox3.Text = "";

            comboBox3.Items.Add("5");
            comboBox3.Items.Add("6");
            comboBox3.Items.Add("7");
            comboBox3.Items.Add("8");

            comboBox3.SelectedIndex = 3;
        }

        private void USB_StopBitList()
        {
            comboBox4.Items.Clear();

            comboBox4.Text = "";

            comboBox4.Items.Add("1");
            comboBox4.Items.Add("1.5");
            comboBox4.Items.Add("2");

            comboBox4.SelectedIndex = 0;
        }

        private void USB_CheckBitList()
        {
            comboBox5.Items.Clear();

            comboBox5.Text = "";

            comboBox5.Items.Add("NONE");
            comboBox5.Items.Add("ODD");
            comboBox5.Items.Add("EVEN");

            comboBox5.SelectedIndex = 0;
        }

        private void USB_CtrlList()
        {
            comboBox6.Items.Clear();

            comboBox6.Text = "";

            comboBox6.Items.Add("NONE");
            comboBox6.Items.Add("XON/XOFF");
            comboBox6.Items.Add("HARDWARE");

            comboBox6.SelectedIndex = 0;
        }

        private void TradeModeList()
        {
            comboBox7.Items.Clear();

            comboBox7.Text = "";

            comboBox7.Items.Add("ICC");
            comboBox7.Items.Add("MCR");
            comboBox7.Items.Add("ICC/MCR/NFC");
            comboBox7.Items.Add("ICC/MCR/NFC/NotDown");
            comboBox7.Items.Add("ICC/MCR");
            comboBox7.Items.Add("ICC/MCR/NotDown");
            comboBox7.Items.Add("NFC");
            comboBox7.Items.Add("ICC/MCR/NFC/NotUp");
            comboBox7.Items.Add("ICC/MCR/NFC/NotUp/NotDown");

            comboBox7.SelectedIndex = 2;
        }

        private void CurrencySymbolList()
        {
            comboBox8.Items.Clear();

            comboBox8.Text = "";

            comboBox8.Items.Add("DEFAULT");
            comboBox8.Items.Add("$");
            comboBox8.Items.Add("￥");
            comboBox8.Items.Add("￡");
            comboBox8.Items.Add("INR");

            comboBox8.SelectedIndex = 0;
        }

        private void ViposModeList()
        {
            comboBox9.Items.Clear();

            comboBox9.Text = "";

            comboBox9.Items.Add("00");
            comboBox9.Items.Add("01");
            comboBox9.Items.Add("02");
            comboBox9.Items.Add("03");

            comboBox9.SelectedIndex = 0;
        }

        private void KeyIndexList()
        {
            comboBox10.Items.Clear();

            comboBox10.Text = "";

            comboBox10.Items.Add("00");
            comboBox10.Items.Add("01");
            comboBox10.Items.Add("02");
            comboBox10.Items.Add("03");
            comboBox10.Items.Add("04");
            comboBox10.Items.Add("05");
            comboBox10.Items.Add("06");
            comboBox10.Items.Add("07");
            comboBox10.Items.Add("08");
            comboBox10.Items.Add("09");
            comboBox10.Items.Add("0A");

            comboBox10.SelectedIndex = 0;

            comboBox11.Items.Clear();

            comboBox11.Text = "";

            comboBox11.Items.Add("00");
            comboBox11.Items.Add("01");
            comboBox11.Items.Add("02");
            comboBox11.Items.Add("03");
            comboBox11.Items.Add("04");
            comboBox11.Items.Add("05");
            comboBox11.Items.Add("06");
            comboBox11.Items.Add("07");
            comboBox11.Items.Add("08");
            comboBox11.Items.Add("09");
            comboBox11.Items.Add("0A");

            comboBox11.SelectedIndex = 0;
        }

        private void TransTypeList()
        {

        }

        private void CurrencyCodeList()
        {
            comboBox12.Items.Clear();

            comboBox12.Text = "";

            comboBox12.Items.Add("0156");
            comboBox12.Items.Add("0356");
            comboBox12.Items.Add("0484");
            comboBox12.Items.Add("0840");

            comboBox12.SelectedIndex = 0;
        }

        private void EncryptionModeList()
        {
            comboBox13.Items.Clear();

            comboBox13.Text = "";

            comboBox13.Items.Add("0000");
            comboBox13.Items.Add("0007");
            comboBox13.Items.Add("0018");

            comboBox13.SelectedIndex = 0;
        }

        private void TransactionTypeInit()
        {
            comboBox28.Items.Clear();

            comboBox28.Text = "";

            comboBox28.Items.Add("GOODS");
            comboBox28.Items.Add("SERVICE");
            comboBox28.Items.Add("CASH");
            comboBox28.Items.Add("CASHBACK");
            comboBox28.Items.Add("INQUIRE");
            comboBox28.Items.Add("TRANSFER");
            comboBox28.Items.Add("ADMIN");
            comboBox28.Items.Add("CASHDEPOSIT");
            comboBox28.Items.Add("PAYMENT");
            comboBox28.Items.Add("FIXED");
            comboBox28.Items.Add("SALE");
            comboBox28.Items.Add("PREAUTH");
            comboBox28.Items.Add("BALANCE");
            comboBox28.Items.Add("FIXED");
            comboBox28.Items.Add("FIXED");
            comboBox28.Items.Add("ECQ DESIGNATED LOAD");
            comboBox28.Items.Add("ECQ UNDESIGNATED LOAD");
            comboBox28.Items.Add("ECQ CASH LOAD");
            comboBox28.Items.Add("ECQ CASH LOAD VOID");
            comboBox28.Items.Add("REFUND");
            comboBox28.Items.Add("MODIFY PIN");

            comboBox28.SelectedIndex = 0;
        }

        private void KeyInjection10F0_Init()
        {
            textBox22.Enabled = false;
            textBox22.Text = "0000000000000000";
            textBox26.Enabled = false;
            textBox26.Text = "0000000000000000";
            textBox28.Enabled = false;
            textBox28.Text = "0000000000000000";

            label42.Text = "";
        }

        private void KeyInjection10E4_Init()
        {
            comboBox33.Items.Clear();

            comboBox33.Text = "";

            comboBox33.Items.Add("00");
            comboBox33.Items.Add("01");
            comboBox33.Items.Add("02");
            comboBox33.Items.Add("03");
            comboBox33.Items.Add("04");
            comboBox33.Items.Add("05");
            comboBox33.Items.Add("06");
            comboBox33.Items.Add("07");
            comboBox33.Items.Add("08");

        }
        private void KeyInjection10E2_Init()
        {
            comboBox34.Items.Clear();

            comboBox34.Text = "";

            comboBox34.Items.Add("00");
            comboBox34.Items.Add("01");
            comboBox34.Items.Add("02");
            comboBox34.Items.Add("03");
            comboBox34.Items.Add("04");
            comboBox34.Items.Add("05");
            comboBox34.Items.Add("06");
            comboBox34.Items.Add("07");
            comboBox34.Items.Add("08");

        }
        private void KeyInjection10F2_Init()
        {
            comboBox14.Items.Clear();

            comboBox14.Text = "";

            comboBox14.Items.Add("00");
            comboBox14.Items.Add("01");
            comboBox14.Items.Add("02");
            comboBox14.Items.Add("03");
            comboBox14.Items.Add("04");
            comboBox14.Items.Add("05");
            comboBox14.Items.Add("06");
            comboBox14.Items.Add("07");
            comboBox14.Items.Add("08");
            comboBox14.Items.Add("09");
            comboBox14.Items.Add("0A");

            comboBox14.SelectedIndex = 0;

            comboBox15.Items.Clear();

            comboBox15.Text = "";

            comboBox15.Items.Add("03");
            comboBox15.Items.Add("08");

            comboBox15.SelectedIndex = 0;

            if (comboBox15.Text == "03")
            {
                textBox33.MaxLength = 6;
            }
            else
            {
                textBox33.MaxLength = 16;
            }

            if (comboBox15.Text == "03")
            {
                textBox34.MaxLength = 6;
            }
            else
            {
                textBox34.MaxLength = 16;
            }

            if (comboBox15.Text == "03")
            {
                textBox37.MaxLength = 6;
            }
            else
            {
                textBox37.MaxLength = 16;
            }

            if (comboBox15.Text == "03")
            {
                textBox33.Text = "000000";
                textBox34.Text = "000000";
                textBox37.Text = "000000";
            }
            else
            {
                textBox33.Text = "0000000000000000";
                textBox34.Text = "0000000000000000";
                textBox37.Text = "0000000000000000";
            }

            label44.Text = "";

        }

        private void USB_ConfigurableStatus(bool Status)
        {
            comboBox1.Enabled = Status;
            comboBox2.Enabled = Status;
            comboBox3.Enabled = Status;
            comboBox4.Enabled = Status;
            comboBox5.Enabled = Status;
            comboBox6.Enabled = Status;
        }

        private void APDU_PackInit()
        {
            textBox39.Text = "00";
            textBox42.Text = "A4";
            textBox45.Text = "04";
            textBox46.Text = "00";

            textBox43.Text = "0E";
            textBox44.Text = "315041592E5359532E4444463031";
            textBox47.Text = "00";

            textBox40.Text = textBox39.Text + textBox42.Text + textBox45.Text + textBox46.Text + textBox43.Text + textBox44.Text + textBox47.Text;

            button15.Enabled = true;
            button18.Enabled = false;
            button19.Enabled = false;

            comboBox16.Items.Clear();

            comboBox16.Text = "";

            comboBox16.Items.Add("ENCRYPT TEXT");
            comboBox16.Items.Add("PLAIN TEXT");

            comboBox16.SelectedIndex = 0;

            comboBox17.Items.Clear();

            comboBox17.Text = "";

            comboBox17.Items.Add("CONTACT CARD");
            comboBox17.Items.Add("CONTACTLESS CARD");

            comboBox17.SelectedIndex = 0;
            
        }

        private void InputPinInit()
        {
            comboBox18.Items.Clear();

            comboBox18.Text = "";

            comboBox18.Items.Add("ENCRYPT FORMAT PIN");//00
            comboBox18.Items.Add("XOR WITH PAN");//01
            comboBox18.Items.Add("ANSI x9.8, NOT PAN");//02
            comboBox18.Items.Add("FORMAT PIN ISO-1");//03
            comboBox18.Items.Add("PLAIN FORMAT PIN");//08
            comboBox18.Items.Add("PLAIN PIN");//0A

            comboBox18.SelectedIndex = 0;

            comboBox19.Items.Clear();

            comboBox19.Text = "";

            comboBox19.Items.Add("00");
            comboBox19.Items.Add("01");
            comboBox19.Items.Add("02");
            comboBox19.Items.Add("03");
            comboBox19.Items.Add("04");
            comboBox19.Items.Add("05");
            comboBox19.Items.Add("06");
            comboBox19.Items.Add("07");
            comboBox19.Items.Add("08");
            comboBox19.Items.Add("09");
            comboBox19.Items.Add("0A");

            comboBox19.SelectedIndex = 0;

            comboBox20.Items.Clear();

            comboBox20.Text = "";

            comboBox20.Items.Add("00");
            comboBox20.Items.Add("04");
            comboBox20.Items.Add("06");
            comboBox20.Items.Add("0C");

            comboBox20.SelectedIndex = 3;

            textBox49.Text = "PLEASE INPUT PIN";
        }

        private void TangemCardInit()
        {
            button25.Enabled = true;
            groupBox10.Enabled = false;
            button23.Enabled = false;
            textBox53.Text = "000000";
        }

        private void EMV_UpdateInit()
        {
            comboBox21.Items.Clear();

            comboBox21.Text = "";

            comboBox21.Items.Add("5F2A");
            comboBox21.Items.Add("5F36");
            comboBox21.Items.Add("9F01");
            comboBox21.Items.Add("9F06");
            comboBox21.Items.Add("9F08");
            comboBox21.Items.Add("9F09");
            comboBox21.Items.Add("9F15");
            comboBox21.Items.Add("9F16");
            comboBox21.Items.Add("9F1A");
            comboBox21.Items.Add("9F1B");
            comboBox21.Items.Add("9F1C");
            comboBox21.Items.Add("9F1E");
            comboBox21.Items.Add("9F33");
            comboBox21.Items.Add("9F35");
            comboBox21.Items.Add("9F39");
            comboBox21.Items.Add("9F3C");
            comboBox21.Items.Add("9F3D");
            comboBox21.Items.Add("9F40");
            comboBox21.Items.Add("9F4E");
            comboBox21.Items.Add("9F66");
            comboBox21.Items.Add("9F73");
            comboBox21.Items.Add("9F7B");
            comboBox21.Items.Add("DF01");
            comboBox21.Items.Add("DF02");
            comboBox21.Items.Add("DF03");
            comboBox21.Items.Add("DF04");
            comboBox21.Items.Add("DF05");
            comboBox21.Items.Add("DF06");
            comboBox21.Items.Add("DF07");
            comboBox21.Items.Add("DF11");
            comboBox21.Items.Add("DF12");
            comboBox21.Items.Add("DF13");
            comboBox21.Items.Add("DF14");
            comboBox21.Items.Add("DF15");
            comboBox21.Items.Add("DF16");
            comboBox21.Items.Add("DF17");
            comboBox21.Items.Add("DF18");
            comboBox21.Items.Add("DF19");
            comboBox21.Items.Add("DF20");
            comboBox21.Items.Add("DF21");
            comboBox21.Items.Add("DF60");
            comboBox21.Items.Add("DF70");
            comboBox21.Items.Add("DF71");
            comboBox21.Items.Add("DF72");
            comboBox21.Items.Add("DF73");
            comboBox21.Items.Add("DF74");
            comboBox21.Items.Add("DF75");
            comboBox21.Items.Add("DF76");
            comboBox21.Items.Add("DF77");
            comboBox21.Items.Add("DF78");
            comboBox21.Items.Add("DF79");
            comboBox21.Items.Add("DF7A");
            comboBox21.Items.Add("DF7B");
            comboBox21.Items.Add("DF7C");
            comboBox21.Items.Add("DF7D");
            comboBox21.Items.Add("DF7F");
            comboBox21.Items.Add("7F10");
            comboBox21.Items.Add("7F11");

            comboBox21.SelectedIndex = 0;
        }

        private void CaculateDES_Init()
        {
            textBox67.Text = "0000000000000000";

            textBox67.Enabled = false;

            comboBox22.Items.Clear();

            comboBox22.Text = "";

            comboBox22.Items.Add("ECB");
            comboBox22.Items.Add("CBC");

            comboBox22.SelectedIndex = 0;
        }

        private void DigitalEnvelopeInit()
        {
            comboBox23.Items.Clear();

            comboBox23.Text = "";

            comboBox23.Items.Add("RSA1024");
            comboBox23.Items.Add("RSA2048");

            comboBox23.SelectedIndex = 0;

            comboBox24.Items.Clear();

            comboBox24.Text = "";

            comboBox24.Items.Add("ConfigurationServer");
            comboBox24.Items.Add("ManagementServer");
            comboBox24.Items.Add("OtherServer(TDES Encryption)");

            comboBox24.SelectedIndex = 0;

            comboBox25.Items.Clear();

            comboBox25.Text = "";

            comboBox25.Items.Add("WorkKey");
            comboBox25.Items.Add("UserData");
            comboBox25.Items.Add("Firmware(Not Support)");

            comboBox25.SelectedIndex = 0;

            comboBox26.Items.Clear();

            comboBox26.Text = "";

            comboBox26.Items.Add("00");
            comboBox26.Items.Add("01");
            comboBox26.Items.Add("02");
            comboBox26.Items.Add("03");
            comboBox26.Items.Add("04");
            comboBox26.Items.Add("05");
            comboBox26.Items.Add("06");
            comboBox26.Items.Add("07");
            comboBox26.Items.Add("08");

            comboBox26.SelectedIndex = 0;

            //default server rsa key E = 010001;
            //textBox74.Text = "9B071918B88D31E9A920169C417A02BFBFAC4E98F69F94DE16FB5C3116FF9D9260C06FA8C488418C5821AE58A963761AA4F97A7A6CE0D1687861CF27C37FE80C3691229561E2F2EFA859BF61991DA70E3B13624B0F7E21F2CDCCB66F1D143B516321155F89E399A3E269904D6E506F31BD17F2D6B40005F1780C33C16BB4BE4B";
            //textBox59.Text = "0C0F2F4A970094C3625E96A3AD0C3AAE83D07984B89A8D500165A834415FBCF82802902D06ACBABC9A1674A37CF9B9B434E51B3BEEC04649E42367A3E6374AEB994C435CA9666B3FA5A869DD19498613FD4F3AD78BF69E071F68BCF46E25293E27D50D6F45F6762E943E73326C74F1791DA37C4FE10405D5B12517ADB265BEC1";
            textBox74.Text = "<RSAKeyValue><Modulus>rclak9u+8DgJEohDCrAFI79dM/4LYfZnSZwNL4ljO1gSd1G3kZESZ8Kl70clUj3Aex+IluOwJQPXs50NhohvjIp214ABrnsmUs0bf+xk6RQCnSZEP33OdWFR3eKnBHDvp/2794W6TNPxTh1X7G13AoSyAm1akpbSpcQhZNDZ3y0=</Modulus><Exponent>AQAB</Exponent><P>3U9TsmhIGvDfH1QcdkxPDtBdbFWJW/TNDjIc5K1HCN0rDNDHNIKKk/so8BcZJ0e3Que7ZCtmbOG5E3QDtOOeFw==</P><Q>yQcFbdMy3H8Ddz/Uk8DF4pbTxBLFZG5etF5BDz11rjLLvBmP/ph7cH4/+qihoW351sE80ztdgF6m7BDPfMXbWw==</Q><DP>FywNKWr90cRSuGcIK+LFjFmIzqUOItC4/7mDiPYTr/voXAkoMnlQpTnxCWKBwbkimSDGYDCjItdnl3/YO4JxtQ==</DP><DQ>nkSd3Jpzp6+D/gXOCkmyQjP3I56Xs/tFKoIufJ4poW0yg7QobwyD2sw6+NB8+EhKc+6NQcyyT5e1mZOel6B6kw==</DQ><InverseQ>zbbPLUrRkSx5WnrOvANuFN1mM2zYVqpMhiu4eLiZkm833BDW3IH5oCqe4+lY5IkoIXN3m7yvHFfgruBT7NXuTg==</InverseQ><D>ZDo9kArrOxXGPbbym2ZbAHvsYAEDRZNbjHuAq0rcPSyVMdWiPkThzY/YLYDlyGGu8hOErilQvHhT3dYVJ+LmGb9p8hiAcdNj06HPWpu1tbXj10brexNznfj+di8UzXUoysXApGsiSy96YWhlmDQB/lfx1b66BxWLM8up1N5vhi0=</D></RSAKeyValue>";
            textBox59.Text = "ADC95A93DBBEF038091288430AB00523BF5D33FE0B61F667499C0D2F89633B58127751B791911267C2A5EF4725523DC07B1F8896E3B02503D7B39D0D86886F8C8A76D78001AE7B2652CD1B7FEC64E914029D26443F7DCE756151DDE2A70470EFA7FDBBF785BA4CD3F14E1D57EC6D770284B2026D5A9296D2A5C42164D0D9DF2D";
            textBox86.Text = "010001";

        }

        private void SelfRepairInit()
        {
            //textBox60.Text = "00000000000000000000";
            textBox60.Text = "17100003000270300008";
            //textBox61.Text = "QPOS";
            //textBox75.Text = "92448B6311A4";
            textBox89.Text = "0018";
            textBox61.Text = "LPPCR30";
            textBox75.Text = "92448B6311A4";
            textBox80.Text = "0123456789ABCDEF0123456789ABCDEF";
            textBox77.Text = "4AC2E6293F57BBD893BB7B7A75CFB61008B6AE4503EE2E27C52A8BA96C691B5F78DF320F6D4B8263C741F0A490AD71C19D2CC057B726916F384D9157B7C36DBD381A087CC6A00E717C92CEC838B41A0EB070D936333A32FBAEE4C11B0893367C721447400055927931C86B9DE47CE138D39ED629086DE1DB14205862E9D29E01";
            textBox76.Text = "0080BDBB548087C81EEEB5044652F789289A28ABD89F1C1B24B2C9EFABD0F8E335B229DC43144BC43339836335FE1C1822179F639574F8AFD3CDF99FA8D0D2E7F20E290E2E9255CC221696CCC7126F24A626A81B653AB117107E94ED06BF49E9F3B9184EACE0077E63CAE818640EE02FBC1A7A11E4B58AE4E1FC7355C2F58CBD2A230003010001";
            textBox78.Text = "00808EBAC76E7EB424C192BD847DB155D7BBDD8F9587DAF34805B5DA9D4B29A55BE7AC21527EED70B9704DC8672F5C07105A983BEB1719FD4E0CBD2DAEEC613FF7359F55AFA582D9BAABED857368747447F35D50CE5174B16FECFE5157C2F78859EE59FB3D10B09D87CEE871249C2C3253614A7F87C8E8A70747E7226C26C17000790003010001";
            textBox79.Text = "0080DA03C82E43C34968EC94788F8B8CE54D7F2F721886AC65A42F17DD51D4B3C44BB409812B836ED13FD58AA6112A88EED5FB7A4BE186DEDC3F5F7AD503DBAE764DC65913E729704895FFE8132457496A22CD1DA61BD2AEB751D138A18A06ECEA760E0324C11975044C0FF8A5CEB7007181D0A8A66320CC99463675F2056D7A4ADD0003010001";
        }
       
        private void CustomInit()
        {
            comboBox27.Items.Clear();

            comboBox27.Text = "";

            comboBox27.Items.Add("Left");
            comboBox27.Items.Add("Center");
            comboBox27.Items.Add("Right");

            comboBox27.SelectedIndex = 0;
        }
        private void Logfile_conversionInit()
        {
            comboBox29.Items.Clear();

            comboBox29.Text = "";


            comboBox29.Items.Add("Lark2.0-MAG");
            comboBox29.Items.Add("Lark2.0-ICC");
            comboBox29.Items.Add("Lark2.0-NFC");
            comboBox29.Items.Add("Lark3.0-MAG");
            comboBox29.Items.Add("Lark3.0-ICC");
            comboBox29.Items.Add("Lark3.0-NFC");

            comboBox29.SelectedIndex = 0;
        }
        private void Log_key_selectInit()
        {
            comboBox30.Items.Clear();

            comboBox30.Text = "";

            comboBox30.Items.Add("decode_card_data");
            comboBox30.Items.Add("ICC Recv");
            comboBox30.Items.Add("rpdu");

            comboBox30.SelectedIndex = 0;
        }

        private void Rsa_typeInit()
        {
            comboBox31.Items.Clear();

            comboBox31.Text = "";

            comboBox31.Items.Add("Public");
            comboBox31.Items.Add("Private");
     

            comboBox31.SelectedIndex = 0;
        }

        private void Rsa_Generate_keytypeInit()
        {
            comboBox32.Items.Clear();

            comboBox32.Text = "";

            comboBox32.Items.Add("XML_FILE");
            comboBox32.Items.Add("PEM_FILE");
            comboBox32.Items.Add("HEX_FILE");


            comboBox32.SelectedIndex = 0;
        }

        protected override void WndProc(ref Message m)
        {
            try
            {
                switch (m.WParam.ToInt32())
                {
                    case DBT_DEVICEARRIVAL:
                        DeviceArrival();
                        break;
                    case DBT_DEVICEREMOVECOMPLETE:
                        DeviceRemoveComplete();
                        break;
                    default:
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

            base.WndProc(ref m);
        }

        private void DukptInit()
        {
            IDC_KSN.GotFocus += new EventHandler(IDC_DukptPara_GotFocus);
            IDC_BDK.GotFocus += new EventHandler(IDC_DukptPara_GotFocus);

            IDC_BDK.Text = "0123456789ABCDEFFEDCBA9876543210";
            IDC_KSN.Text = "FFFF9876543210E00001";
            IDC_Data.Text = "0123456789ABCDEFFEDCBA9876543210";

            IDC_UseBDK.Checked = true;

            IDC_DesMode.Items.Clear();
            IDC_DesMode.Text = "";
            IDC_DesMode.Items.Add("ECB");
            IDC_DesMode.Items.Add("CBC");
            IDC_DesMode.SelectedIndex = 0;

        }

        void IDC_DukptPara_GotFocus(object sender, EventArgs e)
        {
            AcceptButton = IDC_Generate;
        }

        private void IDC_UseBDK_CheckedChanged(object sender, EventArgs e)
        {
            IDC_BDK.ReadOnly = false;
            IDC_IPEK.ReadOnly = true;
        }

        private void IDC_UseIPEK_CheckedChanged(object sender, EventArgs e)
        {
            IDC_BDK.ReadOnly = true;
            IDC_IPEK.ReadOnly = false;
        }


        public FormDemo()
        {
            InitializeComponent();

            DeviceArrival();

            USB_BaudList();
            USB_DataBitList();
            USB_StopBitList();
            USB_CheckBitList();
            USB_CtrlList();

            TradeModeList();
            CurrencySymbolList();
            ViposModeList();
            KeyIndexList();
            TransTypeList();
            CurrencyCodeList();
            EncryptionModeList();
            TransactionTypeInit();

            KeyInjection10F0_Init();
            KeyInjection10F2_Init();
            KeyInjection10E4_Init();
            KeyInjection10E2_Init();

            APDU_PackInit();
            InputPinInit();
            TangemCardInit();
            EMV_UpdateInit();

            CaculateDES_Init();

            DigitalEnvelopeInit();

            SelfRepairInit();
            

            CustomInit();

            DukptInit();
            Logfile_conversionInit();
            Log_key_selectInit();
            Rsa_typeInit();
            Rsa_Generate_keytypeInit();


            checkBox12.Checked = true;
        }

        private void FunctionDoTrade()
        {
            Control.CheckForIllegalCrossThreadCalls = false;

            listBox2.Items.Clear();

            textBox38.Clear();

            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                entry.resetQPOS(hashtable);

                hashtable.Clear();

                //amt
                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionamount, string.Format("{0:D12}", Convert.ToInt64(Convert.ToString(Convert.ToDouble(textBox14.Text.ToString()) * 100))));

                //amt other
                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionamountother, string.Format("{0:D12}", Convert.ToInt64(Convert.ToString(Convert.ToDouble(textBox15.Text.ToString()) * 100))));

                //trade mode
                //String str_tradeMode = textBox15.Text.ToString();
                if (comboBox7.Text == "ICC")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontrademode, "01");
                }
                else if (comboBox7.Text == "MCR")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontrademode, "02");
                }
                else if (comboBox7.Text == "ICC/MCR/NFC")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontrademode, "03");
                }
                else if (comboBox7.Text == "ICC/MCR/NFC/NotDown")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontrademode, "04");
                }
                else if (comboBox7.Text == "ICC/MCR")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontrademode, "05");
                }
                else if (comboBox7.Text == "ICC/MCR/NotDown")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontrademode, "06");
                }
                else if (comboBox7.Text == "NFC")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontrademode, "07");
                }
                else if (comboBox7.Text == "ICC/MCR/NFC/NotUp")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontrademode, "08");
                }
                else if (comboBox7.Text == "ICC/MCR/NFC/NotUp/NotDown")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontrademode, "09");
                }
                else
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontrademode, "03");
                }

                //currency symbol
                if (comboBox8.Text == "DEFAULT")
                {

                }
                else
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactioncurrencysymbol, comboBox8.Text);
                }

                //busines mode
                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionbussinessmode, comboBox9.Text.ToString());

                //time
                hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontimestamp, textBox16.Text.ToString());

                //rand
                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionrandom, textBox17.Text.ToString());

                //additional data
                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionadditionaldata, textBox18.Text.ToString());

                //key index
                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionkeygroup, comboBox10.Text.ToString());

                //input amount on pos
                if (checkBox9.CheckState == CheckState.Checked)
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactioninputamountonpos, "01");
                }
                else
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactioninputamountonpos, "00");
                }

                //display amount on pos
                if (checkBox12.CheckState == CheckState.Checked)
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiondisplayamountonpos, "01");
                }
                else
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiondisplayamountonpos, "00");
                }

                //transaction type
                if (comboBox28.Text == "SERVICE")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontype, "01");
                }
                else if (comboBox28.Text == "SERVICE")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontype, "02");
                }
                else if (comboBox28.Text == "CASH")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontype, "03");
                }
                else if (comboBox28.Text == "CASHBACK")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontype, "04");
                }
                else if (comboBox28.Text == "INQUIRE")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontype, "05");
                }
                else if (comboBox28.Text == "TRANSFER")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontype, "06");
                }
                else if (comboBox28.Text == "ADMIN")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontype, "07");
                }
                else if (comboBox28.Text == "CASHDEPOSIT")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontype, "08");
                }
                else if (comboBox28.Text == "PAYMENT")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontype, "09");
                }
                else if (comboBox28.Text == "SALE")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontype, "0B");
                }
                else if (comboBox28.Text == "PREAUTH")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontype, "0C");
                }
                else if (comboBox28.Text == "BALANCE")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontype, "0D");
                }
                else if (comboBox28.Text == "ECQ DESIGNATED LOAD")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontype, "10");
                }
                else if (comboBox28.Text == "ECQ UNDESIGNATED LOAD")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontype, "11");
                }
                else if (comboBox28.Text == "ECQ CASH LOAD")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontype, "12");
                }
                else if (comboBox28.Text == "ECQ CASH LOAD VOID")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontype, "13");
                }
                else if (comboBox28.Text == "REFUND")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontype, "14");
                }
                else if (comboBox28.Text == "MODIFY PIN")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontype, "F0");
                }
                else
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactiontype, "01");
                }

                //currency code
                hashtable.Add(ClassDspreadEntry.HashtableKey.transactioncurrencycode, comboBox12.Text.ToString());

                //custom display
                hashtable.Add(ClassDspreadEntry.HashtableKey.transactioncustomdisplay, textBox19.Text.ToString());

                //record custom data
                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionrecordcustomdata, textBox20.Text.ToString());

                //amt point display
                if (checkBox10.CheckState == CheckState.Checked)
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactionamountpointdisplay, "01");
                }
                else
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactionamountpointdisplay, "00");
                }

                //mac

                entry.doTrade(hashtable);

                listBox2.Items.Clear();

                foreach (var item in hashtable)
                {
                    listBox2.Items.Add(item.Key + " : " + item.Value);
                }

            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }

            button9.Enabled = true;

            Control.CheckForIllegalCrossThreadCalls = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String COM_PortName = comboBox1.Text;

            Console.WriteLine(COM_PortName);

            if (COM_PortName == "")
            {
                return;
            }
            else
            {

            }

            if (g_USB_SerialPort == null || g_USB_SerialPort.PortName != COM_PortName)
            {
                g_USB_SerialPort = new System.IO.Ports.SerialPort(COM_PortName);
            }
            else
            {

            }

            if (g_USB_SerialPort.IsOpen)
            {
                try
                {
                    g_USB_SerialPort.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
                button1.Text = "OPEN";
                USB_ConfigurableStatus(true);

                g_USB_SerialPort = null;
            }
            else
            {
                try
                {
                    g_USB_SerialPort.Open();
                    g_USB_SerialPort.BaudRate = Convert.ToInt32(comboBox2.Items[comboBox2.SelectedIndex].ToString());
                    g_USB_SerialPort.WriteTimeout = 2000;
                    g_USB_SerialPort.ReadTimeout = 1000000;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
                if (g_USB_SerialPort.IsOpen)
                {
                    button1.Text = "CLOSE";
                    USB_ConfigurableStatus(false);
                }
                else
                {
                    
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void FormDemo_Load(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
            
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                entry.SetDeviceSerialPort(g_USB_SerialPort);
                entry.GetPosInfo(hashtable);

                listBox1.Items.Clear();

                foreach (var item in hashtable)
                {
                    listBox1.Items.Add(item.Key + ":" + item.Value);
                }
            }
            else
            {

            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            Thread pThread = new Thread(FunctionDoTrade);

            button9.Enabled = false;
            pThread.Start();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                entry.SetDeviceSerialPort(g_USB_SerialPort);
                entry.GetPartOfUpgradeKey(hashtable);

                listBox1.Items.Clear();

                foreach (var item in hashtable)
                {
                    if (item.Key == ClassDspreadEntry.HashtableKey.pospartofupgradekey)
                    {
                        textBox27.Clear();
                        textBox27.AppendText(item.Value);
                        break;
                    }
                    else
                    {

                    }
                }
            }
            else
            {

            }
        }

        private void label23_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
        }

        private void comboBox7_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void label36_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                label105.Text = "";
                if (    textBox23.TextLength == 0 && textBox24.TextLength == 0 && textBox25.TextLength == 0
                    ||  textBox23.TextLength != 0 && (textBox23.TextLength != 32 || textBox22.TextLength != 16)
                    ||  textBox24.TextLength != 0 && (textBox24.TextLength != 32 || textBox26.TextLength != 16)
                    ||  textBox25.TextLength != 0 && (textBox25.TextLength != 32 || textBox28.TextLength != 16)
                    )
                {
                    label105.Text = "input length error !";
                    return;
                }
                else
                {

                }

                hashtable.Add(ClassDspreadEntry.HashtableKey.postdk, textBox23.Text);
                hashtable.Add(ClassDspreadEntry.HashtableKey.postdkcheckvalue, textBox22.Text);
                hashtable.Add(ClassDspreadEntry.HashtableKey.pospik, textBox24.Text);
                hashtable.Add(ClassDspreadEntry.HashtableKey.pospikcheckvalue, textBox26.Text);
                hashtable.Add(ClassDspreadEntry.HashtableKey.posmck, textBox25.Text);
                hashtable.Add(ClassDspreadEntry.HashtableKey.posmckcheckvalue, textBox28.Text);
                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionkeygroup, comboBox11.Text);

                entry.SetDeviceSerialPort(g_USB_SerialPort);
                entry.InjectKeyCommand_10F0(hashtable);

                foreach (var item in hashtable)
                {
                    if (item.Key == ClassDspreadEntry.HashtableKey.resultmessage)
                    {
                        label105.Text = item.Value;
                        break;
                    }
                    else
                    {

                    }
                }
            }
            else
            {

            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            label105.Text = "";

            textBox23.Text = "";
            if (checkBox14.CheckState == CheckState.Checked)
            {
                textBox22.Text = "";
            }
            else
            {

            }

            textBox24.Text = "";
            if (checkBox15.CheckState == CheckState.Checked)
            {
                textBox26.Text = "";
            }
            else
            {

            }

            textBox25.Text = "";
            if (checkBox16.CheckState == CheckState.Checked)
            {
                textBox28.Text = "";
            }
            else
            {

            }
        }

        private void label43_Click(object sender, EventArgs e)
        {

        }

        private void checkBox14_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox14.CheckState == CheckState.Checked)
            {
                textBox22.Enabled = true;
            }
            else
            {
                textBox22.Text = "0000000000000000";
                textBox22.Enabled = false;
            }
        }

        private void checkBox15_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox15.CheckState == CheckState.Checked)
            {
                textBox26.Enabled = true;
            }
            else
            {
                textBox26.Text = "0000000000000000";
                textBox26.Enabled = false;
            }
        }

        private void checkBox16_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox16.CheckState == CheckState.Checked)
            {
                textBox28.Enabled = true;
            }
            else
            {
                textBox28.Text = "0000000000000000";
                textBox28.Enabled = false;
            }
        }

        private void textBox23_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox22_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void comboBox15_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox15.Text == "03")
            {
                textBox33.MaxLength = 6;
                textBox34.MaxLength = 6;
                textBox37.MaxLength = 6;
                textBox33.Text = "000000";
                textBox34.Text = "000000";
                textBox37.Text = "000000";
            }
            else
            {
                textBox33.MaxLength = 16;
                textBox34.MaxLength = 16;
                textBox37.MaxLength = 16;
                textBox33.Text = "0000000000000000";
                textBox34.Text = "0000000000000000";
                textBox37.Text = "0000000000000000";
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox32.Text = "";
            textBox31.Text = "";
            textBox33.Text = "";
            textBox30.Text = "";
            textBox29.Text = "";
            textBox34.Text = "";
            textBox36.Text = "";
            textBox35.Text = "";
            textBox37.Text = "";

            label104.Text = "";
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                label104.Text = "";
                if (textBox32.TextLength == 0 && textBox30.TextLength == 0 && textBox36.TextLength == 0
                    || textBox32.TextLength != 0 && (textBox32.TextLength != 32 || textBox31.TextLength != 20 || (textBox33.TextLength != 6 && textBox33.TextLength != 16))
                    || textBox30.TextLength != 0 && (textBox30.TextLength != 32 || textBox29.TextLength != 20 || (textBox34.TextLength != 6 && textBox34.TextLength != 16))
                    || textBox36.TextLength != 0 && (textBox36.TextLength != 32 || textBox35.TextLength != 20 || (textBox37.TextLength != 6 && textBox37.TextLength != 16))
                    )
                {
                    label104.Text = "input length error !";
                    return;
                }
                else
                {

                }

                hashtable.Add(ClassDspreadEntry.HashtableKey.postrackipek, textBox32.Text);
                hashtable.Add(ClassDspreadEntry.HashtableKey.postrackksn, textBox31.Text);
                hashtable.Add(ClassDspreadEntry.HashtableKey.postrackipekcheckvalue, textBox33.Text);

                hashtable.Add(ClassDspreadEntry.HashtableKey.posemvipek, textBox30.Text);
                hashtable.Add(ClassDspreadEntry.HashtableKey.posemvksn, textBox29.Text);
                hashtable.Add(ClassDspreadEntry.HashtableKey.posemvipekcheckvalue, textBox34.Text);

                hashtable.Add(ClassDspreadEntry.HashtableKey.pospinipek, textBox36.Text);
                hashtable.Add(ClassDspreadEntry.HashtableKey.pospinksn, textBox35.Text);
                hashtable.Add(ClassDspreadEntry.HashtableKey.pospinipekcheckvalue, textBox37.Text);

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionkeygroup, comboBox14.Text);

                hashtable.Add(ClassDspreadEntry.HashtableKey.poscheckvaluelengthlimit, comboBox15.Text);

                entry.SetDeviceSerialPort(g_USB_SerialPort);
                entry.InjectKeyCommand_10F2(hashtable);
                
                foreach (var item in hashtable)
                {
                    if (item.Key == ClassDspreadEntry.HashtableKey.resultmessage)
                    {
                        label104.Text = item.Value;
                        break;
                    }
                    else
                    {

                    }
                }
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void checkBox17_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox17.CheckState == CheckState.Checked)
            {
                textBox33.Text = "0000000000000000";
                textBox33.Enabled = false;
                textBox34.Text = "0000000000000000";
                textBox34.Enabled = false;
                textBox37.Text = "0000000000000000";
                textBox37.Enabled = false;
                comboBox15.Enabled = false;
            }
            else
            {
                textBox33.Enabled = true;
                textBox34.Enabled = true;
                textBox37.Enabled = true;
                comboBox15.Enabled = true;
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                g_USB_SerialPort.WriteTimeout = 2000;
                g_USB_SerialPort.ReadTimeout = 10000;

                button12.Enabled = false;

                entry.resetQPOS(hashtable);

                button12.Enabled = true;

                g_USB_SerialPort.WriteTimeout = 2000;
                g_USB_SerialPort.ReadTimeout = 1000000;

                //foreach (var item in hashtable)
                //{
                //    MessageBox.Show(item.Value);
                //}
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            listBox3.Items.Clear();
            textBox54.Text = "";
            textBox55.Text = "";
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "04");

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                if (entry.UpdateEmvApp(hashtable) == false)
                {
                    foreach (var item in hashtable)
                    {
                        if (item.Key == ClassDspreadEntry.HashtableKey.result)
                        {
                            MessageBox.Show("ERROR: UpdateEmvApp Failed : " + item.Value);
                            return;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {

                }

                if (hashtable.Count == 0)
                {
                    MessageBox.Show("The terminal does not load any Application!");
                    return;
                }
                else
                {

                }

                listBox3.Items.Clear();

                foreach (var item in hashtable)
                {
                    listBox3.Items.Add(item.Key + ":" + item.Value);
                }
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "04");

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                if (entry.UpdateEmvCapk(hashtable) == false)
                {
                    foreach (var item in hashtable)
                    {
                        if (item.Key == ClassDspreadEntry.HashtableKey.result)
                        {
                            MessageBox.Show("ERROR: UpdateEmvCapk Failed : " + item.Value);
                            return;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {

                }

                if (hashtable.Count == 0)
                {
                    MessageBox.Show("The terminal does not load any Application!");
                    return;
                }
                else
                {

                }

                listBox3.Items.Clear();

                foreach (var item in hashtable)
                {
                    listBox3.Items.Add(item.Key + ":" + item.Value);
                }
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            textBox41.Text = "";
        }

        private void button20_Click(object sender, EventArgs e)
        {
            textBox40.Text = textBox39.Text + textBox42.Text + textBox45.Text + textBox46.Text + textBox43.Text + textBox44.Text + textBox47.Text;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                button15.Enabled = false;
                comboBox16.Enabled = false;
                comboBox17.Enabled = false;

                if (comboBox16.Items[comboBox16.SelectedIndex].ToString() == "ENCRYPT TEXT")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.apduencrypttype, "01");
                }
                else
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.apduencrypttype, "00");
                }

                if (comboBox17.Items[comboBox17.SelectedIndex].ToString() == "CONTACT CARD")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.apducardtype, "00");
                }
                else
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.apducardtype, "01");
                }

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                entry.APDU_PowerDown(hashtable);

                entry.APDU_PollCard(hashtable);

                button18.Enabled = true;
                button19.Enabled = true;
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                if (comboBox17.Items[comboBox17.SelectedIndex].ToString() == "CONTACT CARD")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.apducardtype, "00");
                }
                else
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.apducardtype, "01");
                }

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                entry.APDU_PowerDown(hashtable);

                button15.Enabled = true;
                comboBox16.Enabled = true;
                comboBox17.Enabled = true;
                button18.Enabled = false;
                button19.Enabled = false;
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (textBox40.Text == "")
            {
                return;
            }
            else
            {

            }

            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                button19.Enabled = false;

                if (comboBox17.Items[comboBox17.SelectedIndex].ToString() == "CONTACT CARD")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.apducardtype, "00");
                }
                else
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.apducardtype, "01");
                }

                hashtable.Add(ClassDspreadEntry.HashtableKey.apdudata, textBox40.Text);

                textBox41.Text += "APDU: ";
                textBox41.Text += textBox40.Text;
                textBox41.Text += "\r\n";

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                entry.APDU_Transmit(hashtable);

                foreach (var item in hashtable)
                {
                    if (item.Key == ClassDspreadEntry.HashtableKey.apduresponsedata)
                    {
                        textBox41.Text += "RPDU: ";
                        textBox41.Text += item.Value;
                        textBox41.Text += "\r\n\r\n";
                        break;
                    }
                    else
                    {

                    }
                }

                button19.Enabled = true;
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void textBox41_TextChanged(object sender, EventArgs e)
        {
            textBox41.SelectionStart = textBox41.Text.Length;
            textBox41.SelectionLength = 0;
            textBox41.ScrollToCaret();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                button21.Enabled = false;

                if (comboBox18.Items[comboBox18.SelectedIndex].ToString() == "ENCRYPT FORMAT PIN")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.inputpintype, "00");
                }
                else if (comboBox18.Items[comboBox18.SelectedIndex].ToString() == "XOR WITH PAN")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.inputpintype, "01");
                }
                else if (comboBox18.Items[comboBox18.SelectedIndex].ToString() == "ANSI x9.8, NOT PAN")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.inputpintype, "02");
                }
                else if (comboBox18.Items[comboBox18.SelectedIndex].ToString() == "FORMAT PIN ISO-1")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.inputpintype, "03");
                }
                else if (comboBox18.Items[comboBox18.SelectedIndex].ToString() == "PLAIN FORMAT PIN")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.inputpintype, "08");
                }
                else if (comboBox18.Items[comboBox18.SelectedIndex].ToString() == "PLAIN PIN")
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.inputpintype, "0A");
                }
                else
                {
                    hashtable.Add(ClassDspreadEntry.HashtableKey.inputpintype, "00");
                }

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionkeygroup, comboBox19.Items[comboBox19.SelectedIndex].ToString());

                hashtable.Add(ClassDspreadEntry.HashtableKey.inputpinlengthmax, comboBox20.Items[comboBox20.SelectedIndex].ToString());

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactioncustomdisplay, textBox49.Text);

                hashtable.Add(ClassDspreadEntry.HashtableKey.inputpinpan, textBox50.Text);

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionadditionaldata, textBox51.Text);

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                entry.InputPIN(hashtable);

                foreach (var item in hashtable)
                {
                    if (item.Key == ClassDspreadEntry.HashtableKey.transactionpinblock)
                    {
                        textBox48.Text += "PIN Block: ";
                        textBox48.Text += item.Value;   
                        textBox48.Text += "\r\n\r\n";
                    }
                    else if (item.Key == ClassDspreadEntry.HashtableKey.transactionpinksn)
                    {
                        textBox48.Text += "PIN KSN: ";
                        textBox48.Text += item.Value;
                        textBox48.Text += "\r\n\r\n";
                    }
                    else
                    {

                    }
                }

                button21.Enabled = true;
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            textBox48.Text = "";
        }

        private void button26_Click(object sender, EventArgs e)
        {
            textBox52.Text = "";
        }

        private void button25_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                hashtable.Add(ClassDspreadEntry.HashtableKey.apduencrypttype, "00");

                hashtable.Add(ClassDspreadEntry.HashtableKey.apducardtype, "01");

                button25.Enabled = false;

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                entry.APDU_PowerDown(hashtable);

                entry.APDU_PollCard(hashtable);

                button23.Enabled = true;
                groupBox10.Enabled = true;

            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void button23_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                hashtable.Add(ClassDspreadEntry.HashtableKey.apducardtype, "01");

                button23.Enabled = false;

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                entry.APDU_PowerDown(hashtable);

                button25.Enabled = true;
                groupBox10.Enabled = false;

            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void label62_Click(object sender, EventArgs e)
        {

        }

        private void button24_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();
                string apdu;

                apdu = "00";

                apdu += "F2";

                apdu += "00";

                apdu += "00";

                apdu += "22";

                apdu += "10";

                apdu += "20";

                SHA256 sha256 = new SHA256Managed();
                byte[] tmpByte = sha256.ComputeHash(GetKeyByteArray(textBox53.Text));
                apdu += ToHexString(tmpByte);

                hashtable.Add(ClassDspreadEntry.HashtableKey.apducardtype, "01");

                hashtable.Add(ClassDspreadEntry.HashtableKey.apdudata, apdu);

                textBox52.Text += "APDU: ";
                textBox52.Text += apdu;
                textBox52.Text += "\r\n";

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                entry.APDU_Transmit(hashtable);

                foreach (var item in hashtable)
                {
                    if (item.Key == ClassDspreadEntry.HashtableKey.apduresponsedata)
                    {
                        textBox52.Text += "RPDU: ";
                        textBox52.Text += item.Value;
                        textBox52.Text += "\r\n\r\n";
                        break;
                    }
                    else
                    {

                    }
                }
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void textBox52_TextChanged(object sender, EventArgs e)
        {
            textBox52.SelectionStart = textBox52.Text.Length;
            textBox52.SelectionLength = 0;
            textBox52.ScrollToCaret();
        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            String BoxString = "";
            String Type = "";

            if (listBox3.SelectedIndex != -1)
            {
                BoxString = listBox3.SelectedItem.ToString();
                Type = BoxString.Substring(0, 3);
            }
            else
            {
                return;
            }

            if (Type == "App")
            {
                if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
                {
                    ClassDspreadEntry entry = new ClassDspreadEntry();
                    Dictionary<String, String> hashtable = new Dictionary<String, String>();

                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "06");

                    byte[] AID = Util.HexStringToByteArray(BoxString.Substring(10, BoxString.Length - 10));

                    byte[] TLV_Buffer = new byte[AID.Length + 8];

                    TLV tlv = new TLV();
                    tlv.tlv_new(TLV_Buffer, 0x9F06, (uint)AID.Length, AID);
                    TLV_Buffer = tlv.tlv_find(TLV_Buffer, 0x9F06);

                    String TLV_String = Util.byteArray2Hex(TLV_Buffer);

                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtlv, TLV_String);

                    entry.SetDeviceSerialPort(g_USB_SerialPort);

                    if (entry.UpdateEmvApp(hashtable) == false)
                    {
                        foreach (var item in hashtable)
                        {
                            if (item.Key == ClassDspreadEntry.HashtableKey.result)
                            {
                                MessageBox.Show("ERROR: UpdateEmvApp Failed : " + item.Value);
                                return;
                            }
                            else
                            {

                            }
                        }
                    }
                    else
                    {

                    }

                    foreach (var item in hashtable)
                    {
                        if (item.Key == ClassDspreadEntry.HashtableKey.transactionupdateemvparamresult)
                        {
                            textBox55.Text = item.Value;
                            textBox54.Text = Util.TLV_PrintValue(item.Value);
                            break;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {
                    MessageBox.Show("Terminal not connected!");
                }
            }
            else if (Type == "Cap")
            {
                if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
                {
                    ClassDspreadEntry entry = new ClassDspreadEntry();
                    Dictionary<String, String> hashtable = new Dictionary<String, String>();
                    TLV tlv = new TLV();

                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "06");

                    byte[] RID = Util.HexStringToByteArray(BoxString.Substring(11, 10));
                    byte[] TLV_Buffer = new byte[256];

                    tlv.tlv_new(TLV_Buffer, 0x9F06, (uint)RID.Length, RID);
                    String TLV_RID = Util.byteArray2Hex(tlv.tlv_find(TLV_Buffer, 0x9F06));

                    byte[] RID_Index = Util.HexStringToByteArray(BoxString.Substring(22, 2));

                    tlv.tlv_new(TLV_Buffer, 0x9F22, (uint)RID_Index.Length, RID_Index);
                    String TLV_RID_Index = Util.byteArray2Hex(tlv.tlv_find(TLV_Buffer, 0x9F22));

                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtlv, TLV_RID + TLV_RID_Index);

                    entry.SetDeviceSerialPort(g_USB_SerialPort);

                    if (entry.UpdateEmvCapk(hashtable) == false)
                    {
                        foreach (var item in hashtable)
                        {
                            if (item.Key == ClassDspreadEntry.HashtableKey.result)
                            {
                                MessageBox.Show("ERROR: UpdateEmvCapk Failed : " + item.Value);
                                return;
                            }
                            else
                            {

                            }
                        }
                    }
                    else
                    {

                    }

                    foreach (var item in hashtable)
                    {
                        if (item.Key == ClassDspreadEntry.HashtableKey.transactionupdateemvparamresult)
                        {
                            textBox55.Text = item.Value;
                            textBox54.Text = Util.TLV_PrintValue(item.Value);
                            break;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {
                    MessageBox.Show("Terminal not connected!");
                }
            }
            else
            {

            }
        }

        private void listBox2_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (listBox2.SelectedItem != null)
            {
                textBox38.Text = listBox2.SelectedItem.ToString();
            }
            else
            {

            }
        }

        private void textBox54_TextChanged(object sender, EventArgs e)
        {

        }

        private void button27_Click(object sender, EventArgs e)
        {

        }

        private void button28_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                MessageBoxButtons messButton = MessageBoxButtons.OKCancel;
                DialogResult dr = MessageBox.Show("WARNING: Are you sure you want to delete all EMV Applications? Doing so may prevent you from trading properly and you must redownload the necessary Application.", "Clear Application", messButton);
                if (dr == DialogResult.OK)
                {
                    ClassDspreadEntry entry = new ClassDspreadEntry();
                    Dictionary<String, String> hashtable = new Dictionary<String, String>();

                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "01");

                    entry.SetDeviceSerialPort(g_USB_SerialPort);

                    if (entry.UpdateEmvApp(hashtable) == false)
                    {
                        foreach (var item in hashtable)
                        {
                            if (item.Key == ClassDspreadEntry.HashtableKey.result)
                            {
                                MessageBox.Show("ERROR: UpdateEmvApp Failed : " + item.Value);
                                return;
                            }
                            else
                            {

                            }
                        }
                    }
                    else
                    {

                    }

                    listBox3.Items.Clear();

                    MessageBox.Show("Clear EMV App Success");
                }
                else
                {

                }
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void file_tlv_anlysis(byte[] src)
        {
            //textBox54.Text= Util.byteArray2Hex(src);
            byte[] data = new byte[384];
            TLV tlv = new TLV();
            uint len = 0;
            uint TotalLen = 0;
            while (true)
            {
                data = src.Skip((int)TotalLen).Take((int)src.Length - (int)TotalLen).ToArray();
                //Setvalue((int)len,src.Length,src,data);
                //textBox54.Text="data"+Util.byteArray2Hex(data)+"\r\n";
                if (tlv.tlv_get_t(data) != 0)
                {
                    len = tlv.tlv_get_node_l(data);
                    TotalLen += len;
                    //listBox3.Items.Add("len:" + len+ " "+tlv.tlv_get_t(data));
                    
                }
                else
                {
                     
                    textBox55.Text = Util.byteArray2Hex(src.Skip(0).Take((int)TotalLen).ToArray());
                    //textBox54.Text = "TotalLen=" + TotalLen + "\r\n";

                    break;
                    
                }
                
            }
        }

        private void button29_Click(object sender, EventArgs e)
        { 
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();
                if (textBox55.Text == "")
                {
                    MessageBox.Show("Please add the necessary application data in TLV format!");
                    return;
                }
                else
                {

                }

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "02");

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtlv, textBox55.Text);

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                if (entry.UpdateEmvApp(hashtable) == false)
                {
                    foreach (var item in hashtable)
                    {
                        if (item.Key == ClassDspreadEntry.HashtableKey.result)
                        {
                            MessageBox.Show("ERROR: UpdateEmvApp Failed : " + item.Value);
                            return;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {

                }

                hashtable.Clear();

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "04");

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                if (entry.UpdateEmvApp(hashtable) == false)
                {
                    foreach (var item in hashtable)
                    {
                        if (item.Key == ClassDspreadEntry.HashtableKey.result)
                        {
                            MessageBox.Show("ERROR: UpdateEmvApp Failed : " + item.Value);
                            return;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {

                }

                listBox3.Items.Clear();

                foreach (var item in hashtable)
                {
                    listBox3.Items.Add(item.Key + ":" + item.Value);
                }

            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void button40_Click(object sender, EventArgs e)
        {
            textBox55.Text = "";
        }

        private void button27_Click_1(object sender, EventArgs e)
        {
            byte[] t = Util.HexStringToByteArray(comboBox21.Text);
            byte[] v = Util.HexStringToByteArray(textBox56.Text);

            uint Tag = (uint)Util.byteArrayToInt(t);

            TLV tlv = new TLV();

            byte[] bTLV = new byte[1024];

            tlv.tlv_new(bTLV, Tag, (uint)v.Length, v);
            byte[] b2TLV = tlv.tlv_find(bTLV, Tag);
            String sTLV = Util.byteArray2Hex(b2TLV);
            textBox55.Text += sTLV;
        }

        private void button30_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                if (textBox55.Text == "")
                {
                    MessageBox.Show("Please add the necessary Application AID in TLV format!");
                    return;
                }
                else
                {

                }

                MessageBoxButtons messButton = MessageBoxButtons.OKCancel;
                DialogResult dr = MessageBox.Show("Do you want to delete this Application?", "Delete Application", messButton);
                if (dr == DialogResult.OK)
                {

                }
                else
                {
                    return;
                }

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "03");

                TLV tlv = new TLV();
                byte[] TLV_Buffer = new byte[1024];

                byte [] tlv_buf = Util.HexStringToByteArray(textBox55.Text);

                tlv.tlv_new(TLV_Buffer, 0x7F00, (uint)tlv_buf.Length, tlv_buf);

                byte [] bAID = tlv.tlv_find(TLV_Buffer, 0x9F06);

                String AID = Util.byteArray2Hex(bAID);

                if (AID == null)
                {
                    return;
                }
                else
                {
                    
                }

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtlv, AID);

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                if (entry.UpdateEmvApp(hashtable) == false)
                {
                    foreach (var item in hashtable)
                    {
                        if (item.Key == ClassDspreadEntry.HashtableKey.result)
                        {
                            MessageBox.Show("ERROR: UpdateEmvApp Failed : " + item.Value);
                            return;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {

                }

                hashtable.Clear();

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "04");

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                if (entry.UpdateEmvApp(hashtable) == false)
                {
                    foreach (var item in hashtable)
                    {
                        if (item.Key == ClassDspreadEntry.HashtableKey.result)
                        {
                            MessageBox.Show("ERROR: UpdateEmvApp Failed : " + item.Value);
                            return;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {

                }

                listBox3.Items.Clear();

                foreach (var item in hashtable)
                {
                    listBox3.Items.Add(item.Key + ":" + item.Value);
                }

                textBox54.Text = "";
                textBox55.Text = "";

            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void button31_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                if (textBox55.Text == "")
                {
                    MessageBox.Show("Please add the necessary application data in TLV format!");
                    return;
                }
                else
                {

                }

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "05");

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtlv, textBox55.Text);

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                if (entry.UpdateEmvApp(hashtable) == false)
                {
                    foreach (var item in hashtable)
                    {
                        if (item.Key == ClassDspreadEntry.HashtableKey.result)
                        {
                            MessageBox.Show("ERROR: UpdateEmvApp Failed : " + item.Value);
                            return;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {

                }

                hashtable.Clear();

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "04");

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                if (entry.UpdateEmvApp(hashtable) == false)
                {
                    foreach (var item in hashtable)
                    {
                        if (item.Key == ClassDspreadEntry.HashtableKey.result)
                        {
                            MessageBox.Show("ERROR: UpdateEmvApp Failed : " + item.Value);
                            return;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {

                }

                listBox3.Items.Clear();

                foreach (var item in hashtable)
                {
                    listBox3.Items.Add(item.Key + ":" + item.Value);
                }

                textBox54.Text = "";
                textBox55.Text = "";

            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void button39_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                MessageBoxButtons messButton = MessageBoxButtons.OKCancel;
                DialogResult dr = MessageBox.Show("WARNING: Are you sure you want to delete all EMV CAPK? Doing so may prevent you from trading properly and you must redownload the necessary CAPK.", "Clear CAPK", messButton);
                if (dr == DialogResult.OK)
                {
                    ClassDspreadEntry entry = new ClassDspreadEntry();
                    Dictionary<String, String> hashtable = new Dictionary<String, String>();

                    hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "01");

                    entry.SetDeviceSerialPort(g_USB_SerialPort);

                    if (entry.UpdateEmvCapk(hashtable) == false)
                    {
                        foreach (var item in hashtable)
                        {
                            if (item.Key == ClassDspreadEntry.HashtableKey.result)
                            {
                                MessageBox.Show("ERROR: UpdateEmvCapk Failed : " + item.Value);
                                return;
                            }
                            else
                            {

                            }
                        }
                    }
                    else
                    {

                    }

                    listBox3.Items.Clear();

                    MessageBox.Show("Clear EMV CAPK Success");
                }
                else
                {

                }
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void button41_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                entry.GetPOS_PublicKey(hashtable);

                foreach (var item in hashtable)
                {
                    if (item.Key == ClassDspreadEntry.HashtableKey.pospublickey)
                    {
                        textBox57.Text = item.Value;
                    }
                    else
                    {

                    }
                }
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void button42_Click(object sender, EventArgs e)
        {

            if (textBox58.Text == "")
            {
                return;
            }
            else
            {

            }
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                hashtable.Add(ClassDspreadEntry.HashtableKey.digitalenvelope, textBox58.Text);

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                entry.DigitalEnvelopeDownload(hashtable);

                foreach (var item in hashtable)
                {
                    if (item.Key == ClassDspreadEntry.HashtableKey.resultmessage)
                    {
                        label69.Text = item.Value;
                    }
                    else
                    {

                    }
                }
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void button44_Click(object sender, EventArgs e)
        {
            label69.Text = "";
            textBox74.Text = "";
            textBox59.Text = "";
            textBox86.Text = "";
            textBox88.Text = "";
        }

        private void button32_Click(object sender, EventArgs e)
        {
            //端口判断
            if (g_USB_SerialPort == null || !g_USB_SerialPort.IsOpen)
            {
                MessageBox.Show("Terminal not connected!");
                return;
            }
            else
            {

            }

            textBox54.Text = "";

            ClassDspreadEntry entry = new ClassDspreadEntry();
            Dictionary<String, String> hashtable = new Dictionary<String, String>();
            Dictionary<String, String> hashtable_parameters = new Dictionary<String, String>();
            String PlarformVersionNumber = "";

            //创建必要临时文件
            //FileStream ApplicationFIle = File.Create(System.Windows.Forms.Application.StartupPath + "/" + "temp_emv_app.bin");
            //FileStream CAPK_FIle = File.Create(System.Windows.Forms.Application.StartupPath + "/" + "temp_emv_capk.bin");

            XmlDocument xmldoc = new XmlDocument();

            XmlDeclaration xmldecl = xmldoc.CreateXmlDeclaration("1.0", "utf-8", null);
            xmldoc.AppendChild(xmldecl);

            XmlNode root = xmldoc.CreateElement("EMV_Configuration");
            XmlNode CustomerTree = xmldoc.CreateElement("CustomerTree");
            XmlNode AppTreeNode = xmldoc.CreateElement("AppTree");
            XmlNode CAPK_TreeNode = xmldoc.CreateElement("CAPK_Tree");

            //获取平台版本
            hashtable.Clear();

            entry.SetDeviceSerialPort(g_USB_SerialPort);

            entry.GetQPOS_PlatformVersionNumber(hashtable);

            foreach (var item in hashtable)
            {
                if (item.Key == ClassDspreadEntry.HashtableKey.posplatformversionnumber)
                {
                    PlarformVersionNumber = item.Value;
                    XmlElement CustomerElement = xmldoc.CreateElement("PlatformVersionNumber");
                    CustomerTree.AppendChild(CustomerElement);
                    CustomerElement.InnerText = PlarformVersionNumber;
                }
                else
                {

                }
            }

            root.AppendChild(CustomerTree);
            root.AppendChild(AppTreeNode);
            root.AppendChild(CAPK_TreeNode);
            xmldoc.AppendChild(root);

            if (PlarformVersionNumber == "")
            {
                MessageBox.Show("ERROR: Platform version number geting failed!");
                //ApplicationFIle.Close();
                //CAPK_FIle.Close();
                //xmldoc.Save(System.Windows.Forms.Application.StartupPath + "/" + "temp_emv_configuration.xml");
                return;
            }
            else
            {

            }

            //获取应用列表
            hashtable.Clear();
            hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "04");

            entry.SetDeviceSerialPort(g_USB_SerialPort);

            if (entry.UpdateEmvApp(hashtable) == false)
            {
                foreach (var item in hashtable)
                {
                    if (item.Key == ClassDspreadEntry.HashtableKey.result)
                    {
                        MessageBox.Show("ERROR: UpdateEmvApp Failed : " + item.Value);
                        return;
                    }
                    else
                    {

                    }
                }
            }
            else
            {

            }

            if (hashtable.Count == 0)
            {
                MessageBox.Show("The terminal does not load any Application!");
                //ApplicationFIle.Close();
                //CAPK_FIle.Close();
                //xmldoc.Save(System.Windows.Forms.Application.StartupPath + "/" + "temp_emv_configuration.xml");
                return;
            }
            else
            {

            }

            //遍历应用列表，读取应用数据并保存
            foreach (var item in hashtable)
            {
                if (item.Value == "")
                {
                    continue;
                }
                else
                {

                }

                hashtable_parameters.Clear();
                hashtable_parameters.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "06");

                byte[] AID = Util.HexStringToByteArray(item.Value);
                byte[] TLV_Buffer = new byte[AID.Length + 8];
                TLV tlv = new TLV();
                tlv.tlv_new(TLV_Buffer, 0x9F06, (uint)AID.Length, AID);
                TLV_Buffer = tlv.tlv_find(TLV_Buffer, 0x9F06);
                String TLV_String = Util.byteArray2Hex(TLV_Buffer);
                hashtable_parameters.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtlv, TLV_String);

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                if (entry.UpdateEmvApp(hashtable_parameters) == false)
                {
                    foreach (var itemIn in hashtable)
                    {
                        if (itemIn.Key == ClassDspreadEntry.HashtableKey.result)
                        {
                            MessageBox.Show("ERROR: UpdateEmvApp Failed : " + item.Value);
                            return;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {

                }

                foreach (var itemv in hashtable_parameters)
                {
                    if (itemv.Key == ClassDspreadEntry.HashtableKey.transactionupdateemvparamresult)
                    {
                        textBox54.Text += itemv.Key + " : " + itemv.Value;
                        textBox54.Text += "\r\n";
                        textBox54.SelectionStart = textBox54.Text.Length;
                        textBox54.ScrollToCaret();

                        byte[] Application = Util.HexStringToByteArray(itemv.Value);
                        byte[] ApplicationBuffer = new byte[EMV_PARAMETERS_BLOCK_SIZE];

                        if (Application.Length > EMV_PARAMETERS_BLOCK_SIZE)
                        {
                            MessageBox.Show("ERROR: File Length Error!");
                            //ApplicationFIle.Close();
                            //CAPK_FIle.Close();
                            //xmldoc.Save(System.Windows.Forms.Application.StartupPath + "/" + "temp_emv_configuration.xml");
                            return;
                        }
                        else
                        {

                        }

                        for (int i = 0; i < ApplicationBuffer.Length; i++)
                            ApplicationBuffer[i] = 0x00;

                        Array.Copy(Application, ApplicationBuffer, Application.Length);

                        //ApplicationFIle.Write(ApplicationBuffer, 0, ApplicationBuffer.Length);

                        {
                            byte[] TLV_BatchBuffer = new byte[EMV_PARAMETERS_BLOCK_SIZE + 8];
                            byte[] b = new byte[EMV_PARAMETERS_BLOCK_SIZE];
                            byte[] TLV_ElmentBuffer = new byte[EMV_PARAMETERS_BLOCK_SIZE];
                            XmlNode AppNode = xmldoc.CreateElement("App");

                            tlv.tlv_new(TLV_BatchBuffer, 0x7F00, (uint)Application.Length, Application);

                            b = tlv.tlv_get_v(TLV_BatchBuffer);
                            while (b.Length != 0)
                            {
                                string StrTAG = "_" + String.Format("{0:X}", tlv.tlv_get_t(b));
                                String StrValue = Util.byteArray2Hex(tlv.tlv_get_v(b));

                                XmlElement AppTAG_Element = xmldoc.CreateElement(StrTAG);
                                //Util.SetTAG_ElementAttribute(tlv.tlv_get_t(b), AppTAG_Element);
                                AppNode.AppendChild(AppTAG_Element);
                                AppTAG_Element.InnerText = StrValue;

                                b = b.Skip((int)tlv.tlv_get_node_l(b)).Take((int)b.Length - (int)tlv.tlv_get_node_l(b)).ToArray();
                            }

                            AppTreeNode.AppendChild(AppNode);
                        }

                        break;
                    }
                    else
                    {

                    }
                }

                hashtable_parameters.Clear();
            }

            //获取公钥列表
            hashtable.Clear();
            hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "04");

            entry.SetDeviceSerialPort(g_USB_SerialPort);

            if (entry.UpdateEmvCapk(hashtable) == false)
            {
                foreach (var item in hashtable)
                {
                    if (item.Key == ClassDspreadEntry.HashtableKey.result)
                    {
                        MessageBox.Show("ERROR: UpdateEmvCapk Failed : " + item.Value);
                        //ApplicationFIle.Close();
                        //CAPK_FIle.Close();
                        //xmldoc.Save(System.Windows.Forms.Application.StartupPath + "/" + "temp_emv_configuration.xml");
                        return;
                    }
                    else
                    {

                    }
                }
            }
            else
            {

            }

            if (hashtable.Count == 0)
            {
                MessageBox.Show("The terminal does not load any CAPK!");
                //ApplicationFIle.Close();
                //CAPK_FIle.Close();
                //xmldoc.Save(System.Windows.Forms.Application.StartupPath + "/" + "temp_emv_configuration.xml");
                return;
            }
            else
            {

            }

            //遍历应公钥表，读取公钥数据并保存
            foreach (var item in hashtable)
            {
                if (item.Value == "")
                {
                    continue;
                }
                else
                {

                }

                hashtable_parameters.Clear();
                hashtable_parameters.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "06");

                TLV tlv = new TLV();
                byte[] RID = Util.HexStringToByteArray(item.Value.Substring(0, 10));
                byte[] TLV_Buffer = new byte[256];

                tlv.tlv_new(TLV_Buffer, 0x9F06, (uint)RID.Length, RID);
                String TLV_RID = Util.byteArray2Hex(tlv.tlv_find(TLV_Buffer, 0x9F06));

                byte[] RID_Index = Util.HexStringToByteArray(item.Value.Substring(11, 2));

                tlv.tlv_new(TLV_Buffer, 0x9F22, (uint)RID_Index.Length, RID_Index);
                String TLV_RID_Index = Util.byteArray2Hex(tlv.tlv_find(TLV_Buffer, 0x9F22));

                hashtable_parameters.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtlv, TLV_RID + TLV_RID_Index);

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                if (entry.UpdateEmvCapk(hashtable_parameters) == false)
                {
                    foreach (var itemIn in hashtable)
                    {
                        if (itemIn.Key == ClassDspreadEntry.HashtableKey.result)
                        {
                            MessageBox.Show("ERROR: UpdateEmvCapk Failed : " + item.Value);
                            //ApplicationFIle.Close();
                            //CAPK_FIle.Close();
                            //xmldoc.Save(System.Windows.Forms.Application.StartupPath + "/" + "temp_emv_configuration.xml");
                            return;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {

                }

                foreach (var itemv in hashtable_parameters)
                {
                    if (itemv.Key == ClassDspreadEntry.HashtableKey.transactionupdateemvparamresult)
                    {
                        textBox54.Text += itemv.Key + " : " + itemv.Value;
                        textBox54.Text += "\r\n";
                        textBox54.SelectionStart = textBox54.Text.Length;
                        textBox54.ScrollToCaret();

                        byte[] CAPK = Util.HexStringToByteArray(itemv.Value);
                        byte[] CAPK_Buffer = new byte[EMV_PARAMETERS_BLOCK_SIZE];

                        if (CAPK.Length > EMV_PARAMETERS_BLOCK_SIZE)
                        {
                            MessageBox.Show("ERROR: File Length Error!");
                            //ApplicationFIle.Close();
                            //CAPK_FIle.Close();
                            //xmldoc.Save(System.Windows.Forms.Application.StartupPath + "/" + "temp_emv_configuration.xml");
                            return;
                        }
                        else
                        {

                        }

                        for (int i = 0; i < CAPK_Buffer.Length; i++)
                            CAPK_Buffer[i] = 0x00;

                        Array.Copy(CAPK, CAPK_Buffer, CAPK.Length);

                        //CAPK_FIle.Write(CAPK_Buffer, 0, CAPK_Buffer.Length);

                        {
                            byte[] TLV_BatchBuffer = new byte[EMV_PARAMETERS_BLOCK_SIZE + 8];
                            byte[] b = new byte[EMV_PARAMETERS_BLOCK_SIZE];
                            byte[] TLV_ElmentBuffer = new byte[EMV_PARAMETERS_BLOCK_SIZE];
                            XmlNode CAPK_Node = xmldoc.CreateElement("Capk");

                            tlv.tlv_new(TLV_BatchBuffer, 0x7F00, (uint)CAPK.Length, CAPK);

                            b = tlv.tlv_get_v(TLV_BatchBuffer);
                            while (b.Length != 0)
                            {
                                string StrTAG = "_" + String.Format("{0:X}", tlv.tlv_get_t(b));
                                String StrValue = Util.byteArray2Hex(tlv.tlv_get_v(b));

                                XmlElement CAPK_TAG_Element = xmldoc.CreateElement(StrTAG);
                                //Util.SetTAG_ElementAttribute(tlv.tlv_get_t(b), CAPK_TAG_Element);
                                CAPK_Node.AppendChild(CAPK_TAG_Element);
                                CAPK_TAG_Element.InnerText = StrValue;

                                b = b.Skip((int)tlv.tlv_get_node_l(b)).Take((int)b.Length - (int)tlv.tlv_get_node_l(b)).ToArray();
                            }

                            CAPK_TreeNode.AppendChild(CAPK_Node);
                        }

                        break;
                    }
                    else
                    {

                    }
                }

                hashtable_parameters.Clear();
            }

            //ApplicationFIle.Close();
            //CAPK_FIle.Close();

            XmlElement CustomerElementOut = xmldoc.CreateElement("UploadTime");
            CustomerTree.AppendChild(CustomerElementOut);
            CustomerElementOut.InnerText = DateTime.Now.ToLocalTime().ToString();

            OpenFileDialog dialog = new OpenFileDialog();
            dialog.CheckFileExists = false;
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                xmldoc.Save(dialog.FileName);
            }
            else
            {
                xmldoc.Save(System.Windows.Forms.Application.StartupPath + "/" + "temp_emv_configuration.xml");
            }

            MessageBox.Show("Upload Success!");
        }

        private void button33_Click(object sender, EventArgs e)
        {
            //textBox54.Text = string.Empty;
            //textBox55.Text = string.Empty;
            //OpenFileDialog dialog = new OpenFileDialog();
            //dialog.CheckFileExists = false;
            //if (dialog.ShowDialog() == DialogResult.OK)
            //{
            //    textBox54.SelectedText = dialog.FileName;
            //}
            //update_emv(dialog.FileName);
        }

        private void button38_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();
                if (textBox55.Text == "")
                {
                    MessageBox.Show("Please add the necessary CAPK data in TLV format!");
                    return;
                }
                else
                {

                }

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "02");

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtlv, textBox55.Text);

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                if (entry.UpdateEmvCapk(hashtable) == false)
                {
                    foreach (var item in hashtable)
                    {
                        if (item.Key == ClassDspreadEntry.HashtableKey.result)
                        {
                            MessageBox.Show("ERROR: UpdateEmvCapk Failed : " + item.Value);
                            return;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {

                }

                hashtable.Clear();

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "04");

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                if (entry.UpdateEmvCapk(hashtable) == false)
                {
                    foreach (var item in hashtable)
                    {
                        if (item.Key == ClassDspreadEntry.HashtableKey.result)
                        {
                            MessageBox.Show("ERROR: UpdateEmvCapk Failed : " + item.Value);
                            return;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {

                }

                listBox3.Items.Clear();

                foreach (var item in hashtable)
                {
                    listBox3.Items.Add(item.Key + ":" + item.Value);
                }

            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void button37_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                if (textBox55.Text == "")
                {
                    MessageBox.Show("Please add the necessary CAPK RID and index in TLV format!");
                    return;
                }
                else
                {

                }

                MessageBoxButtons messButton = MessageBoxButtons.OKCancel;
                DialogResult dr = MessageBox.Show("Do you want to delete this CAPK", "Delete CAPK", messButton);
                if (dr == DialogResult.OK)
                {

                }
                else
                {
                    return;
                }

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "03");

                TLV tlv = new TLV();
                byte[] TLV_Buffer = new byte[1024];

                byte[] tlv_buf = Util.HexStringToByteArray(textBox55.Text);

                tlv.tlv_new(TLV_Buffer, 0x7F00, (uint)tlv_buf.Length, tlv_buf);

                byte[] bAID = tlv.tlv_find(TLV_Buffer, 0x9F06);

                String AID = Util.byteArray2Hex(bAID);

                if (AID == null)
                {
                    return;
                }
                else
                {

                }

                byte[] bIndex = tlv.tlv_find(TLV_Buffer, 0x9F22);

                String Index = Util.byteArray2Hex(bIndex);

                if (Index == null)
                {
                    return;
                }
                else
                {

                }

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtlv, AID + Index);

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                if (entry.UpdateEmvCapk(hashtable) == false)
                {
                    foreach (var item in hashtable)
                    {
                        if (item.Key == ClassDspreadEntry.HashtableKey.result)
                        {
                            MessageBox.Show("ERROR: UpdateEmvCapk Failed : " + item.Value);
                            return;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {

                }

                hashtable.Clear();

                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "04");

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                if (entry.UpdateEmvCapk(hashtable) == false)
                {
                    foreach (var item in hashtable)
                    {
                        if (item.Key == ClassDspreadEntry.HashtableKey.result)
                        {
                            MessageBox.Show("ERROR: UpdateEmvCapk Failed : " + item.Value);
                            return;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {

                }

                listBox3.Items.Clear();

                foreach (var item in hashtable)
                {
                    listBox3.Items.Add(item.Key + ":" + item.Value);
                }

                textBox54.Text = "";
                textBox55.Text = "";

            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void button35_Click(object sender, EventArgs e)
        {

        }

        private void button34_Click(object sender, EventArgs e)
        {
            //textBox54.Text = string.Empty;
            //OpenFileDialog dialog = new OpenFileDialog();
            //if (dialog.ShowDialog() == DialogResult.OK)
            //{
            //    textBox54.SelectedText = dialog.FileName;
            //}
            //updatecapk(dialog.FileName);
        }

        //DES decrypt
        private void button36_Click(object sender, EventArgs e)
        {
            byte[] byKey = Util.HexStringToByteArray(textBox64.Text);
            byte[] inputByteArray = Util.HexStringToByteArray(textBox65.Text);
            byte[] result = new byte[0];

            if (comboBox22.Text == "CBC")
            {
                byte[] IV = Util.HexStringToByteArray(textBox67.Text);
                result = Util.Decrypt_CBC(byKey, inputByteArray, IV);
            }
            else
            {
                result = Util.Decrypt_ECB(byKey, inputByteArray);

            }
            textBox66.Text = Util.byteArray2Hex(result);
        }

        //DES encrypt
        private void button45_Click(object sender, EventArgs e)
        {
            byte[] byKey = Util.HexStringToByteArray(textBox64.Text);
            byte[] inputByteArray = Util.HexStringToByteArray(textBox65.Text);
            byte[] result = new byte[0];

            if (comboBox22.Text == "CBC")
            {
                byte[] IV = Util.HexStringToByteArray(textBox67.Text);
                result = Util.Encrypt_CBC(byKey, inputByteArray, IV);
            }
            else
            {
                result = Util.Encrypt_ECB(byKey, inputByteArray);
            }
            if (result == null)
            {
                MessageBox.Show("The length of the key or data is incorrect!");
                return;
            }
            StringBuilder ret = new StringBuilder();
            foreach (byte b in result)
            {
                ret.AppendFormat("{0:X2}", b);
            }
            textBox66.Text = ret.ToString();
        }

        private void textBox67_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox22_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox22.Text == "CBC")
            {
                textBox67.Enabled = true;
            }
            else
            {
                textBox67.Enabled = false;
            }
        }

        //Select the file to upload
        private void button46_Click(object sender, EventArgs e)
        {
            textBox68.Text = string.Empty;
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                textBox68.SelectedText = dialog.FileName;
            }
        }

        //Start uploading file
        private void button47_Click(object sender, EventArgs e)
        {
            //get the file path and file name
            String filePath;
            String fileName;

            filePath = textBox68.Text;
            if (filePath == "")
            {
                textBox83.Text += "Please select the file to upload!\r\n";
                return;
            }
            else
            {
                fileName = Path.GetFileName(filePath);
                
                textBox69.Text = fileName;
            }

            //upload the file
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                hashtable.Clear();
                hashtable.Add("FileName", fileName);

                FileStream fs = File.OpenRead(filePath);

                int fd = 0;

                hashtable.Add("Mode", "w+");
                fd = entry.dock_fopen(hashtable);
                if (fd < 0)
                {
                    textBox83.Text += "fopen filed! fd = " + fd.ToString() + "\r\n";
                    return;
                }
                else
                {
                    hashtable.Add("fd", fd.ToString());
                }

                int perUploadLen = 512;
                Byte[] fileDate = new Byte[perUploadLen];

                int TotalLength = (int)fs.Length;
                int writtenLen = 0;
                int writtenTotalLen = 0;
                int ret = 0;
                progressBar1.Minimum = 0;
                progressBar1.Maximum = TotalLength;
                while (true)
                {
                    fs.Seek(writtenTotalLen, SeekOrigin.Begin);
                    ret = fs.Read(fileDate, 0, perUploadLen);
                    
                    //hashtable.Add("FileContent", Encoding.Default.GetString(fileDate));
                    hashtable.Add("FileContent", Convert.ToBase64String(fileDate));
                    hashtable.Add("FileContentLen", Convert.ToString(ret));
                    writtenLen = entry.dock_fwrite(hashtable);
                    if (writtenLen < 0)
                    {
                        textBox83.Text += "dock_fwrite error!\r\n";
                        break;
                    }
                    else if (writtenLen < ret)
                    {
                        textBox83.Text += "not all byte ! written " + writtenLen + "\r\n";
                    }
                    else
                    {
                    }

                    hashtable.Add("offset", 0.ToString());
                    hashtable.Add("fromwhere", 2.ToString());
                    entry.dock_fseek(hashtable);

                    writtenTotalLen += ret;
                    progressBar1.Value = writtenTotalLen;
                    if (writtenTotalLen == TotalLength)
                    {
                        textBox83.Text += "Write File:      " +fileName +"   size:       "+ writtenTotalLen + "\r\n";
                    }

                    if (ret < perUploadLen)
                    {
                        hashtable.Add("FileDateLength", writtenTotalLen.ToString());
                        break;
                    }
                }

                entry.dock_close(hashtable);


                fs.Close();

                foreach (var item in hashtable)
                {
                    textBox83.Text += item.Key + ":" + item.Value + "\r\n";
                }
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        //Delete the file
        private void button48_Click(object sender, EventArgs e)
        {
            String fileName;

            fileName = textBox69.Text;
            if (fileName == "")
            {
                textBox83.Text += "Please input the file name!\r\n";
                return;
            }
            else { }

            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {

                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                hashtable.Clear();
                hashtable.Add("FileName", fileName);

                if (entry.dock_remove(hashtable) == 0)
                {
                    DialogResult dr1 = MessageBox.Show("File deleted successfully!", "reminder", MessageBoxButtons.OK);
                }
                else
                {
                    DialogResult dr2 = MessageBox.Show("File deleted failed!", "reminder", MessageBoxButtons.OK);
                }
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        //List File
        private void button49_Click(object sender, EventArgs e)
        {
            String foldername = "Z:\\\\*";
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {

                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                hashtable.Clear();
                hashtable.Add("FileName", foldername);

                if (entry.dock_list(hashtable) == 0)
                {
                    textBox83.Text += "filelist>>" + hashtable["filelist"] + "\r\n";
                }
                else
                {

                }
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void button50_Click(object sender, EventArgs e)
        {
            textBox83.Text = "";
        }

        private void button52_Click(object sender, EventArgs e)
        {
            //byte[] StrRes = Encoding.Default.GetBytes(textBox72.Text);
            String Str = textBox72.Text;

            byte[] Byte = new byte[Str.Length/2];
            byte[] Res = new byte[20];

            for (int i = 0; i < Str.Length / 2; i++)
            {
                Byte[i] = (Byte)Convert.ToByte(Str.Substring(i * 2, 2), 16);
            }

            HashAlgorithm iSHA = new SHA1CryptoServiceProvider();
            Res = iSHA.ComputeHash(Byte);

            textBox71.Text = Util.byteArray2Hex(Res);
        }


        //get track
        private void button51_Click(object sender, EventArgs e)
        {
            String encode_track;
            encode_track = textBox70.Text;

            if (encode_track == "")
            {
                textBox73.Text = "Please input the track!";
                return;
            }

            string bitstr = Util.hexstr2bitstr(encode_track);

            byte[] trackData = new byte[1024];
            int len = bitstr.Length / 6;

            for(int i = 0;i < len; i++)
            {
                int result = Util.bitstr2byte("00" + bitstr.Substring(6 * i, 6)) + 0x20;
                trackData[i] = (byte)result;
            }

            textBox73.Text = System.Text.Encoding.Default.GetString(trackData);
        }
        public static void XMLConvertToPEM()//XML格式密钥转PEM
        {
            var rsa2 = new RSACryptoServiceProvider();
            using (var sr = new StreamReader(".\\PrivateKey.xml"))
            {
                rsa2.FromXmlString(sr.ReadToEnd());
            }
            var p = rsa2.ExportParameters(true);

            var key = new RsaPrivateCrtKeyParameters(
                new Org.BouncyCastle.Math.BigInteger(1, p.Modulus), new BigInteger(1, p.Exponent), new BigInteger(1, p.D),
                new BigInteger(1, p.P), new Org.BouncyCastle.Math.BigInteger(1, p.Q), new BigInteger(1, p.DP), new BigInteger(1, p.DQ),
                new BigInteger(1, p.InverseQ));

            using (var sw = new StreamWriter(".\\PrivateKey.pem"))
            {
                var pemWriter = new Org.BouncyCastle.OpenSsl.PemWriter(sw);
                pemWriter.WriteObject(key);
            }
        }
        public static byte[] Int2Bytes(int value)
        {
            byte[] src = new byte[2];
            //src[3] = (byte)((value >> 24) & 0xFF);
            //src[2] = (byte)((value >> 16) & 0xFF);
            src[1] = (byte)((value >> 8) & 0xFF);
            src[0] = (byte)(value & 0xFF);
            //Console.WriteLine("src=" + Util.byteArray2Hex(src));
            return src;
        }
        private void button43_Click(object sender, EventArgs e)
        {
            int RSA_Length = 0;
            String ServerPrivateKeyD = textBox74.Text;
            String ServerPrivateKeyN = textBox59.Text;
            String RSA_Type = "";
            String POS_PublicKeyN = "";
            String POS_PublicKeyE = "";
            String EnvelopePlainBody = "";
            String EnvelopeEncryptBody = "";

            String ItemValue = comboBox23.SelectedItem.ToString();

            if (String.Compare(ItemValue, "RSA1024") == 0)
            {
                textBox58.Text = "1024";
                //RSA_Type = "1024";
                RSA_Length = 1024;
            }
            else if (String.Compare(ItemValue, "RSA2048") == 0)
            {
                textBox58.Text = "2048";
                //RSA_Type = "2048";
                RSA_Length = 2048;
            }
            RSA_Type = textBox58.Text;
            //if (ServerPrivateKeyD.Length * 8 / 2 != 1024 && ServerPrivateKeyD.Length * 8 / 2 != 2048)
            //{
            //    return;
            //}
            //else
            //{
            //    RSA_Length = ServerPrivateKeyD.Length * 8 / 2;
            //}

            if (ServerPrivateKeyN.Length * 8 / 2 != RSA_Length)
            {
                return;
            }
            else
            {

            }
            Console.WriteLine("server_public_lenght" + ServerPrivateKeyN.Length * 8 / 2 + "\r\n");
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                entry.GetPOS_PublicKey(hashtable);

                foreach (var item in hashtable)
                {
                    if (item.Key == ClassDspreadEntry.HashtableKey.pospublickey)
                    {
                        int Length = 0;
                        int Cnt = 0;

                        Length = (int)Util.BE_PtrToShort(Util.str2Bcd(item.Value.Substring(Cnt, 4)));
                        Cnt += 4;
                        POS_PublicKeyN = item.Value.Substring(Cnt, (int)Length * 2);
                        Console.WriteLine("pos_publicKEY=" + POS_PublicKeyN);
                        Cnt += Length * 2;

                        Length = (int)Util.BE_PtrToShort(Util.str2Bcd(item.Value.Substring(Cnt, 4)));
                        Cnt += 4;
                        POS_PublicKeyE = item.Value.Substring(Cnt, (int)Length * 2);
                        Console.WriteLine("pos_publicE=" + POS_PublicKeyE);
                        Cnt += Length * 2;
                    }
                    else
                    {

                    }
                }
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
                return;
            }

            if (POS_PublicKeyN.Length * 8 / 2 != RSA_Length)
            {
                return;
            }
            else
            {

            }

            if (POS_PublicKeyE.Length / 2 != 3)
            {
                return;
            }
            else
            {

            }

            EnvelopePlainBody += "0001020304050607";
            Console.WriteLine("EnvelopePlainBody=" + EnvelopePlainBody + "\r\n");
            if (comboBox24.Text == "ConfigurationServer")
            {
                EnvelopePlainBody += "00";
            }
            else if (comboBox24.Text == "ManagementServer")
            {
                EnvelopePlainBody += "01";
                Console.WriteLine("ManagementServer" + "\r\n");
                Console.WriteLine("EnvelopePlainBody=" + EnvelopePlainBody + "\r\n");
            }
            else if (comboBox24.Text == "OtherServer(TDES Encryption)")
            {
                EnvelopePlainBody += "02";
            }
            else
            {
                return;
            }

            if (comboBox25.Text == "WorkKey")
            {
                EnvelopePlainBody += "02";
                Console.WriteLine("WorkKey" + "\r\n");
                Console.WriteLine("EnvelopePlainBody=" + EnvelopePlainBody + "\r\n");
            }
            else if (comboBox25.Text == "UserData")
            {
                EnvelopePlainBody += "01";
            }
            else if (comboBox25.Text == "Firmware(Not Support)")
            {
                EnvelopePlainBody += "00";
            }
            else
            {
                return;
            }

            EnvelopePlainBody += "0000";
            Console.WriteLine("EnvelopePlainBody=" + EnvelopePlainBody + "\r\n");
            byte[] SN = new byte[textBox62.Text.Length / 2];
            Console.WriteLine("textBox62.Text="+ textBox62.Text+"\r\n");
            SN = Util.HexStringToByteArray(textBox62.Text);
            EnvelopePlainBody += Util.byteArray2Hex(Int2Bytes(SN.Length));
            Console.WriteLine("data_leng=" + Util.byteArray2Hex(Int2Bytes(SN.Length)));
            Console.WriteLine("EnvelopePlainBody=" + EnvelopePlainBody + "\r\n");
            EnvelopePlainBody += "0000";
            Console.WriteLine("EnvelopePlainBody=" + EnvelopePlainBody + "\r\n");
            EnvelopePlainBody += textBox62.Text;
            Console.WriteLine("data=" + textBox62.Text);
            Console.WriteLine("EnvelopePlainBody=" + EnvelopePlainBody + "\r\n");
            Console.WriteLine("data_leng=" + EnvelopePlainBody.Length);
            //int len = 0;
            //len = Convert.ToInt32(EnvelopePlainBody.Length);
            //Console.WriteLine("len=" + len);
            //if (len / 8 != 0)
            //{
            //    EnvelopePlainBody += "FFFFFF";
            //    Console.WriteLine("EnvelopePlainBody=" + EnvelopePlainBody + "\r\n");
            //}
            //Console.WriteLine("length=" + Convert.ToInt32(EnvelopePlainBody.Length));
            //EnvelopePlainBody += Util.byteArray2Hex(Util.intToBytes(textBox62.Text.Length / 2));

            //EnvelopePlainBody += textBox62.Text;

            //EnvelopeEncryptBody = Util.DigitalEnvelopeGenerate(ServerPrivateKeyD, ServerPrivateKeyN, POS_PublicKeyN, POS_PublicKeyE, EnvelopePlainBody);
            EnvelopeEncryptBody = Util.Generate_envolope(RSA_Type,ServerPrivateKeyD, POS_PublicKeyN, EnvelopePlainBody);
            textBox58.Text = EnvelopeEncryptBody;
        }

        private void label65_Click(object sender, EventArgs e)
        {

        }

        private void button53_Click(object sender, EventArgs e)
        {
            String LengthString = "";

            if (comboBox26.Text.Length != 2 || textBox63.Text.Length %2 != 0)
            {
                return;
            }
            else
            {

            }

            LengthString = Util.byteArray2Hex(Util.intToBytes(textBox63.Text.Length / 2));

            textBox62.Text += comboBox26.Text + LengthString + textBox63.Text;
        }
        //RSA加密c#默认只能使用公钥进行加密
        private void button54_Click(object sender, EventArgs e)
        {
            String PlainData = textBox62.Text;
            String PubKey = textBox74.Text;
            String PrivateKey = textBox59.Text;
            String EnData = "";
            string publicKeyPath = @".\\PublicKey.xml";
            string publicKey = File.ReadAllText(publicKeyPath);

            RSACryptoServiceProvider rsaPublic = new RSACryptoServiceProvider();
            rsaPublic.FromXmlString(publicKey);

            //对数据进行加密
            byte[] publicValue = rsaPublic.Encrypt(Encoding.UTF8.GetBytes(PlainData), false);
            //使用base64将byte转换为string
            //EnData = Convert.ToBase64String(publicValue);
            EnData=Util.byteArray2Hex(publicValue);
            //EnData = Convert.ToString(publicValue);
            //将base64转换为hex

            textBox58.Text = "RSA Encrypt:\r\n" + " \r\n" + EnData;

        }
        //RSA 解密c#默认只能使用私钥进行解密
        private void button55_Click(object sender, EventArgs e)
        {
            String EnData = textBox62.Text;
            String PubKey = textBox74.Text;
            String PrivateKey = textBox59.Text;
            String PlainData = "";
            String base64data = "";
         
            string privateKeyPath = @".\\PrivateKey.xml";
            string privateKey = File.ReadAllText(privateKeyPath);

            //创建RSA对象，并载入私钥
            RSACryptoServiceProvider rsaPrivate = new RSACryptoServiceProvider();
            rsaPrivate.FromXmlString(privateKey);

            //将hex转化为base64
            int length = EnData.Length / 2;
            byte[] d = new byte[length];
            //将hex转化为byte
            d = Util.HexStringToByteArray(EnData);
            //使用base64将byte转换为string
            base64data = Convert.ToBase64String(d);
            //textBox74.Text = base64data;

            //对数据解密
            byte[] privateValue = rsaPrivate.Decrypt(Convert.FromBase64String(base64data), false);
            PlainData = Encoding.UTF8.GetString(privateValue);


            textBox58.Text = "RSA Decrypt:\r\n" + "  \r\n" + PlainData;
        }

        private void button54_Click_1(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                hashtable.Clear();
                hashtable.Add(ClassDspreadEntry.HashtableKey.posid, textBox60.Text);//posid
                hashtable.Add(ClassDspreadEntry.HashtableKey.pospublickey, textBox76.Text);//pos public key
                hashtable.Add(ClassDspreadEntry.HashtableKey.posprivatekey, textBox77.Text); //pos private key
                hashtable.Add(ClassDspreadEntry.HashtableKey.postmk, textBox80.Text);//pos tmk
                hashtable.Add(ClassDspreadEntry.HashtableKey.posbthead, textBox61.Text);
                hashtable.Add(ClassDspreadEntry.HashtableKey.posbtmacaddr, textBox75.Text);
                hashtable.Add(ClassDspreadEntry.HashtableKey.posbtmanapubkey, textBox79.Text);
                hashtable.Add(ClassDspreadEntry.HashtableKey.posbencryptmode, textBox89.Text);
                //Console.WriteLine("BT HEAD="+ textBox61.Text);
                //Console.WriteLine("BT MAC addr=" + textBox75.Text);

                entry.SelfDestructionRepair(hashtable);
                foreach (var item in hashtable)
                {
                    if (item.Key == ClassDspreadEntry.HashtableKey.result)
                    {
                        label17.Text = item.Value;
                    }
                    else
                    {

                    }
                }

            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void textBox81_TextChanged(object sender, EventArgs e)
        {

        }

        private void button56_Click(object sender, EventArgs e)
        {
            textBox81.Text = string.Empty;
        }

        private void button55_Click_1(object sender, EventArgs e)
        {
            
        }

        private void button55_Click_2(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();
                String mode = "";
                if (comboBox27.Text == "Left")
                {
                    mode = "00";
                }
                else if (comboBox27.Text == "Center")
                {
                    mode = "40";
                }
                else if (comboBox27.Text == "Right")
                {
                    mode = "20";
                }
                hashtable.Add(ClassDspreadEntry.HashtableKey.displaymode, mode);
                hashtable.Add(ClassDspreadEntry.HashtableKey.displayinfo, textBox81.Text);
                entry.SetDeviceSerialPort(g_USB_SerialPort);
                entry.Custom_display(hashtable);//custom display command

                foreach (var item in hashtable)
                {
                    if (item.Key == ClassDspreadEntry.HashtableKey.resultmessage)
                    {
                        label83.Text = item.Value;
                        break;
                    }
                    else
                    {

                    }
                }
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void button56_Click_1(object sender, EventArgs e)
        {
            textBox81.Text = string.Empty;
        }
        public void SaveToFile(String filename, String data)
        {
            System.IO.StreamWriter sw = System.IO.File.CreateText(filename);
            sw.WriteLine(data);
            sw.Close();
        }
        /// <summary>
        ///  格式化公钥/私钥
        /// </summary>
        /// <param name="key">生成的公钥/私钥</param>
        /// <param name="type">1:公钥 2:私钥</param>
        /// <returns>PEM格式的公钥/私钥</returns>
        public static string Format(string key, int type)
        {
            string result = string.Empty;

            int length = key.Length / 64;
            for (int i = 0; i < length; i++)
            {
                int start = i * 64;
                result = result + key.Substring(start, 64) + "\r\n";
            }

            result = result + key.Substring(length * 64);
            if (type == 1)
            {
                result = result.Insert(0, "-----BEGIN PUBLIC KEY-----\r\n");
                result += "\r\n-----END PUBLIC KEY-----";
            }
            if (type == 2)
            {
                result = result.Insert(0, "-----BEGIN PRIVATE KEY-----\r\n");
                result += "\r\n-----END PRIVATE KEY-----";
            }

            return result;
        }
        /// <summary>
        ///  XML格式公钥转PEM格式公钥
        /// </summary>
        /// <param name="xml">XML格式的公钥</param>
        /// <param name="saveFile">保存文件的物理路径</param>
        public static string Xml2PemPublic(string xml, string saveFile)
        {
            var rsa = new RSACryptoServiceProvider();
            rsa.FromXmlString(xml);
            var p = rsa.ExportParameters(false);
            RsaKeyParameters key = new RsaKeyParameters(false, new BigInteger(1, p.Modulus), new BigInteger(1, p.Exponent));
            using (var sw = new StreamWriter(saveFile))
            {
                var pemWriter = new Org.BouncyCastle.OpenSsl.PemWriter(sw);
                pemWriter.WriteObject(key);
            }

            SubjectPublicKeyInfo publicKeyInfo = SubjectPublicKeyInfoFactory.CreateSubjectPublicKeyInfo(key);
            byte[] serializedPublicBytes = publicKeyInfo.ToAsn1Object().GetDerEncoded();
            string publicKey = Convert.ToBase64String(serializedPublicBytes);
            //return Format(publicKey, 1);
            return publicKey;
        }

        /// <summary>
        ///  XML格式私钥转PEM
        /// </summary>
        /// <param name="xml">XML格式私钥</param>
        /// <param name="saveFile">保存文件的物理路径</param>
        public static string Xml2PemPrivate(string xml, string saveFile)
        {
            var rsa = new RSACryptoServiceProvider();
            rsa.FromXmlString(xml);
            var p = rsa.ExportParameters(true);
            var key = new RsaPrivateCrtKeyParameters(
                new BigInteger(1, p.Modulus), new BigInteger(1, p.Exponent), new BigInteger(1, p.D),
                new BigInteger(1, p.P), new BigInteger(1, p.Q), new BigInteger(1, p.DP), new BigInteger(1, p.DQ),
                new BigInteger(1, p.InverseQ));
            using (var sw = new StreamWriter(saveFile))
            {
                var pemWriter = new Org.BouncyCastle.OpenSsl.PemWriter(sw);
                pemWriter.WriteObject(key);
            }

            PrivateKeyInfo privateKeyInfo = PrivateKeyInfoFactory.CreatePrivateKeyInfo(key);
            byte[] serializedPrivateBytes = privateKeyInfo.ToAsn1Object().GetEncoded();
            string privateKey = Convert.ToBase64String(serializedPrivateBytes);
            //return Format(privateKey, 2);
            return privateKey;
        }
        public static void Generate_RSA_Key()
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            String xmlPrivateKey = rsa.ToXmlString(true);//xml私钥

            String pemPrivateKey = Xml2PemPrivate(xmlPrivateKey, "private.pem");//pem私钥

            String xmlPublicKey = rsa.ToXmlString(false);//xml公钥
            
            String pemPublicKey = Xml2PemPublic(xmlPublicKey, "public.pem");//pem公钥
        }
        public byte[] ReadChild(XmlElement parent, string name)
        {
            XmlElement element1 = (XmlElement)parent.SelectSingleNode(name);
            Console.WriteLine("element1.InnerText="+ element1.InnerText+"\r\n");
            //byte[] c = Convert.FromBase64String(element1.InnerText);
            //return hexToBytes(element1.InnerText); 
            //Util.byteArray2Hex(publicKeyParam.Modulus.ToByteArrayUnsigned())
            return Convert.FromBase64String(element1.InnerText);
        }
        private void Get_HexKey_fromXML(String filename)
        {
            String PublicN = "";
            String PublicE = "";
            String privateD = "";
            RSAParameters parameters1;
            parameters1 = new RSAParameters();
            //StreamReader reader1 = new StreamReader(filename);
            XmlDocument document1 = new XmlDocument();
            //document1.LoadXml(reader1.ReadToEnd());
            document1.LoadXml(filename);
            XmlElement element1 = (XmlElement)document1.SelectSingleNode("RSAKeyValue");
            parameters1.Modulus = ReadChild(element1, "Modulus");
            PublicN = Util.byteArray2Hex(parameters1.Modulus);
            Console.WriteLine("Modulus="+ PublicN + "\r\n");
            parameters1.Exponent = ReadChild(element1, "Exponent");
            PublicE = Util.byteArray2Hex(parameters1.Exponent);
            Console.WriteLine("Exponent=" + PublicE + "\r\n");
            parameters1.D = ReadChild(element1, "D");
            privateD = Util.byteArray2Hex(parameters1.D);
            Console.WriteLine("D=" + privateD+"\r\n");
            //textBox59.Text----------公钥N显示
            textBox59.Text = PublicN;
            //textBox88.Text----------私钥D显示
            textBox88.Text = privateD;
            //textBox86.Text----------E显示
            textBox86.Text = PublicE;
            //parameters1.DP = ReadChild(element1, "DP");
            //parameters1.DQ = ReadChild(element1, "DQ");
            //parameters1.P = ReadChild(element1, "P");
            //parameters1.Q = ReadChild(element1, "Q");
            //parameters1.InverseQ = ReadChild(element1, "InverseQ");
            //CspParameters parameters2 = new CspParameters();
            //parameters2.Flags = CspProviderFlags.UseMachineKeyStore;
            //RSACryptoServiceProvider provider1 = new RSACryptoServiceProvider(parameters2);
            //provider1.ImportParameters(parameters1);
            //reader1.Close();
            //return provider1;
        }
        private void button57_Click(object sender, EventArgs e)
        {
            String Private_FileName = "";
            String xmldata = "";
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                Private_FileName = dialog.FileName;
            }
            Console.WriteLine("Private_FileName="+ Private_FileName+"\r\n");
            //PEM转换XML私钥
            String pathname = GetPrivatePath(Private_FileName);
            xmldata = Privatepemtoxml(pathname);
            //textBox74.Text----------XML私钥显示
            textBox74.Text = xmldata;
            //XML得到HEX的N和E
            Get_HexKey_fromXML(xmldata);
           


            //Generate_RSA_Key();

        }
        /// <summary>    
        /// RSA公钥格式转换， 
        /// </summary>    
        /// <param name="publicKey">pem公钥</param>    
        /// <returns></returns>    
        public static string Publicpemtoxml(string publicKey)
        {
            RsaKeyParameters publicKeyParam = (RsaKeyParameters)PublicKeyFactory.CreateKey(Convert.FromBase64String(publicKey));
            Console.WriteLine("modulus=" + Util.byteArray2Hex(publicKeyParam.Modulus.ToByteArrayUnsigned()));
            Console.WriteLine("Exponent=" + Util.byteArray2Hex(publicKeyParam.Exponent.ToByteArrayUnsigned()));
            String pkxml = "<RSAKeyValue>\n<Modulus>" + ToHexString(publicKeyParam.Modulus.ToByteArrayUnsigned()) + "</Modulus>";
            pkxml += "\n<Exponent>" + ToHexString(publicKeyParam.Exponent.ToByteArrayUnsigned()) + "</Exponent>\n</RSAKeyValue>";
            System.IO.StreamWriter sw = System.IO.File.CreateText("publicHex.xml");
            sw.WriteLine(pkxml);
            sw.Close();
            //生成一个XML的hex文件
            return string.Format("<RSAKeyValue><Modulus>{0}</Modulus><Exponent>{1}</Exponent></RSAKeyValue>",
                          Convert.ToBase64String(publicKeyParam.Modulus.ToByteArrayUnsigned()),
                          Convert.ToBase64String(publicKeyParam.Exponent.ToByteArrayUnsigned()));


        }
        public static byte[] GetPublicFromPem(String publicKey)
        {
            RsaKeyParameters publicKeyParam = (RsaKeyParameters)PublicKeyFactory.CreateKey(Convert.FromBase64String(publicKey));
            String SN = "";
            String E = "";
            //Console.WriteLine("modulus=" + Util.byteArray2Hex(publicKeyParam.Modulus.ToByteArrayUnsigned()));
            //Console.WriteLine("Exponent=" + Util.byteArray2Hex(publicKeyParam.Exponent.ToByteArrayUnsigned()));
            SN = Util.byteArray2Hex(publicKeyParam.Modulus.ToByteArrayUnsigned());
            //E = Util.byteArray2Hex(publicKeyParam.Exponent.ToByteArrayUnsigned());

            return publicKeyParam.Modulus.ToByteArrayUnsigned();

        }
        public static byte[] GetPublicEFromPem(String publicKey)
        {
            RsaKeyParameters publicKeyParam = (RsaKeyParameters)PublicKeyFactory.CreateKey(Convert.FromBase64String(publicKey));
            String SN = "";
            String E = "";
            //Console.WriteLine("modulus=" + Util.byteArray2Hex(publicKeyParam.Modulus.ToByteArrayUnsigned()));
            //Console.WriteLine("Exponent=" + Util.byteArray2Hex(publicKeyParam.Exponent.ToByteArrayUnsigned()));
            //SN = Util.byteArray2Hex(publicKeyParam.Modulus.ToByteArrayUnsigned());
            E = Util.byteArray2Hex(publicKeyParam.Exponent.ToByteArrayUnsigned());

            return publicKeyParam.Exponent.ToByteArrayUnsigned();

        }
        public static string Privatepemtoxml(string pemkey)
        {
            AsymmetricCipherKeyPair keyPair;
            using (var sr = new StreamReader(pemkey))
            {
                var pemReader = new Org.BouncyCastle.OpenSsl.PemReader(sr);
                keyPair = (AsymmetricCipherKeyPair)pemReader.ReadObject();
            }
            var key = (RsaPrivateCrtKeyParameters)keyPair.Private;
            //var p = new RSAParameters
            //{
            //    Modulus = key.Modulus.ToByteArrayUnsigned(),
            //    Exponent = key.PublicExponent.ToByteArrayUnsigned(),
            //    D = key.Exponent.ToByteArrayUnsigned(),
            //    P = key.P.ToByteArrayUnsigned(),
            //    Q = key.Q.ToByteArrayUnsigned(),
            //    DP = key.DP.ToByteArrayUnsigned(),
            //    DQ = key.DQ.ToByteArrayUnsigned(),
            //    InverseQ = key.QInv.ToByteArrayUnsigned(),
            //};
            String phexxml = "<RSAKeyValue>\n<Modulus>" + ToHexString(key.Modulus.ToByteArrayUnsigned()) + "</Modulus>";
            phexxml += "\n<Exponent>" + ToHexString(key.PublicExponent.ToByteArrayUnsigned()) + "</Exponent>";
            phexxml += "\n<D>" + ToHexString(key.Exponent.ToByteArrayUnsigned()) + "</D>";
            phexxml += "\n<DP>" + ToHexString(key.DP.ToByteArrayUnsigned()) + "</DP>";
            phexxml += "\n<P>" + ToHexString(key.P.ToByteArrayUnsigned()) + "</P>";
            phexxml += "\n<Q>" + ToHexString(key.Q.ToByteArrayUnsigned()) + "</Q>";
            phexxml += "\n<DQ>" + ToHexString(key.DQ.ToByteArrayUnsigned()) + "</DQ>";
            phexxml += "\n<InverseQ>" + ToHexString(key.QInv.ToByteArrayUnsigned()) + "</InverseQ>\n</RSAKeyValue>";
            //System.IO.StreamWriter sw = System.IO.File.CreateText("privatHex.xml");
            //sw.WriteLine(phexxml);
            //sw.Close();
            String psxml = "<RSAKeyValue><Modulus>" + Convert.ToBase64String(key.Modulus.ToByteArrayUnsigned()) + "</Modulus>";
            psxml += "<Exponent>" + Convert.ToBase64String(key.PublicExponent.ToByteArrayUnsigned()) + "</Exponent>";
            psxml += "<P>" + Convert.ToBase64String(key.P.ToByteArrayUnsigned()) + "</P>";
            psxml += "<Q>" + Convert.ToBase64String(key.Q.ToByteArrayUnsigned()) + "</Q>";
            psxml += "<DP>" + Convert.ToBase64String(key.DP.ToByteArrayUnsigned()) + "</DP>";
            psxml += "<DQ>" + Convert.ToBase64String(key.DQ.ToByteArrayUnsigned()) + "</DQ>";
            psxml += "<InverseQ> " + Convert.ToBase64String(key.QInv.ToByteArrayUnsigned()) + " </InverseQ>";
            psxml += "<D>" + Convert.ToBase64String(key.Exponent.ToByteArrayUnsigned()) + "</D></RSAKeyValue>";
            //System.IO.StreamWriter sw1 = System.IO.File.CreateText(".\\XML_FILE\\private.xml");
            //sw1.WriteLine(psxml);
            //sw1.Close();
            return psxml;
            //SaveToFile("privatekey.xml", psxml);
            //var rsa = new RSACryptoServiceProvider();
            //rsa.ImportParameters(p);
            //return rsa.ToXmlString(true);
            //using (var sw = new StreamWriter("e:\\key.xml"))
            //{
            //    sw.Write(rsa.ToXmlString(true));
            //}
        }
        public static String GetPrivatePath(String name)
        {
            Console.WriteLine("pathnanme=" + name + "\r\n");
            return name;
        }
        
        private void button64_Click(object sender, EventArgs e)
        {
            textBox58.Text = string.Empty;
            String xmldata = "";
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                textBox58.SelectedText = dialog.FileName;
                String name = dialog.FileName;
                String pathname = GetPrivatePath(name);
                xmldata = Privatepemtoxml(pathname);
                Util.SetPrivateKey(xmldata);
            }

        }

        private void button65_Click(object sender, EventArgs e)
        {
            String pemData = textBox58.Text;
            byte[] SN = new byte[128];
            SN=GetPublicFromPem(pemData);
            textBox59.Text = Util.byteArray2Hex(SN);


        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            if (g_USB_SerialPort == null || !g_USB_SerialPort.IsOpen)
            {
                MessageBox.Show("Terminal not connected!");
                return;
            }
            else
            {

            }

            ClassDspreadEntry entry = new ClassDspreadEntry();
            Dictionary<String, String> hashtable = new Dictionary<String, String>();

            entry.SetDeviceSerialPort(g_USB_SerialPort);
            entry.GetPartOfUpgradeKey(hashtable);
            foreach (var item in hashtable)
            {
                if (item.Key == ClassDspreadEntry.HashtableKey.pospartofupgradekey)
                {
                    textBox27.Text = item.Value;
                }
                else
                {

                }
            }
        }

        private void button41_Click_1(object sender, EventArgs e)
        {
            if (g_USB_SerialPort == null || !g_USB_SerialPort.IsOpen)
            {
                MessageBox.Show("Terminal not connected!");
                return;
            }
            else
            {

            }

            ClassDspreadEntry entry = new ClassDspreadEntry();
            Dictionary<String, String> hashtable = new Dictionary<String, String>();

            entry.SetDeviceSerialPort(g_USB_SerialPort);
            entry.GetPOS_PublicKey(hashtable);
            foreach (var item in hashtable)
            {
                if (item.Key == ClassDspreadEntry.HashtableKey.pospublickey)
                {
                    textBox57.Text = item.Value;
                }
                else
                {

                }
            }
        }


        /// <summary>
        /// Non Reversible Key Generatino Procedure
        /// private function used by GetDUKPTKey
        /// </summary>
        private static void NRKGP(Byte[] key, Byte[] ksn)
        {
            Byte[] temp, key_l, key_r, key_temp;
            int i;

            temp = new Byte[8];
            key_l = new Byte[8];
            key_r = new Byte[8];
            key_temp = new Byte[8];

            Console.Write("");

            Array.Copy(key, key_temp, 8);
            for (i = 0; i < 8; i++)
                temp[i] = (byte)(ksn[i] ^ key[8 + i]);
            key_r = Util.Encrypt_ECB(key_temp, temp);
            for (i = 0; i < 8; i++)
                key_r[i] ^= key[8 + i];

            key_temp[0] ^= 0xC0;
            key_temp[1] ^= 0xC0;
            key_temp[2] ^= 0xC0;
            key_temp[3] ^= 0xC0;
            key[8] ^= 0xC0;
            key[9] ^= 0xC0;
            key[10] ^= 0xC0;
            key[11] ^= 0xC0;

            for (i = 0; i < 8; i++)
                temp[i] = (byte)(ksn[i] ^ key[8 + i]);
            key_l = Util.Encrypt_ECB(key_temp, temp);
            for (i = 0; i < 8; i++)
                key[i] = (byte)(key_l[i] ^ key[8 + i]);
            Array.Copy(key_r, 0, key, 8, 8);
        }

        /// <summary>
        /// Get current DUKPT Key by KSN
        /// Normally, DUKPT key is not directly used in encryption / decryption.
        /// Instead, key variant will be used.
        /// </summary>
        /// <param name="ksn">Key serial number(KSN). A 10 bytes data. Which use to determine which BDK will be used and calculate IPEK. With different KSN, the DUKPT system will ensure different IPEK will be generated.
        /// Normally, the first 4 digit of KSN is used to determine which BDK is used. The last 21 bit is a counter which indicate the current key.</param>
        /// <param name="ipek">IPEK.</param>
        /// <returns>DUKPT current Key (16 Bytes)</returns>
        public static Byte[] GetDUKPTKey(Byte[] ksn, Byte[] ipek)
        {
            Byte[] key;
            Byte[] cnt;
            Byte[] temp;
            Byte shift;

            key = new Byte[16];
            Array.Copy(ipek, key, 16);

            temp = new Byte[8];
            cnt = new Byte[3];
            cnt[0] = (Byte)(ksn[7] & 0x1F);
            cnt[1] = ksn[8];
            cnt[2] = ksn[9];
            Array.Copy(ksn, 2, temp, 0, 6);
            temp[5] &= 0xE0;

            shift = 0x10;
            while (shift > 0)
            {
                if ((cnt[0] & shift) > 0)
                {
                    temp[5] |= shift;
                    NRKGP(key, temp);
                }
                shift >>= 1;
            }
            shift = 0x80;
            while (shift > 0)
            {
                if ((cnt[1] & shift) > 0)
                {
                    temp[6] |= shift;
                    NRKGP(key, temp);
                }
                shift >>= 1;
            }
            shift = 0x80;
            while (shift > 0)
            {
                if ((cnt[2] & shift) > 0)
                {
                    temp[7] |= shift;
                    NRKGP(key, temp);
                }
                shift >>= 1;
            }

            return key;
        }

        /// <summary>
        /// Get current Data Key variant
        /// Data Key variant is XOR DUKPT Key with 0000 0000 00FF 0000 0000 0000 00FF 0000
        /// </summary>
        /// <param name="ksn">Key serial number(KSN). A 10 bytes data. Which use to determine which BDK will be used and calculate IPEK. With different KSN, the DUKPT system will ensure different IPEK will be generated.
        /// Normally, the first 4 digit of KSN is used to determine which BDK is used. The last 21 bit is a counter which indicate the current key.</param>
        /// <param name="ipek">IPEK (16 byte).</param>
        /// <returns>Data Key variant (16 byte)</returns>
        public static Byte[] GetDataKeyVariant(Byte[] ksn, Byte[] ipek)
        {
            Byte[] key;

            key = GetDUKPTKey(ksn, ipek);
            key[5] ^= 0xFF;
            key[13] ^= 0xFF;

            return key;
        }

        /// <summary>
        /// Get current Data Key
        /// </summary>
        /// <param name="ksn">Key serial number(KSN). A 10 bytes data. Which use to determine which BDK will be used and calculate IPEK. With different KSN, the DUKPT system will ensure different IPEK will be generated.
        /// Normally, the first 4 digit of KSN is used to determine which BDK is used. The last 21 bit is a counter which indicate the current key.</param>
        /// <param name="ipek">IPEK (16 byte).</param>
        /// <returns>Data Key (16 byte)</returns>
        public static Byte[] GetDataKey(Byte[] ksn, Byte[] ipek)
        {
            Byte[] temp1, temp2, temp3;

            temp1 = GetDataKeyVariant(ksn, ipek);
            temp2 = new Byte[16];
            Array.Copy(temp1, temp2, 16);
            temp3 = Util.Encrypt_ECB(temp2, temp1);

            return temp3;
        }

        /// <summary>
        /// Gerneate Initial PIN Encryption Key (IPEK)
        /// IPEK is use to intialize DUKPT table which will be injected into device
        /// Each device should has different IPEK
        /// </summary>
        /// <param name="ksn">Key serial number(KSN). A 10 bytes data. Which use to determine which BDK will be used and calculate IPEK. With different KSN, the DUKPT system will ensure different IPEK will be generated.
        /// Normally, the first 4 digit of KSN is used to determine which BDK is used. The last 21 bit is a counter which indicate the current key.
        /// </param>
        /// <param name="DK">Base Derivation Key(BDK). A 16 bytes data. Which use to derive IPEK and current keys.</param>
        /// <returns>IPEK. (16 bytes)</returns>
        public static Byte[] GenerateIPEK(Byte[] ksn, Byte[] DK)
        {
            Byte[] result;
            Byte[] temp, temp2, keyTemp;

            result = new Byte[16];
            temp = new Byte[8];
            keyTemp = new Byte[16];

            Array.Copy(DK, keyTemp, 16);
            Array.Copy(ksn, temp, 8);
            temp[7] &= 0xE0;
            temp2 = Util.Encrypt_ECB(keyTemp, temp);
            Array.Copy(temp2, result, 8);
            keyTemp[0] ^= 0xC0;
            keyTemp[1] ^= 0xC0;
            keyTemp[2] ^= 0xC0;
            keyTemp[3] ^= 0xC0;
            keyTemp[8] ^= 0xC0;
            keyTemp[9] ^= 0xC0;
            keyTemp[10] ^= 0xC0;
            keyTemp[11] ^= 0xC0;
            temp2 = Util.Encrypt_ECB(keyTemp, temp);
            Array.Copy(temp2, 0, result, 8, 8);

            return result;
        }

        /// <summary>
        /// Display Byte array in TextBox (in HEX)
        /// </summary>
        /// <param name="tb">TextBox</param>
        /// <param name="data">data to be displayed</param>
        private void ShowData(TextBox tb, Byte[] data)
        {
            Int32 i;

            tb.Text = "";
            i = 0;
            foreach (Byte tmp in data)
            {
                tb.Text += tmp.ToString("X2");
                i++;
            }
        }

        private void IDC_Generate_Click(object sender, EventArgs e)
        {
            Byte[] ksn, bdk, ipek;
            Byte[] baTemp;

            // get ksn and bdk from GUI and check the length of them
            ksn = Util.HexStringToByteArray(IDC_KSN.Text);
            bdk = Util.HexStringToByteArray(IDC_BDK.Text);
            ipek = Util.HexStringToByteArray(IDC_IPEK.Text);

            if (ksn.Length != 10)
            {
                MessageBox.Show("KSN should be 10 bytes", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if ((IDC_UseBDK.Checked) && (bdk.Length != 16))
            {
                MessageBox.Show("BDK should be 16 bytes", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if ((IDC_UseIPEK.Checked) && (ipek.Length != 16))
            {
                MessageBox.Show("IPEK should be 16 bytes", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //generate ipek by ksn and dbk
            if (IDC_UseBDK.Checked)
                ipek = GenerateIPEK(ksn, bdk);
            if (ipek.Length == 16)
                ShowData(IDC_IPEK, ipek);
            else
                IDC_IPEK.Text = "Error";

            //generate keys by ksn and ipek
            baTemp = GetDataKey(ksn, ipek);
            if (baTemp.Length == 16)
            {
                ShowData(IDC_DataKey, baTemp);
            }
            else
            {
                IDC_DataKey.Text = "Error";
            }

        }

        private void IDC_EncDec_Click(object sender, EventArgs e)
        {
            Byte[] key;
            Byte[] data;
            Byte[] result;

            // get key and data from GUI
            key = new Byte[8];
            if (IDC_DataKey.Text != "")
            {
                key = Util.HexStringToByteArray(IDC_DataKey.Text);
            }
            data = Util.HexStringToByteArray(IDC_Data.Text);

            IDC_Decrypt.Text = "";

            // check key and data length
            if (key.Length != 16)
            {
                IDC_Encrypt.Text = "Error";
                return;
            }
            if (((data.Length % 16) != 0) || ((data.Length % 8) != 0) || (data.Length == 0))
            {
                IDC_Encrypt.Text = "Error";
                return;
            }

            // encrypt data and display in GUI
            if (IDC_DesMode.Text == "ECB")
            {
                result = Util.Encrypt_ECB(key, data);
                ShowData(IDC_Encrypt, result);

                result = Util.Decrypt_ECB(key, data);
                ShowData(IDC_Decrypt, result);
            }
            else
            {
                byte[] IV = new byte[8];
                result = Util.Encrypt_CBC(key, data, IV);
                ShowData(IDC_Encrypt, result);

                result = Util.Decrypt_CBC(key, data, IV);
                ShowData(IDC_Decrypt, result);
            }

        }

        private void tabPage22_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            button2.Enabled = false;
            button58.Enabled = false;

            textBox2.Text = "";
            textBox1.Text = "";

            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                hashtable.Clear();
                entry.GetPOS_BT_Name(hashtable);
                foreach (var item in hashtable)
                {
                    if (item.Key == ClassDspreadEntry.HashtableKey.bluetoothname)
                    {
                        textBox2.Text = item.Value;
                    }
                    else
                    {

                    }
                }

                hashtable.Clear();
                entry.GetPOS_BT_Address(hashtable);
                foreach (var item in hashtable)
                {
                    if (item.Key == ClassDspreadEntry.HashtableKey.bluetoothaddress)
                    {
                        textBox1.Text = item.Value;
                    }
                    else
                    {

                    }
                }
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }

            button2.Enabled = true;
            button58.Enabled = true;
        }

        private void button58_Click(object sender, EventArgs e)
        {
            button2.Enabled = false;
            button58.Enabled = false;
            label16.Text = "NA";

            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                hashtable.Clear();
                hashtable.Add(ClassDspreadEntry.HashtableKey.bluetoothname, textBox2.Text);

                entry.SetPOS_BT_Name(hashtable);
                foreach (var item in hashtable)
                {
                    if (item.Key == ClassDspreadEntry.HashtableKey.result)
                    {
                        if (item.Value == "success")
                        {

                        }
                        else
                        {
                            label16.Text = "Download Bluetooth Name Failed!";
                            button2.Enabled = true;
                            button58.Enabled = true;
                            return;
                        }
                    }
                    else
                    {

                    }
                }

                hashtable.Clear();
                hashtable.Add(ClassDspreadEntry.HashtableKey.bluetoothaddress, textBox1.Text);

                entry.SetPOS_BT_Address(hashtable);
                foreach (var item in hashtable)
                {
                    if (item.Key == ClassDspreadEntry.HashtableKey.result)
                    {
                        if (item.Value == "success")
                        {
                            label16.Text = "Download Bluetooth Parameter Success!";
                            button2.Enabled = true;
                            button58.Enabled = true;
                            return;
                        }
                        else
                        {
                            label16.Text = "Download Bluetooth Address Failed!";
                            button2.Enabled = true;
                            button58.Enabled = true;
                            return;
                        }
                    }
                    else
                    {

                    }
                }
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void button59_Click(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                label17.Text = "NA";

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                hashtable.Clear();
                hashtable.Add(ClassDspreadEntry.HashtableKey.posmanageserverpublickey, textBox79.Text);
                hashtable.Add(ClassDspreadEntry.HashtableKey.factorykey, "2403");
                hashtable.Add(ClassDspreadEntry.HashtableKey.factoryparam, textBox79.Text);

                entry.SelfDestructionRepairManagePublicKey(hashtable);

                foreach (var item in hashtable)
                {
                    if (item.Key == ClassDspreadEntry.HashtableKey.result)
                    {
                        label17.Text = item.Value;
                    }
                    else
                    {

                    }
                }
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void button66_Click(object sender, EventArgs e)
        {
            textBox3.Text = string.Empty;
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                textBox3.SelectedText = dialog.FileName;
            }
        }
        private void button67_Click(object sender, EventArgs e)
        {
            //----------------------------------------------------------------------------
            //get the file path and file name
            String filePath= textBox3.Text;
            String CardFile = "card_simulation.h";
            String logkeyvalue = "";
            //第一步，创建需要的.h 文件
            //第二步，读取log文件内容，找到需要转换的数据，输出到listbox5
            //第三步，将需要的数据写到。h文件
            StreamReader sR = File.OpenText(filePath);
            string nextLine;
            FileInfo myFile = new FileInfo(CardFile);
            StreamWriter sW = myFile.CreateText();
            if (textBox4.Text != "")
            {
                logkeyvalue = textBox4.Text;
                Console.WriteLine("com_value=" + logkeyvalue);
            }
            else
            {
                 
                if (comboBox29.Text == "Lark2.0-MAG")
                {
                    comboBox30.SelectedIndex = 0;
                    logkeyvalue = comboBox30.SelectedItem.ToString();
                    Console.WriteLine("com_value=" + logkeyvalue);
                }
                else if (comboBox29.Text == "Lark2.0-ICC")
                {
                    comboBox30.SelectedIndex = 1;
                    logkeyvalue = comboBox30.SelectedItem.ToString();
                    Console.WriteLine("com_value=" + logkeyvalue);
                }
                else if (comboBox29.Text == "Lark2.0-NFC")
                {
                    comboBox30.SelectedIndex = 2;
                    logkeyvalue = comboBox30.SelectedItem.ToString();
                    Console.WriteLine("com_value=" + logkeyvalue);
                }
                else if (comboBox29.Text == "Lark3.0-MAG")
                {
                    comboBox30.SelectedIndex = 0;
                    logkeyvalue = comboBox30.SelectedItem.ToString();
                    Console.WriteLine("com_value=" + logkeyvalue);
                }
                else if (comboBox29.Text == "Lark3.0-ICC")
                {
                    comboBox30.SelectedIndex = 2;
                    logkeyvalue = comboBox30.SelectedItem.ToString();
                    Console.WriteLine("com_value=" + logkeyvalue);
                }
                else if (comboBox29.Text == "Lark3.0-NFC")
                {
                    comboBox30.SelectedIndex = 2;
                    logkeyvalue = comboBox30.SelectedItem.ToString();
                    Console.WriteLine("com_value=" + logkeyvalue);
                }
            }

            if (comboBox29.Text == "Lark2.0-MAG")
            {
                //----------------------------------
                //写入。h文件其他数据
                string[] font_strs = { "#ifndef _CARD_SIMULATION_H", "#define _CARD_SIMULATION_H\r\n", "#ifdef _CARD_SIMULATION_C", "#define GLOBAL", "#else", "#define GLOBAL  extern", "#endif\r\n", "#if defined(CFG_CARD_SIMULATION)", "const char * CardSimulationMAG_Cmd[] =", "{" };
                foreach (var s in font_strs)
                {
                    sW.WriteLine(s);
                }
                listBox5.Items.Clear();
                while ((nextLine = sR.ReadLine()) != null)
                {
                    Console.WriteLine(nextLine);
                    if (nextLine.Contains(logkeyvalue))
                    {
                        //对找到的数据做处理
                        string[] sArray = nextLine.Split(':');
                        string str = sArray[1];
                        string tSt;
                        tSt = str.Replace("H ", "");
                        //去掉空格
                        string Tarry = tSt;
                        string Tay;
                        Tay = Tarry.Replace(" ", "");
                        //将需要的数据写到指定的。h文件中
                        sW.WriteLine("  " + '"' + Tay + '"' + ',');
                        listBox5.Items.Add("[" + '"' + Tay + '"' + "]");//Tay最终数据
                        listBox5.TopIndex = listBox5.Items.Count - 1;//数据向上移动，下方会一直显示最新数据
                    }
                }

                string[] last_strs = { "  " + '"' + '"' + ',' + "\r\n" + "}" + ';' + "\r\n", "const char * CardSimulationICC_Cmd[] =", "{", "  " + '"' + '"' + ',', "}" + ';' + "\r\n", "const char * CardSimulationNFC_Cmd[] =", "{", "    " + '"' + '"' + ',', "}" + ';', "#endif" + "\r\n", "#if defined(CFG_CARD_SIMULATION)", "GLOBAL u32 CardSimulationReset(void);", "GLOBAL u32 CardSimulationMAG_ReadCommand(pu8 pCommand, u32 CommandLengthMax);", "GLOBAL u32 CardSimulationICC_ReadCommand(pu8 pCommand, u32 CommandLengthMax);", "GLOBAL u32 CardSimulationNFC_ReadCommand(pu8 pCommand, u32 CommandLengthMax);", "#endif" + "\r\n", "#undef GLOBAL", "#endif" };
                foreach (var s in last_strs)
                {
                    sW.WriteLine(s);
                }

                //---------------------------------------
            }
            else if (comboBox29.Text == "Lark2.0-ICC")
            {
                //---------------------------------------------
                //写入。h文件其他数据
                string[] font_strs = { "#ifndef _CARD_SIMULATION_H", "#define _CARD_SIMULATION_H\r\n", "#ifdef _CARD_SIMULATION_C", "#define GLOBAL", "#else", "#define GLOBAL  extern", "#endif\r\n", "#if defined(CFG_CARD_SIMULATION)", "const char * CardSimulationMAG_Cmd[] =", "{", "    " + '"' + '"' + ',', "}" + ';', "\r\n", "const char * CardSimulationICC_Cmd[] =", "{" };
                foreach (var s in font_strs)
                {
                    sW.WriteLine(s);
                }
                listBox5.Items.Clear();
                while ((nextLine = sR.ReadLine()) != null)
                {
                    Console.WriteLine(nextLine);
                    
                    Console.WriteLine(nextLine);
                    if (nextLine.Contains("ICC Send"))
                    {
                        string[] Sarray = nextLine.Split(':');
                        string sstr = Sarray[1];
                        string tSting;
                        tSting = sstr.Replace("H ", "");
                        //去掉空格
                        string Tsend = tSting;
                        string Tapdu;
                        Tapdu = Tsend.Replace(" ", "");
                        sW.WriteLine("  " + "//" + Tapdu);
                    }
                    if (nextLine.Contains(logkeyvalue))
                    {
                        //对找到的数据做处理
                        string[] sArray = nextLine.Split(':');
                        string str = sArray[1];
                        string tSt;
                        tSt = str.Replace("H ", "");
                        //去掉空格
                        string Tarry = tSt;
                        string Tay;
                        Tay = Tarry.Replace(" ", "");
                        //将需要的数据写到指定的。h文件中
                        sW.WriteLine("  " + '"' + Tay + '"' + ','+"\r\n");
                        listBox5.Items.Add("[" + '"' + Tay + '"' + "]");//Tay最终数据
                        listBox5.TopIndex = listBox5.Items.Count - 1;//数据向上移动，下方会一直显示最新数据
                    }
                }
                //sR.Close();
                string[] last_strs = { "  " + '"' + '"' + ',' + "\r\n" + "}" + ';' + "\r\n", "const char * CardSimulationNFC_Cmd[] =", "{", "    " + '"' + '"' + ',', "}" + ';', "#endif" + "\r\n", "#if defined(CFG_CARD_SIMULATION)", "GLOBAL u32 CardSimulationReset(void);", "GLOBAL u32 CardSimulationMAG_ReadCommand(pu8 pCommand, u32 CommandLengthMax);", "GLOBAL u32 CardSimulationICC_ReadCommand(pu8 pCommand, u32 CommandLengthMax);", "GLOBAL u32 CardSimulationNFC_ReadCommand(pu8 pCommand, u32 CommandLengthMax);", "#endif" + "\r\n", "#undef GLOBAL", "#endif" };
                foreach (var s in last_strs)
                {
                    sW.WriteLine(s);
                }
                //sW.Close();
                //---------------------------------------------------------
            }
            else if (comboBox29.Text == "Lark2.0-NFC")
            {
                //-----------------------------
                //写入。h文件其他数据
                string[] font_strs = { "#ifndef _CARD_SIMULATION_H", "#define _CARD_SIMULATION_H\r\n", "#ifdef _CARD_SIMULATION_C", "#define GLOBAL", "#else", "#define GLOBAL  extern", "#endif\r\n", "#if defined(CFG_CARD_SIMULATION)", "const char * CardSimulationMAG_Cmd[] =", "{", "    " + '"' + '"' + ',', "}" + ';', "\r\n", "const char * CardSimulationICC_Cmd[] =", "{", "  " + '"' + '"' + ',', "}" + ';' + "\r\n", "const char * CardSimulationNFC_Cmd[] =", "{" };
                foreach (var s in font_strs)
                {
                    sW.WriteLine(s);
                }
                listBox5.Items.Clear();
                while ((nextLine = sR.ReadLine()) != null)
                {
                    Console.WriteLine(nextLine);
                    if (nextLine.Contains("apdu:"))
                    {
                        string[] apdu = nextLine.Split(':');
                        string str = apdu[1];
                        string Aarry_apdu = "";
                        Aarry_apdu = str.Replace(" ", "");
                        //listBox5.Items.Add("[" + Aarry_apdu + "]");//Tay最终数据
                        sW.WriteLine("  " + "//" + Aarry_apdu);
                    }
                    if (nextLine.Contains(logkeyvalue))
                    {
                        //对找到的数据做处理
                        string[] sArray = nextLine.Split(':');
                        string str = sArray[1];
                        string tSt;
                        tSt = str.Replace("H", "");
                        //去掉空格
                        string Tarry = tSt;
                        string Tay;
                        Tay = Tarry.Replace(" ", "");
                        //将需要的数据写到指定的。h文件中
                        sW.WriteLine("  " + '"' + Tay + '"' + ',' + "\r\n");
                        listBox5.Items.Add("[" + Tay + "]");//Tay最终数据
                        listBox5.TopIndex = listBox5.Items.Count - 1;//数据向上移动，下方会一直显示最新数据
                    }
                }

                string[] last_strs = { "  " + '"' + '"' + ',' + "\r\n" + "}" + ';', "#endif", "\r\n", "#if defined(CFG_CARD_SIMULATION)", "GLOBAL u32 CardSimulationReset(void);", "GLOBAL u32 CardSimulationMAG_ReadCommand(pu8 pCommand, u32 CommandLengthMax);", "GLOBAL u32 CardSimulationICC_ReadCommand(pu8 pCommand, u32 CommandLengthMax);", "GLOBAL u32 CardSimulationNFC_ReadCommand(pu8 pCommand, u32 CommandLengthMax);", "#endif" + "\r\n", "#undef GLOBAL", "#endif" };
                foreach (var s in last_strs)
                {
                    sW.WriteLine(s);
                }
            
                //--------------------------------
            }
            else if (comboBox29.Text == "Lark3.0-MAG")
            {
                //----------------------------------
                //写入。h文件其他数据
                string[] font_strs = { "#ifndef _CARD_SIMULATION_H", "#define _CARD_SIMULATION_H\r\n", "#ifdef _CARD_SIMULATION_C", "#define GLOBAL", "#else", "#define GLOBAL  extern", "#endif\r\n", "#if defined(CFG_CARD_SIMULATION)", "const char * CardSimulationMAG_Cmd[] =", "{" };
                foreach (var s in font_strs)
                {
                    sW.WriteLine(s);
                }
                listBox5.Items.Clear();
                while ((nextLine = sR.ReadLine()) != null)
                {
                    Console.WriteLine(nextLine);
                    if (nextLine.Contains(logkeyvalue))
                    {
                        //对找到的数据做处理
                        string[] sArray = nextLine.Split(':');
                        string str = sArray[1];
                        string tSt;
                        tSt = str.Replace("H ", "");
                        //去掉空格
                        string Tarry = tSt;
                        string Tay;
                        Tay = Tarry.Replace(" ", "");
                        //将需要的数据写到指定的。h文件中
                        sW.WriteLine("  " + '"' + Tay + '"' + ',');
                        listBox5.Items.Add("[" + '"' + Tay + '"' + "]");//Tay最终数据
                        listBox5.TopIndex = listBox5.Items.Count - 1;//数据向上移动，下方会一直显示最新数据
                    }
                }

                string[] last_strs = { "  " + '"' + '"' + ',' + "\r\n" + "}" + ';' + "\r\n", "const char * CardSimulationICC_Cmd[] =", "{", "  " + '"' + '"' + ',', "}" + ';' + "\r\n", "const char * CardSimulationNFC_Cmd[] =", "{", "    " + '"' + '"' + ',', "}" + ';', "#endif" + "\r\n", "#if defined(CFG_CARD_SIMULATION)", "GLOBAL u32 CardSimulationReset(void);", "GLOBAL u32 CardSimulationMAG_ReadCommand(pu8 pCommand, u32 CommandLengthMax);", "GLOBAL u32 CardSimulationICC_ReadCommand(pu8 pCommand, u32 CommandLengthMax);", "GLOBAL u32 CardSimulationNFC_ReadCommand(pu8 pCommand, u32 CommandLengthMax);", "#endif" + "\r\n", "#undef GLOBAL", "#endif" };
                foreach (var s in last_strs)
                {
                    sW.WriteLine(s);
                }

                //---------------------------------------
            }
            else if (comboBox29.Text == "Lark3.0-ICC")
            {
                //---------------------------------------------
                //写入。h文件其他数据
                string[] font_strs = { "#ifndef _CARD_SIMULATION_H", "#define _CARD_SIMULATION_H\r\n", "#ifdef _CARD_SIMULATION_C", "#define GLOBAL", "#else", "#define GLOBAL  extern", "#endif\r\n", "#if defined(CFG_CARD_SIMULATION)", "const char * CardSimulationMAG_Cmd[] =", "{", "    " + '"' + '"' + ',', "}" + ';', "\r\n", "const char * CardSimulationICC_Cmd[] =", "{" };
                foreach (var s in font_strs)
                {
                    sW.WriteLine(s);
                }
                listBox5.Items.Clear();
                while ((nextLine = sR.ReadLine()) != null)
                {
                    Console.WriteLine(nextLine);
                    if (nextLine.Contains("apdu"))
                    {
                        string[] apdu = nextLine.Split(':');
                        string str = apdu[1];
                        string Aarry_apdu = "";
                        Aarry_apdu = str.Replace(" ", "");
                        sW.WriteLine("  " + "//" + Aarry_apdu);
                    }
                    if (nextLine.Contains(logkeyvalue))
                    {
                        //对找到的数据做处理
                        string[] sArray = nextLine.Split(':');
                        string str = sArray[1];
                        string tSt;
                        tSt = str.Replace("H ", "");
                        //去掉空格
                        string Tarry = tSt;
                        string Tay;
                        Tay = Tarry.Replace(" ", "");
                        //将需要的数据写到指定的。h文件中
                        sW.WriteLine("  " + '"' + Tay + '"' + ','+"\r\n");
                        listBox5.Items.Add("[" + '"' + Tay + '"' + "]");//Tay最终数据
                        listBox5.TopIndex = listBox5.Items.Count - 1;//数据向上移动，下方会一直显示最新数据
                    }
                }
                //sR.Close();
                string[] last_strs = { "  " + '"' + '"' + ',' + "\r\n" + "}" + ';' + "\r\n", "const char * CardSimulationNFC_Cmd[] =", "{", "    " + '"' + '"' + ',', "}" + ';', "#endif" + "\r\n", "#if defined(CFG_CARD_SIMULATION)", "GLOBAL u32 CardSimulationReset(void);", "GLOBAL u32 CardSimulationMAG_ReadCommand(pu8 pCommand, u32 CommandLengthMax);", "GLOBAL u32 CardSimulationICC_ReadCommand(pu8 pCommand, u32 CommandLengthMax);", "GLOBAL u32 CardSimulationNFC_ReadCommand(pu8 pCommand, u32 CommandLengthMax);", "#endif" + "\r\n", "#undef GLOBAL", "#endif" };
                foreach (var s in last_strs)
                {
                    sW.WriteLine(s);
                }
                //sW.Close();
                //---------------------------------------------------------
            }
            else if (comboBox29.Text == "Lark3.0-NFC")
            {
                //-----------------------------
                //写入。h文件其他数据
                string[] font_strs = { "#ifndef _CARD_SIMULATION_H", "#define _CARD_SIMULATION_H\r\n", "#ifdef _CARD_SIMULATION_C", "#define GLOBAL", "#else", "#define GLOBAL  extern", "#endif\r\n", "#if defined(CFG_CARD_SIMULATION)", "const char * CardSimulationMAG_Cmd[] =", "{", "    " + '"' + '"' + ',', "}" + ';', "\r\n", "const char * CardSimulationICC_Cmd[] =", "{", "  " + '"' + '"' + ',', "}" + ';' + "\r\n", "const char * CardSimulationNFC_Cmd[] =", "{" };
                foreach (var s in font_strs)
                {
                    sW.WriteLine(s);
                }
                listBox5.Items.Clear();
                while ((nextLine = sR.ReadLine()) != null)
                {
                    Console.WriteLine(nextLine);
                    Console.WriteLine(nextLine);
                    if (nextLine.Contains("apdu"))
                    {
                        string[] apdu = nextLine.Split(':');
                        string str = apdu[1];
                        string Aarry_apdu = "";
                        Aarry_apdu = str.Replace(" ", "");
                        sW.WriteLine("  " + "//" + Aarry_apdu);
                    }
                    if (nextLine.Contains(logkeyvalue))
                    {
                        //对找到的数据做处理
                        string[] sArray = nextLine.Split(':');
                        string str = sArray[1];
                        string tSt;
                        tSt = str.Replace("H", "");
                        //去掉空格
                        string Tarry = tSt;
                        string Tay;
                        Tay = Tarry.Replace(" ", "");
                        //将需要的数据写到指定的。h文件中
                        sW.WriteLine("  " + '"' + Tay + '"' + ','+"\r\n");
                        listBox5.Items.Add("[" + Tay + "]");//Tay最终数据
                        listBox5.TopIndex = listBox5.Items.Count - 1;//数据向上移动，下方会一直显示最新数据
                    }
                }

                string[] last_strs = { "  " + '"' + '"' + ',' + "\r\n" + "}" + ';', "#endif", "\r\n", "#if defined(CFG_CARD_SIMULATION)", "GLOBAL u32 CardSimulationReset(void);", "GLOBAL u32 CardSimulationMAG_ReadCommand(pu8 pCommand, u32 CommandLengthMax);", "GLOBAL u32 CardSimulationICC_ReadCommand(pu8 pCommand, u32 CommandLengthMax);", "GLOBAL u32 CardSimulationNFC_ReadCommand(pu8 pCommand, u32 CommandLengthMax);", "#endif" + "\r\n", "#undef GLOBAL", "#endif" };
                foreach (var s in last_strs)
                {
                    sW.WriteLine(s);
                }

                //--------------------------------
            }


            sR.Close();
            sW.Close();
            //=================================================================================
        }

        private void button68_Click(object sender, EventArgs e)
        {
            String xmlData = textBox5.Text;
            String pemData = "";
            if (comboBox31.Text == "Public")//Public
            {
                pemData = Xml2PemPublic(xmlData, "public.pem");//pem公钥
                textBox6.Text = pemData;
            }
            else if (comboBox31.Text == "Private")//Private
            {
                pemData = Xml2PemPrivate(xmlData, "private.pem");//pem私钥
                textBox6.Text = pemData;
                //textBox6.Text = "Please check WindowsDspreadDemo\\bin\\Debug\\privatePEM.txt";
            }
            
        }

        private void button70_Click(object sender, EventArgs e)
        {
            String xmlData = "";
            String pemData = textBox6.Text;
            if (comboBox31.Text == "Public")//Public
            {
                xmlData = Publicpemtoxml(pemData);//pem公钥
                textBox5.Text = xmlData;
            }
            else if (comboBox31.Text == "Private")//Private
            {
                textBox6.Text = string.Empty;
                String xmldata = "";
                OpenFileDialog dialog = new OpenFileDialog();
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    textBox6.SelectedText = dialog.FileName;
                    String name = dialog.FileName;
                    String pathname = GetPrivatePath(name);
                    xmldata = Privatepemtoxml(pathname);
                    //Util.SetPrivateKey(xmldata);
                }
                textBox5.Text = xmldata;
            }
            
        }
        public static byte[] IntToBytes(int value)
        {
            byte[] src = new byte[2];
            //src[3] = (byte)((value >> 24) & 0xFF);
            //src[2] = (byte)((value >> 16) & 0xFF);
            src[0] = (byte)((value >> 8) & 0xFF);
            src[1] = (byte)(value & 0xFF);
            //Console.WriteLine("src=" + Util.byteArray2Hex(src));
            return src;
        }
        private String GetHexString()
        {
            return PublicHexString;
        }
        private void SetHexString(String HexString)
        {
            PublicHexString = HexString;
        }
       

        private String GetPrivatefromhex_xml_file(String pathname)
        {
            String hexdata = "";
            RSAParameters parameters1;
            parameters1 = new RSAParameters();
            StreamReader reader1 = new StreamReader(pathname);
            XmlDocument document1 = new XmlDocument();
            document1.LoadXml(reader1.ReadToEnd());
            XmlElement element1 = (XmlElement)document1.SelectSingleNode("RSAKeyValue");
            //parameters1.Modulus = ReadChild(element1, "Modulus");
            //parameters1.Exponent = ReadChild(element1, "Exponent");
            parameters1.D = ReadChild(element1, "D");
            hexdata = Util.byteArray2Hex(parameters1.D);
            //parameters1.DP = ReadChild(element1, "DP");
            //parameters1.DQ = ReadChild(element1, "DQ");
            //parameters1.P = ReadChild(element1, "P");
            //parameters1.Q = ReadChild(element1, "Q");
            //parameters1.InverseQ = ReadChild(element1, "InverseQ");
            //CspParameters parameters2 = new CspParameters();
            //parameters2.Flags = CspProviderFlags.UseMachineKeyStore;
            //RSACryptoServiceProvider provider1 = new RSACryptoServiceProvider(parameters2);
            //provider1.ImportParameters(parameters1);
            reader1.Close();
            
            return hexdata;
        }
        private void button69_Click(object sender, EventArgs e)
        {
            String pemData = textBox6.Text;
            byte[] SN = new byte[256];
            byte[] E = new byte[4];
            if (comboBox31.Text == "Public")
            {
                SN = GetPublicFromPem(pemData);
                E = GetPublicEFromPem(pemData);
                SetHexString(Util.byteArray2Hex(SN));
                textBox7.Text = Util.byteArray2Hex(IntToBytes(SN.Length))+ Util.byteArray2Hex(SN) + Util.byteArray2Hex(IntToBytes(E.Length)) + Util.byteArray2Hex(E);
            }
            else if (comboBox31.Text == "Private")
            {
                //textBox7.Text = "Conversion of private keys from pem to hex is not supported";
                textBox6.Text = "";
                textBox6.Text = "pls select privateHex.xml file";
                OpenFileDialog dialog = new OpenFileDialog();
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    textBox6.SelectedText = dialog.FileName;
                    String name = dialog.FileName;
                    String hexstring = GetPrivatefromhex_xml_file(name);
                    textBox7.Text = hexstring;
                    textBox6.Text = "";
                    //String pathname = GetPrivatePath(name);
                    //xmldata = Privatepemtoxml(pathname);
                    //Util.SetPrivateKey(xmldata);
                }

            }
            //String pemData = textBox6.Text;
            //String HexData = "";
            //if (comboBox31.Text == "Public")//Public
            //{
            //    byte[] data = Convert.FromBase64String(pemData);
            //    HexData = Util.byteArray2Hex(data);
            //}
            //else if (comboBox31.Text == "Private")//Private
            //{
            //    byte[] data = Convert.FromBase64String(pemData);
            //    HexData = Util.byteArray2Hex(data);
            //}
            //textBox7.Text = HexData;

        }

        private void button71_Click(object sender, EventArgs e)
        {
            String HexData = textBox7.Text;
            String PemData = "";
            if (comboBox31.Text == "Public")//Public
            {
                //byte[] data = System.Text.Encoding.Default.GetBytes(HexData);
                //PemData = Convert.ToBase64String(data);
            }
            else if (comboBox31.Text == "Private")//Private
            {
                //byte[] data = System.Text.Encoding.Default.GetBytes(HexData);
                //PemData = Convert.ToBase64String(data);
            }
            textBox6.Text = PemData;
            //textBox7.Text = "Conversion of private keys from hex to pem is not supported";
        }

        private void button60_Click(object sender, EventArgs e)
        {
            if (comboBox32.Text == "XML_FILE")
            {
                RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
                using (StreamWriter writer = new StreamWriter("PrivateXMLKey.xml"))  //这个文件要保密...
                {

                    writer.WriteLine(rsa.ToXmlString(true));

                }
                using (StreamWriter writer = new StreamWriter("PublicXMLKey.xml"))
                {

                    writer.WriteLine(rsa.ToXmlString(false));

                }
            }
            else if (comboBox32.Text == "PEM_FILE")
            {
                RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
                String xmlPrivateKey = rsa.ToXmlString(true);//xml私钥
                //textBox74.Text = xmlPrivateKey;
                String pemPrivateKey = Xml2PemPrivate(xmlPrivateKey, "privatePEMKey.pem");//pem私钥
                                                                                   
                String xmlPublicKey = rsa.ToXmlString(false);//xml公钥
               // textBox59.Text = xmlPublicKey;
                String pemPublicKey = Xml2PemPublic(xmlPublicKey, "publicPEMKey.pem");//pem公钥
                                                                               
            }
            else if (comboBox32.Text == "HEX_FILE")
            {
                CreateRSAKey();
            }
           
        }

        private void button61_Click(object sender, EventArgs e)
        {
            textBox8.Text = string.Empty;
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                textBox8.SelectedText = dialog.FileName;
            }
        }

        private void button62_Click(object sender, EventArgs e)
        {
            textBox9.Text = string.Empty;
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                textBox9.SelectedText = dialog.FileName;
            }
        }
        public static string[] GenerateKeys()
        {
            string[] sKeys = new String[2];
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            sKeys[0] = rsa.ToXmlString(true);
            sKeys[1] = rsa.ToXmlString(false);
            return sKeys;
        }
       
        public void CreateRSAKey()
        {

            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            RSAParameters keys = rsa.ExportParameters(true);
            String pkxml = "<RSAKeyValue>\n<Modulus>" + ToHexString(keys.Modulus) + "</Modulus>";
            pkxml += "\n<Exponent>" + ToHexString(keys.Exponent) + "</Exponent>\n</RSAKeyValue>";
            String psxml = "<RSAKeyValue>\n<Modulus>" + ToHexString(keys.Modulus) + "</Modulus>";
            psxml += "\n<Exponent>" + ToHexString(keys.Exponent) + "</Exponent>";
            psxml += "\n<D>" + ToHexString(keys.D) + "</D>";
            psxml += "\n<DP>" + ToHexString(keys.DP) + "</DP>";
            psxml += "\n<P>" + ToHexString(keys.P) + "</P>";
            psxml += "\n<Q>" + ToHexString(keys.Q) + "</Q>";
            psxml += "\n<DQ>" + ToHexString(keys.DQ) + "</DQ>";
            psxml += "\n<InverseQ>" + ToHexString(keys.InverseQ) + "</InverseQ>\n</RSAKeyValue>";

            SaveToFile("publicHEXkey.xml", pkxml);
            SaveToFile("privateHEXkey.xml", psxml);

        }
        private void button65_Click_1(object sender, EventArgs e)
        {
            CreateRSAKey();
            //RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            //String xmlPrivateKey = rsa.ToXmlString(true);//xml私钥

            //String pemPrivateKey = Xml2PemPrivate(xmlPrivateKey, "RSA_Private.pem");//pem私钥

            //String xmlPublicKey = rsa.ToXmlString(false);//xml公钥

            //String pemPublicKey = Xml2PemPublic(xmlPublicKey, "RSA_Public.pem");//pem公钥

            //RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            //using (StreamWriter writer = new StreamWriter("PrivateKey.xml"))  //这个文件要保密...
            //{

            //    writer.WriteLine(rsa.ToXmlString(true));

            //}
            //using (StreamWriter writer = new StreamWriter("PublicKey.xml"))
            //{

            //    writer.WriteLine(rsa.ToXmlString(false));

            //}
            //string[] sKeys = new String[2];
            //sKeys = GenerateKeys();
            //textBox10.Text = sKeys[0];//公钥
            //textBox11.Text = sKeys[1];//私钥
        }
        public byte[] hexToBytes(String src)
        {
            int l = src.Length / 2;
            String str;
            byte[] ret = new byte[l];

            for (int i = 0; i < l; i++)
            {
                str = src.Substring(i * 2, 2);
                ret[i] = Convert.ToByte(str, 16);
            }
            return ret;
        }
       
        public RSACryptoServiceProvider CreateRSAEncryptProvider(String publicKeyFile)
        {
            RSAParameters parameters1;
            parameters1 = new RSAParameters();
            StreamReader reader1 = new StreamReader(publicKeyFile);
            XmlDocument document1 = new XmlDocument();
            document1.LoadXml(reader1.ReadToEnd());
            XmlElement element1 = (XmlElement)document1.SelectSingleNode("root");
            parameters1.Modulus = ReadChild(element1, "Modulus");
            parameters1.Exponent = ReadChild(element1, "Exponent");
            CspParameters parameters2 = new CspParameters();
            parameters2.Flags = CspProviderFlags.UseMachineKeyStore;
            RSACryptoServiceProvider provider1 = new RSACryptoServiceProvider(parameters2);
            provider1.ImportParameters(parameters1);
            reader1.Close();
            return provider1;
        }
        public string EnCrypt(string str)
        {
            String pathname = textBox8.Text; 
            //RSACryptoServiceProvider rsaencrype = CreateRSAEncryptProvider("publickey.xml");
            RSACryptoServiceProvider rsaencrype = CreateRSAEncryptProvider(pathname);
            String text = str;
            byte[] data = new UnicodeEncoding().GetBytes(text);
            byte[] endata = rsaencrype.Encrypt(data, true);
            return ToHexString(endata);
        }
        private void button63_Click(object sender, EventArgs e)
        {
            String data= textBox10.Text;
            textBox11.Text=EnCrypt(data);
        }
        public RSACryptoServiceProvider CreateRSADEEncryptProvider(String privateKeyFile)
        {
            RSAParameters parameters1;
            parameters1 = new RSAParameters();
            StreamReader reader1 = new StreamReader(privateKeyFile);
            XmlDocument document1 = new XmlDocument();
            document1.LoadXml(reader1.ReadToEnd());
            XmlElement element1 = (XmlElement)document1.SelectSingleNode("root");
            parameters1.Modulus = ReadChild(element1, "Modulus");
            parameters1.Exponent = ReadChild(element1, "Exponent");
            parameters1.D = ReadChild(element1, "D");
            parameters1.DP = ReadChild(element1, "DP");
            parameters1.DQ = ReadChild(element1, "DQ");
            parameters1.P = ReadChild(element1, "P");
            parameters1.Q = ReadChild(element1, "Q");
            parameters1.InverseQ = ReadChild(element1, "InverseQ");
            CspParameters parameters2 = new CspParameters();
            parameters2.Flags = CspProviderFlags.UseMachineKeyStore;
            RSACryptoServiceProvider provider1 = new RSACryptoServiceProvider(parameters2);
            provider1.ImportParameters(parameters1);
            reader1.Close();
            return provider1;
        }
        public string Decrypt(string hexstr)
        {
            String pathname = textBox9.Text;
           // RSACryptoServiceProvider rsadeencrypt = CreateRSADEEncryptProvider("privatekey.xml");
            RSACryptoServiceProvider rsadeencrypt = CreateRSADEEncryptProvider(pathname);

            byte[] miwen = hexToBytes(hexstr);

            byte[] dedata = rsadeencrypt.Decrypt(miwen, true);

            return System.Text.UnicodeEncoding.Unicode.GetString(dedata);
        }
        private void button64_Click_1(object sender, EventArgs e)
        {
            String data = textBox11.Text;
            textBox10.Text=Decrypt(data);
        }

        private void button73_Click(object sender, EventArgs e)
        {
            //ASC转txt文件
            String filePath = textBox12.Text;
            String destPath = "update.txt";
            FileStream fs = new FileStream(filePath, FileMode.Open);
            StreamWriter sW = new StreamWriter(destPath);
            //获取文件大小
            long size = fs.Length;
            //long size = 5120;
            int ret = 0;
            int fileTotalLen = 0;
            //listBox6.Items.Add("size:" + size);
            textBox13.Text = "file size=" + size;
            byte[] array = new byte[1];
            //byte[] data = new byte[384];
            //String tlvdata = "";


            //将文件读到byte数组中
            fs.Seek(0, SeekOrigin.Begin);
            if (size != 0)
            {
                while (fileTotalLen < size)
                {
                    ret = fs.Read(array, 0, array.Length);
                    String data = Util.byteArray2Hex(array);
                    fileTotalLen += array.Length;
                    //Console.WriteLine("\r\n" + data + "\r\n");
                    //char[] charArray = new char[100];
                    sW.Write(data);
                }
                textBox13.Text = "file conversion success";
                fs.Close();
                sW.Close();
            }
       }

        private void button72_Click(object sender, EventArgs e)
        {
            textBox12.Text = string.Empty;
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                textBox12.SelectedText = dialog.FileName;
            }
        }
        private void sptfile_operation(string filename,string data)
        {
            StreamWriter sW = new StreamWriter(filename);
            int len = 0;
            sW.Write(data);
            //len += data.Length;
            //if (len == 1024)
            //{
            //    sW.Close();
            //}
            sW.Close();

        }
        private void button74_Click(object sender, EventArgs e)
        {
            //将txt文件拆分
            String filePath = textBox21.Text;
            int cnt = 1;
            int len = 0;
            bool flag = false;
            FileStream fs = new FileStream(filePath, FileMode.Open);
            //StreamWriter sW = new StreamWriter(destPath);
            //获取文件大小
            long size = fs.Length;
            //long size = 1224;
            int ret = 0;
            int fileTotalLen = 0;
            //listBox6.Items.Add("size:" + size);
            textBox13.Text = "file size=" + size;
            byte[] array = new byte[1];
            //byte[] data = new byte[384];
            //String tlvdata = "";


            //将文件读到byte数组中
            fs.Seek(0, SeekOrigin.Begin);
            if (size != 0)
            {
                //flag = true;
                String filedata = "";
                while (fileTotalLen < size)
                {
                    ret = fs.Read(array, 0, array.Length);
                    String data = Util.byteArray2Hex(array);
                    fileTotalLen += array.Length;
                    len += array.Length;

                    //if (cnt * 512 == size)
                    //{
                    //    break;
                    //}
                    //else if(size-cnt*512>0 && size-cnt*512<512)
                    //{
                    //    filedata += data;
                    //    Console.WriteLine(filedata);
                    //    Console.WriteLine("len=" + len + "\r\n");
                    //    flag = true;
                    //}
                    //if (true)
                    //{
                    //    if (cnt * 512 + len < size)
                    //    {
                    //        continue;
                    //    }
                    //    else
                    //    {
                    //        String destPath = "file" + "00" + cnt + '.' + "txt";
                    //        sptfile_operation(destPath, filedata);
                    //        Console.WriteLine("splitfiledata_len=" + filedata.Length + "\r\n");
                    //    }
                    //}
                
                    
                    filedata += data;
                    Console.WriteLine(filedata);
                    Console.WriteLine("len=" + len + "\r\n");
                    if (len == 512)
                    {
                        //splitfiledata = filedata;
                        String destPath = "file" + "00" + cnt + '.' + "txt";
                        sptfile_operation(destPath, filedata);
                        Console.WriteLine("splitfiledata_len=" + filedata.Length + "\r\n");
                       
                    }
                    else if (len > 1024)
                    {
                        len = 0;
                        cnt += 1;
                        filedata = "";
                    }
                    //if (len <= 1024)
                    //{
                    //    //创建文件，写数据
                       
                    //    String destPath = "file" + "00" + cnt + '.' + "txt";
                    //    sptfile_operation(destPath, data);

                    //}
                    //else
                    //{
                    //    len = 0;
                    //    cnt++;
                       
                    //}
                    //Console.WriteLine("\r\n" + data + "\r\n");

                    //sW.Write(data);
                }
                textBox13.Text = "file conversion success";
                fs.Close();
                //sW.Close();
            }


        }

        private void button75_Click(object sender, EventArgs e)
        {
            textBox21.Text = string.Empty;
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                textBox21.SelectedText = dialog.FileName;
            }
        }

        private void button76_Click(object sender, EventArgs e)
        {
            String file_name = "";
            OpenFileDialog dialog = new OpenFileDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                file_name = dialog.FileName;
                textBox82.Text = file_name;
            }
            Console.WriteLine("file_name="+file_name+"\r\n");
        }

        private void button78_Click(object sender, EventArgs e)
        {
            textBox84.Text="";
            textBox85.Text="";
            label95.Text = "";
        }

        private void button77_Click(object sender, EventArgs e)
        {
            //textBox84.Text = "950973182317F80B950973182317F80B";
            //textBox85.Text = "00962B60AA556E65";
            //Console.WriteLine(textBox84.TextLength);
            //Console.WriteLine(textBox85.TextLength);

            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                label95.Text = "";
                if (Encoding.Default.GetByteCount(textBox84.Text) != 32 || Encoding.Default.GetByteCount(textBox85.Text) != 16)
                {
                    label95.Text = "input length error !";
                    return;
                }
                else
                {

                }

                hashtable.Add(ClassDspreadEntry.HashtableKey.tmkvalue, textBox84.Text);
                hashtable.Add(ClassDspreadEntry.HashtableKey.tmkcheckvalue, textBox85.Text);
                hashtable.Add(ClassDspreadEntry.HashtableKey.tmkindex, comboBox33.Text);

                entry.SetDeviceSerialPort(g_USB_SerialPort);
                entry.InjectKeyCommand_10E4(hashtable);

                foreach (var item in hashtable)
                {
                    if (item.Key == ClassDspreadEntry.HashtableKey.resultmessage)
                    {
                        label95.Text = item.Value;
                        break;
                    }
                    else
                    {

                    }
                }
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
            //----------------------------------------------------
        }
        private bool Const_To_bin(String filename)
        {
            //String CardFile = "data.bin";
            String logkeyvalue = "0x";
            String Strstr = "";
            StreamReader sR = File.OpenText(filename);
            string nextLine;
            //FileInfo myFile = new FileInfo(CardFile);
            BinaryWriter sW =new BinaryWriter(new FileStream("data.bin",FileMode.Create));

            while ((nextLine = sR.ReadLine()) != null)
            {
                if (nextLine.Contains(logkeyvalue))
                {
                    //对找到的数据做处理
                    //Console.WriteLine(nextLine);
                    String txt = nextLine.Replace(", ", "");
                    String strtxt = txt.Replace("0x","");
                    String stxt = strtxt.Replace(",", "");
                    Strstr += stxt;
                    //Console.WriteLine("stxt="+stxt);
                    //string[] sArray = txt.Split(',');
                    //string str = sArray[1];
                    //Console.WriteLine(str);
                    //string tSt;
                    
                    //tSt = str.Replace("0x", "");
                    //Strstr += tSt;
                   
                    //byte[] array = Encoding.UTF8.GetBytes(tSt);

                    //sW.Write(array, 0,array.Length);
                    //string[] sArray = nextLine.Split(',');
                    //string str = sArray[1];
                    //Console.WriteLine("str="+str+"\r\n");
                    //string tSt;
                    //tSt = str.Replace("H ", "");
                    //去掉空格
                    //string Tarry = tSt;
                    //string Tay;
                    //Tay = Tarry.Replace(" ", "");
                    //将需要的数据写到指定的。h文件中
                    //sW.WriteLine("  " + '"' + Tay + '"' + ',');
                    //listBox5.Items.Add("[" + '"' + Tay + '"' + "]");//Tay最终数据
                    //listBox5.TopIndex = listBox5.Items.Count - 1;//数据向上移动，下方会一直显示最新数据
                }
            }
            Console.WriteLine("Strstr"+Strstr);
            //byte[] array = Encoding.UTF8.GetBytes(Strstr);
            byte[] array = Util.HexStringToByteArray(Strstr);
            sW.Write(array, 0, array.Length);
            sW.Close();
            return true;
        }
        private void button79_Click(object sender, EventArgs e)
        {
            String Filename = textBox82.Text;
            bool res = false;
            res=Const_To_bin(Filename);
            if (res)
            {
                label97.Text = "SUCCESS";
            }
            else
            {
                label97.Text = "Failed";
            }

        }
       
       
        //private static void GPOS_Read()
        //{
        //    //destPath:读出来的文件
        //    String destPath = "upgrader.asc";
        //    //fileName：GPOS里要读取的目标文件
        //    String fileName = "upgrader.asc";

        //    if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
        //    {
        //        int ReadLen = 0;
        //        int fileLen = 0;
        //        int ReadTotalLen = 0;
        //        //int DestFileLen = 27089;
        //        int DestFileLen = 0;
        //        int ReadOnetimeLen;
        //        ClassDspreadEntry entry = new ClassDspreadEntry();
        //        Dictionary<String, String> hashtable = new Dictionary<String, String>();

        //        entry.SetDeviceSerialPort(g_USB_SerialPort);

        //        String foldername = "Z:\\\\*";
        //        hashtable.Add("FileName", foldername);
        //        DestFileLen = entry.dock_Getfilesize(hashtable);
        //        Console.WriteLine("fileLen=" + DestFileLen + "\r\n");
        //        if (fileLen < 0)
        //        {
        //            Console.WriteLine("Get file size failed" + "\r\n");
        //            return;
        //        }
        //        else
        //        {
        //            Console.WriteLine("Get File size=" + fileLen + "\r\n");
        //            //Console.WriteLine("File_size=" + Util.byteArrayToInt(filelen));
        //        }

        //        hashtable.Clear();
        //        hashtable.Add("FileName", fileName);
        //        Console.WriteLine("filename=" + fileName + "\r\n");
        //        //创建目标文件文件
        //        //StreamWriter sW = new StreamWriter(destPath);
        //        FileStream fs = new FileStream(destPath, FileMode.Create);

        //        int fd = 0;

        //        hashtable.Add("Mode", "rb+");
        //        fd = entry.dock_fopen(hashtable);
        //        if (fd < 0)
        //        {
        //            //textBox83.Text += "fopen filed! fd = " + fd.ToString() + "\r\n";
                  
        //            Console.WriteLine("fopen filed! fd = " + fd.ToString() + "\r\n");
        //            return;
        //        }
        //        else
        //        {
        //            hashtable.Add("fd", fd.ToString());
        //            Console.WriteLine("fd=" + fd.ToString() + "\r\n");
        //        }

             

        //        while (true)
        //        {
        //            if (ReadTotalLen <= DestFileLen && ReadTotalLen + 512 <= DestFileLen)
        //            {
        //                ReadOnetimeLen = 512;

        //            }
        //            else
        //            {
        //                ReadOnetimeLen = DestFileLen - ReadTotalLen;
        //            }
        //            Byte[] fileDate = new Byte[ReadOnetimeLen];
        //            Console.WriteLine("           [ReadOnetimeLen]=" + ReadOnetimeLen + "\r\n");
        //            Console.WriteLine("           [ReadTotalLen]=" + ReadTotalLen + "\r\n");
        //            Console.WriteLine("           [DestFileLen]=" + DestFileLen + "\r\n");
        //            hashtable.Add("FileContent", "");
        //            hashtable.Add("FileContentLen", Convert.ToString(ReadOnetimeLen));
        //            Console.WriteLine("FileContentLen=" + Convert.ToString(ReadOnetimeLen) + "\r\n");
        //            ReadLen = entry.dock_fread(hashtable, fileDate, ReadOnetimeLen);
        //            if (ReadLen < 0)
        //            {
        //                //textBox83.Text += "dock_fread error!\r\n";
        //                Console.WriteLine("dock_fread error!\r\n");
        //                break;
        //            }
        //            else if (ReadLen < 1)
        //            {
        //                //textBox83.Text += "not all byte ! Readlen " + ReadLen + "\r\n";
        //                if (ReadLen == 0)
        //                {
        //                    //textBox83.Text += "read all byte complete: " + ReadTotalLen + "!\r\n";
        //                    Console.WriteLine("read all byte complete: " + ReadTotalLen + "!\r\n");
        //                    break;
        //                }
        //            }
        //            else
        //            {
        //                Console.WriteLine("ReadLen=" + ReadLen + "\r\n");
        //                Console.WriteLine("[data]=" + Util.byteArray2Hex(fileDate));
        //                fs.Write(fileDate, 0, fileDate.Length);
        //            }
        //            ReadTotalLen += ReadLen;
        //            Console.WriteLine("ReadTotalLen=" + ReadTotalLen + "\r\n");

        //        }

        //        entry.dock_close(hashtable);
        //        fs.Close();


        //    }
        //    else
        //    {
        //        //textBox83.Text += "No equipment found!\r\n";
        //        Console.WriteLine("No equipment found!\r\n");
        //        return;
        //    }
        //}
        private void Read_ASC_File(String filename)
        {
            Console.WriteLine("filename=" + filename + "\r\n");
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                int ReadLen = 0;
                int ReadTotalLen = 0;
                int DestFileLen = 0;
                int ReadOnetimeLen;
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                String foldername = "Z:\\\\*";
                hashtable.Add("FileName", foldername);
                DestFileLen = entry.dock_Getfilesize(hashtable,filename);
                Console.WriteLine("fileLen=" + DestFileLen + "\r\n");
                if (DestFileLen < 0)
                {
                    Console.WriteLine("Get file size failed" + "\r\n");
                    textBox83.Text += "Get File size failed:" + filename + "\r\n";
                    return;
                }
                else
                {
                    Console.WriteLine("Get File size=" + DestFileLen + "\r\n");
                    //Console.WriteLine("File_size=" + Util.byteArrayToInt(filelen));
                }

                hashtable.Clear();
                hashtable.Add("FileName", filename);
                Console.WriteLine("filename=" + filename + "\r\n");
                //创建目标文件文件
                FileStream fs = new FileStream(filename, FileMode.Create);

                int fd = 0;

                hashtable.Add("Mode", "rb+");
                fd = entry.dock_fopen(hashtable);
                if (fd < 0)
                {
                    textBox83.Text += "fopen filed! fd = " + fd.ToString() + "\r\n";

                    //Console.WriteLine("fopen filed! fd = " + fd.ToString() + "\r\n");
                    return;
                }
                else
                {
                    hashtable.Add("fd", fd.ToString());
                    //Console.WriteLine("fd=" + fd.ToString() + "\r\n");
                }
                progressBar1.Maximum = DestFileLen;
                progressBar1.Minimum = 0;

                while (true)
                {
                    if (ReadTotalLen <= DestFileLen && ReadTotalLen + 512 <= DestFileLen)
                    {
                        ReadOnetimeLen = 512;

                    }
                    else
                    {
                        ReadOnetimeLen = DestFileLen - ReadTotalLen;
                    }
                    Byte[] fileDate = new Byte[ReadOnetimeLen];
                    //Console.WriteLine("           [ReadOnetimeLen]=" + ReadOnetimeLen + "\r\n");
                    //Console.WriteLine("           [ReadTotalLen]=" + ReadTotalLen + "\r\n");
                    //Console.WriteLine("           [DestFileLen]=" + DestFileLen + "\r\n");
                    hashtable.Add("FileContent", "");
                    hashtable.Add("FileContentLen", Convert.ToString(ReadOnetimeLen));
                    //Console.WriteLine("FileContentLen=" + Convert.ToString(ReadOnetimeLen) + "\r\n");
                    ReadLen = entry.dock_fread(hashtable, fileDate, ReadOnetimeLen);
                    if (ReadLen < 0)
                    {
                        textBox83.Text += "dock_fread error!\r\n";
                        break;
                    }
                    else if (ReadLen < 1)
                    {
                        if (ReadLen == 0)
                        {
                            //textBox83.Text += "read all byte complete: " + ReadTotalLen + "!\r\n";
                            break;
                        }
                    }
                    else
                    {
                        fs.Write(fileDate, 0, fileDate.Length);
                    }
                    ReadTotalLen += ReadLen;
                    progressBar1.Value = ReadTotalLen;
                    if (ReadTotalLen == DestFileLen)
                    {
                        textBox83.Text += "reading File:        " + filename + "   size:      " + ReadTotalLen + "\r\n";
                    }
                    //textBox83.Text += "reading File:      " + destPath +"       size:     "+ ReadTotalLen + "!\r\n";

                }

                entry.dock_close(hashtable);
                fs.Close();


            }
            else
            {
                MessageBox.Show("Terminal not connected!");
                return;
            }
        }
        private void Read_Txt_File(String filename)
        {
            Console.WriteLine("filename=" + filename + "\r\n");
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                int ReadLen = 0;
                int ReadTotalLen = 0;
                //int DestFileLen = 27089;
                int DestFileLen = 0;
                int ReadOnetimeLen;
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                entry.SetDeviceSerialPort(g_USB_SerialPort);

                String foldername = "Z:\\\\*";
                hashtable.Add("FileName", foldername);
                DestFileLen = entry.dock_Getfilesize(hashtable,filename);
                Console.WriteLine("fileLen=" + DestFileLen + "\r\n");
                if (DestFileLen < 0)
                {
                    Console.WriteLine("Get file size failed" + "\r\n");
                    textBox83.Text += "Get File size failed:" + filename + "\r\n";
                    return;
                }
                else
                {
                    Console.WriteLine("Get File size=" + DestFileLen + "\r\n");
                    //Console.WriteLine("File_size=" + Util.byteArrayToInt(filelen));
                }

                hashtable.Clear();
                hashtable.Add("FileName", filename);
                Console.WriteLine("filename=" + filename + "\r\n");
                //创建目标文件文件
                StreamWriter sW = new StreamWriter(filename);
               

                int fd = 0;

                hashtable.Add("Mode", "rb+");
                fd = entry.dock_fopen(hashtable);
                if (fd < 0)
                {
                    textBox83.Text += "fopen filed! fd = " + fd.ToString() + "\r\n";

                    //Console.WriteLine("fopen filed! fd = " + fd.ToString() + "\r\n");
                    return;
                }
                else
                {
                    hashtable.Add("fd", fd.ToString());
                    //Console.WriteLine("fd=" + fd.ToString() + "\r\n");
                }
                progressBar1.Maximum = DestFileLen;
                progressBar1.Minimum = 0;

                while (true)
                {
                    if (ReadTotalLen <= DestFileLen && ReadTotalLen + 512 <= DestFileLen)
                    {
                        ReadOnetimeLen = 512;

                    }
                    else
                    {
                        ReadOnetimeLen = DestFileLen - ReadTotalLen;
                    }
                    Byte[] fileDate = new Byte[ReadOnetimeLen];
                    //Console.WriteLine("           [ReadOnetimeLen]=" + ReadOnetimeLen + "\r\n");
                    //Console.WriteLine("           [ReadTotalLen]=" + ReadTotalLen + "\r\n");
                    //Console.WriteLine("           [DestFileLen]=" + DestFileLen + "\r\n");
                    hashtable.Add("FileContent", "");
                    hashtable.Add("FileContentLen", Convert.ToString(ReadOnetimeLen));
                    //Console.WriteLine("FileContentLen=" + Convert.ToString(ReadOnetimeLen) + "\r\n");
                    ReadLen = entry.dock_fread(hashtable, fileDate, ReadOnetimeLen);
                    if (ReadLen < 0)
                    {
                        textBox83.Text += "dock_fread error!\r\n";
                        break;
                    }
                    else if (ReadLen < 1)
                    {
                        if (ReadLen == 0)
                        {
                            //textBox83.Text += "read all byte complete: " + ReadTotalLen + "!\r\n";
                            break;
                        }
                    }
                    else
                    {
                        //fs.Write(fileDate, 0, fileDate.Length);
                        sW.Write(System.Text.Encoding.ASCII.GetString(fileDate));
                    }
                    ReadTotalLen += ReadLen;
                    progressBar1.Value = ReadTotalLen;
                    if (ReadTotalLen == DestFileLen)
                    {
                        textBox83.Text += "reading File:        " + filename + "   size:      " + ReadTotalLen + "\r\n";
                    }
                    //textBox83.Text += "reading File:      " + destPath +"       size:     "+ ReadTotalLen + "!\r\n";

                }

                entry.dock_close(hashtable);
                sW.Close();


            }
            else
            {
                MessageBox.Show("Terminal not connected!");
                return;
            }
        }
        private void button80_Click(object sender, EventArgs e)
        {
            /*******d读GD文件******/
            //文件操作线程
            //Thread t = new Thread(new ThreadStart(GPOS_Read));
            //t.IsBackground = true;
            //t.Start();
            //textBox83.Text += "read all byte complete"+"\r\n";
            //destPath:读出来的文件
            String filename = textBox69.Text;
            string[] TArray = filename.Split('.');
            if (TArray[1] == "txt")
            {
                Console.WriteLine("File_Type=" + TArray[1] + "\r\n");
                Read_Txt_File(filename);
            }
            else 
            {
                Console.WriteLine("File_Type=" + TArray[1] + "\r\n");
                Read_ASC_File(filename);
            }

            

        }

        private void button81_Click(object sender, EventArgs e)
        {
            String hexstr = textBox87.Text;
            BinaryWriter sW = new BinaryWriter(new FileStream("key.bin", FileMode.Create));
            byte[] array = Util.HexStringToByteArray(hexstr);
            Console.WriteLine("array.Length="+array.Length+"\r\n");
            sW.Write(array, 0, array.Length);
            sW.Close();
            label98.Text = "success";


        }

        private void textBox71_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void button35_Click_1(object sender, EventArgs e)
        {
            //端口判断
            if (g_USB_SerialPort == null || !g_USB_SerialPort.IsOpen)
            {
                MessageBox.Show("Terminal not connected!");
                return;
            }
            else
            {

            }

            textBox54.Text = "";

            ClassDspreadEntry entry = new ClassDspreadEntry();
            Dictionary<String, String> hashtable = new Dictionary<String, String>();
            Dictionary<String, String> hashtable_parameters = new Dictionary<String, String>();
            String PlarformVersionNumber = "";
            String PlarformVersionNumberFormXML = "";
            String TempString = "";
            XmlNodeList NodeList;
            XmlNodeList TAG_List;
            XmlElement NodeElement;

            //创建必要临时文件
            XmlDocument xmldoc = new XmlDocument();

            OpenFileDialog dialog = new OpenFileDialog();
            dialog.CheckFileExists = false;
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                xmldoc.Load(dialog.FileName);
            }
            else
            {
                xmldoc.Load(System.Windows.Forms.Application.StartupPath + "/" + "temp_emv_configuration.xml");
            }

            TempString = "";

            NodeList = xmldoc.SelectSingleNode("EMV_Configuration").ChildNodes;

            if (NodeList.Count == 0)
            {
                MessageBox.Show("ERROR: EMV_Configuration node not found!");
                return;
            }
            else
            {

            }

            foreach (XmlNode node in NodeList)
            {
                NodeElement = (XmlElement)node;
                if (NodeElement.Name == "CustomerTree")
                {
                    TempString = node.Value;
                    NodeList = NodeElement.ChildNodes;
                    break;
                }
                else
                {

                }
            }

            if (TempString == "")
            {
                MessageBox.Show("ERROR: CustomerTree node not found!");
                return;
            }
            else
            {

            }

            foreach (XmlNode node in NodeList)
            {
                NodeElement = (XmlElement)node;
                if (NodeElement.Name == "PlatformVersionNumber")
                {
                    PlarformVersionNumberFormXML = NodeElement.InnerText;
                }
            }

            //获取平台版本
            hashtable.Clear();
            entry.SetDeviceSerialPort(g_USB_SerialPort);
            entry.GetQPOS_PlatformVersionNumber(hashtable);
            foreach (var item in hashtable)
            {
                if (item.Key == ClassDspreadEntry.HashtableKey.posplatformversionnumber)
                {
                    PlarformVersionNumber = item.Value;
                    break;
                }
                else
                {

                }
            }

            if (PlarformVersionNumber == "")
            {
                MessageBox.Show("ERROR: Platform version number geting failed!");
                return;
            }
            else
            {

            }

            //检查xml文件版本是否与终端相匹配
            if (PlarformVersionNumberFormXML == PlarformVersionNumber)
            {

            }
            else if (PlarformVersionNumberFormXML == "Lark2.0" && PlarformVersionNumber == "Lark3.0")
            {
                MessageBox.Show("ERROR: XML platform version number is Lark2.0 but terminal is Lark3.0");
                return;
            }
            else if (PlarformVersionNumberFormXML == "Lark3.0" && PlarformVersionNumber == "Lark2.0")
            {
                MessageBox.Show("ERROR: XML platform version number is Lark3.0 but terminal is Lark2.0");
                return;
            }
            else
            {
                MessageBox.Show("ERROR: Unknown platform version number");
                return;
            }

            //获取xml文件中的应用节点
            NodeList = xmldoc.SelectSingleNode("EMV_Configuration").ChildNodes;

            if (NodeList.Count == 0)
            {
                MessageBox.Show("ERROR: EMV_Configuration node not found!");
                return;
            }
            else
            {

            }

            foreach (XmlNode node in NodeList)
            {
                NodeElement = (XmlElement)node;
                if (NodeElement.Name == "AppTree")
                {
                    TempString = node.Value;
                    NodeList = NodeElement.ChildNodes;
                    break;
                }
            }

            if (TempString == "")
            {
                MessageBox.Show("ERROR: AppTree node not found!");
                return;
            }
            else
            {

            }

            foreach (XmlNode node in NodeList)
            {
                //获取第一个App节点
                NodeElement = (XmlElement)node;
                if (NodeElement.Name != "App")
                {
                    MessageBox.Show("ERROR: Found a unknown node in AppTree!");
                    return;
                }
                else
                {
                    TAG_List = NodeElement.ChildNodes;
                }

                //遍历App中的所有TAG，并放到TLV数据包中
                byte[] TLV_Buffer = new byte[512];
                String TLV_String = "";

                foreach (XmlNode TAG in TAG_List)
                {
                    NodeElement = (XmlElement)TAG;
                    TLV tlv = new TLV();
                    uint t = (uint)Util.byteArrayToInt(Util.HexStringToByteArray(TAG.Name.Substring(1, TAG.Name.Length - 1)));
                    byte[] v = Util.HexStringToByteArray(TAG.InnerText);
                    tlv.tlv_new(TLV_Buffer, t, (uint)v.Length, v);
                    byte[] TLV_BufferOneTAG = tlv.tlv_find(TLV_Buffer, t);
                    String sTLV = Util.byteArray2Hex(TLV_BufferOneTAG);
                    TLV_String += sTLV;
                }

                textBox54.Text += "App TLV String From XML:\r\n";
                textBox54.Text += TLV_String;
                textBox54.Text += "\r\n";
                textBox54.SelectionStart = textBox54.Text.Length;
                textBox54.ScrollToCaret();

                //添加该App到终端中
                hashtable.Clear();
                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "02");
                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtlv, TLV_String);
                entry.SetDeviceSerialPort(g_USB_SerialPort);

                if (entry.UpdateEmvApp(hashtable) == false)
                {
                    foreach (var item in hashtable)
                    {
                        if (item.Key == ClassDspreadEntry.HashtableKey.result)
                        {
                            MessageBox.Show("ERROR: UpdateEmvApp Failed : " + item.Value);
                            return;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {

                }
            }

            //获取xml文件中的应用节点
            NodeList = xmldoc.SelectSingleNode("EMV_Configuration").ChildNodes;

            if (NodeList.Count == 0)
            {
                MessageBox.Show("ERROR: EMV_Configuration node not found!");
                return;
            }
            else
            {

            }

            foreach (XmlNode node in NodeList)
            {
                NodeElement = (XmlElement)node;
                if (NodeElement.Name == "CAPK_Tree")
                {
                    TempString = node.Value;
                    NodeList = NodeElement.ChildNodes;
                    break;
                }
            }

            if (TempString == "")
            {
                MessageBox.Show("ERROR: CAPK_Tree node not found!");
                return;
            }
            else
            {

            }

            foreach (XmlNode node in NodeList)
            {
                //获取第一个Capk节点
                NodeElement = (XmlElement)node;
                if (NodeElement.Name != "Capk")
                {
                    MessageBox.Show("ERROR: Found a unknown node in AppTree!");
                    return;
                }
                else
                {
                    TAG_List = NodeElement.ChildNodes;
                }

                //遍历Capk中的所有TAG，并放到TLV数据包中
                byte[] TLV_Buffer = new byte[512];
                String TLV_String = "";

                foreach (XmlNode TAG in TAG_List)
                {
                    NodeElement = (XmlElement)TAG;
                    TLV tlv = new TLV();
                    uint t = (uint)Util.byteArrayToInt(Util.HexStringToByteArray(TAG.Name.Substring(1, TAG.Name.Length - 1)));
                    byte[] v = Util.HexStringToByteArray(TAG.InnerText);
                    tlv.tlv_new(TLV_Buffer, t, (uint)v.Length, v);
                    byte[] TLV_BufferOneTAG = tlv.tlv_find(TLV_Buffer, t);
                    String sTLV = Util.byteArray2Hex(TLV_BufferOneTAG);
                    TLV_String += sTLV;
                }

                textBox54.Text += "Capk TLV String From XML:\r\n";
                textBox54.Text += TLV_String;
                textBox54.Text += "\r\n";
                textBox54.SelectionStart = textBox54.Text.Length;
                textBox54.ScrollToCaret();

                //添加该Capk到终端中
                hashtable.Clear();
                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtype, "02");
                hashtable.Add(ClassDspreadEntry.HashtableKey.transactionupdateemvparamtlv, TLV_String);
                entry.SetDeviceSerialPort(g_USB_SerialPort);

                if (entry.UpdateEmvCapk(hashtable) == false)
                {
                    foreach (var item in hashtable)
                    {
                        if (item.Key == ClassDspreadEntry.HashtableKey.result)
                        {
                            MessageBox.Show("ERROR: UpdateEmvCapk Failed : " + item.Value);
                            return;
                        }
                        else
                        {

                        }
                    }
                }
                else
                {

                }
            }

            MessageBox.Show("Download Success!");
        }

        private void button40_Click_1(object sender, EventArgs e)
        {
            if (g_USB_SerialPort != null && g_USB_SerialPort.IsOpen)
            {
                ClassDspreadEntry entry = new ClassDspreadEntry();
                Dictionary<String, String> hashtable = new Dictionary<String, String>();

                label103.Text = "";
                if (Encoding.Default.GetByteCount(textBox90.Text) != 32 || Encoding.Default.GetByteCount(textBox91.Text) != 16)
                {
                    label103.Text = "input length error !";
                    return;
                }
                else
                {

                }

                hashtable.Add(ClassDspreadEntry.HashtableKey.tmkvalue, textBox90.Text);
                hashtable.Add(ClassDspreadEntry.HashtableKey.tmkcheckvalue, textBox91.Text);
                hashtable.Add(ClassDspreadEntry.HashtableKey.tmkindex, comboBox34.Text);

                entry.SetDeviceSerialPort(g_USB_SerialPort);
                entry.InjectKeyCommand_10E2(hashtable);

                foreach (var item in hashtable)
                {
                    if (item.Key == ClassDspreadEntry.HashtableKey.resultmessage)
                    {
                        label103.Text = item.Value;
                        break;
                    }
                    else
                    {

                    }
                }
            }
            else
            {
                MessageBox.Show("Terminal not connected!");
            }
        }

        private void button82_Click(object sender, EventArgs e)
        {
            textBox90.Text = "";
            textBox91.Text = "";
            label103.Text = "";
        }
    }
}

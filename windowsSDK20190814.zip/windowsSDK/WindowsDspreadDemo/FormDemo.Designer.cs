﻿namespace WindowsDspreadDemo
{
    partial class FormDemo
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.TRADE = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.comboBox28 = new System.Windows.Forms.ComboBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.label23 = new System.Windows.Forms.Label();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.label24 = new System.Windows.Forms.Label();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.comboBox13 = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.comboBox17 = new System.Windows.Forms.ComboBox();
            this.comboBox16 = new System.Windows.Forms.ComboBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.button20 = new System.Windows.Forms.Button();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.button13 = new System.Windows.Forms.Button();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.button22 = new System.Windows.Forms.Button();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.comboBox20 = new System.Windows.Forms.ComboBox();
            this.comboBox19 = new System.Windows.Forms.ComboBox();
            this.comboBox18 = new System.Windows.Forms.ComboBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.button21 = new System.Windows.Forms.Button();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.button24 = new System.Windows.Forms.Button();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.button23 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.tabPage20 = new System.Windows.Forms.TabPage();
            this.label83 = new System.Windows.Forms.Label();
            this.comboBox27 = new System.Windows.Forms.ComboBox();
            this.button56 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.button7 = new System.Windows.Forms.Button();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.label55 = new System.Windows.Forms.Label();
            this.comboBox15 = new System.Windows.Forms.ComboBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.comboBox14 = new System.Windows.Forms.ComboBox();
            this.button8 = new System.Windows.Forms.Button();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.label49 = new System.Windows.Forms.Label();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.button57 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.label69 = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.textBox88 = new System.Windows.Forms.TextBox();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.label96 = new System.Windows.Forms.Label();
            this.button43 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.comboBox26 = new System.Windows.Forms.ComboBox();
            this.label67 = new System.Windows.Forms.Label();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.comboBox25 = new System.Windows.Forms.ComboBox();
            this.comboBox23 = new System.Windows.Forms.ComboBox();
            this.label66 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.comboBox24 = new System.Windows.Forms.ComboBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.button42 = new System.Windows.Forms.Button();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.tabPage27 = new System.Windows.Forms.TabPage();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.comboBox33 = new System.Windows.Forms.ComboBox();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.button78 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.label93 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.tabPage28 = new System.Windows.Forms.TabPage();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.label103 = new System.Windows.Forms.Label();
            this.button82 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.comboBox34 = new System.Windows.Forms.ComboBox();
            this.label102 = new System.Windows.Forms.Label();
            this.textBox91 = new System.Windows.Forms.TextBox();
            this.textBox90 = new System.Windows.Forms.TextBox();
            this.label101 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button35 = new System.Windows.Forms.Button();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.button34 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.comboBox21 = new System.Windows.Forms.ComboBox();
            this.button27 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.button41 = new System.Windows.Forms.Button();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button11 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button3 = new System.Windows.Forms.Button();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.button80 = new System.Windows.Forms.Button();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.button50 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.label71 = new System.Windows.Forms.Label();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.button47 = new System.Windows.Forms.Button();
            this.label70 = new System.Windows.Forms.Label();
            this.button46 = new System.Windows.Forms.Button();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.button45 = new System.Windows.Forms.Button();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.comboBox22 = new System.Windows.Forms.ComboBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.button36 = new System.Windows.Forms.Button();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.button52 = new System.Windows.Forms.Button();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.label73 = new System.Windows.Forms.Label();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.button51 = new System.Windows.Forms.Button();
            this.label72 = new System.Windows.Forms.Label();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.IDC_Data = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.IDC_DesMode = new System.Windows.Forms.ComboBox();
            this.IDC_Decrypt = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.IDC_Encrypt = new System.Windows.Forms.TextBox();
            this.IDC_EncDec = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.IDC_UseBDK = new System.Windows.Forms.RadioButton();
            this.IDC_UseIPEK = new System.Windows.Forms.RadioButton();
            this.IDC_BDK = new System.Windows.Forms.TextBox();
            this.IDC_KSN = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.IDC_IPEK = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.IDC_Generate = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.IDC_DataKey = new System.Windows.Forms.TextBox();
            this.tabPage23 = new System.Windows.Forms.TabPage();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.comboBox30 = new System.Windows.Forms.ComboBox();
            this.comboBox29 = new System.Windows.Forms.ComboBox();
            this.listBox5 = new System.Windows.Forms.ListBox();
            this.button67 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.tabPage24 = new System.Windows.Forms.TabPage();
            this.comboBox32 = new System.Windows.Forms.ComboBox();
            this.label90 = new System.Windows.Forms.Label();
            this.button60 = new System.Windows.Forms.Button();
            this.label88 = new System.Windows.Forms.Label();
            this.comboBox31 = new System.Windows.Forms.ComboBox();
            this.label84 = new System.Windows.Forms.Label();
            this.button71 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.label63 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.tabPage21 = new System.Windows.Forms.TabPage();
            this.button65 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label89 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.button62 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.tabPage25 = new System.Windows.Forms.TabPage();
            this.button75 = new System.Windows.Forms.Button();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.button74 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.tabPage26 = new System.Windows.Forms.TabPage();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.label98 = new System.Windows.Forms.Label();
            this.button81 = new System.Windows.Forms.Button();
            this.textBox87 = new System.Windows.Forms.TextBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.label97 = new System.Windows.Forms.Label();
            this.button79 = new System.Windows.Forms.Button();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.button76 = new System.Windows.Forms.Button();
            this.tabPage19 = new System.Windows.Forms.TabPage();
            this.textBox89 = new System.Windows.Forms.TextBox();
            this.label99 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.button59 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.label81 = new System.Windows.Forms.Label();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.textBox79 = new System.Windows.Forms.TextBox();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.label80 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.tabPage22 = new System.Windows.Forms.TabPage();
            this.label16 = new System.Windows.Forms.Label();
            this.button58 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button12 = new System.Windows.Forms.Button();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.TRADE.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.tabPage20.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tabPage13.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.tabPage27.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.tabPage28.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage17.SuspendLayout();
            this.tabPage14.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage15.SuspendLayout();
            this.tabPage16.SuspendLayout();
            this.tabPage18.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.tabPage23.SuspendLayout();
            this.tabPage24.SuspendLayout();
            this.tabPage21.SuspendLayout();
            this.tabPage25.SuspendLayout();
            this.tabPage26.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.tabPage19.SuspendLayout();
            this.tabPage22.SuspendLayout();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(68, 30);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(100, 26);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(68, 264);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(102, 34);
            this.button1.TabIndex = 0;
            this.button1.Text = "OPEN";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 34);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 18);
            this.label1.TabIndex = 2;
            this.label1.Text = "PORT";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(68, 69);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(100, 26);
            this.comboBox2.TabIndex = 3;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 74);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 18);
            this.label2.TabIndex = 4;
            this.label2.Text = "BAUD";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 112);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "DBIT";
            // 
            // comboBox3
            // 
            this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(68, 108);
            this.comboBox3.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(100, 26);
            this.comboBox3.TabIndex = 6;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 152);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 18);
            this.label4.TabIndex = 7;
            this.label4.Text = "STOP";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // comboBox4
            // 
            this.comboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(68, 147);
            this.comboBox4.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(100, 26);
            this.comboBox4.TabIndex = 8;
            this.comboBox4.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 190);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 18);
            this.label5.TabIndex = 9;
            this.label5.Text = "CBIT";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // comboBox5
            // 
            this.comboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(68, 186);
            this.comboBox5.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(100, 26);
            this.comboBox5.TabIndex = 10;
            this.comboBox5.SelectedIndexChanged += new System.EventHandler(this.comboBox5_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 230);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 18);
            this.label6.TabIndex = 11;
            this.label6.Text = "CTRL";
            // 
            // comboBox6
            // 
            this.comboBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(68, 225);
            this.comboBox6.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(100, 26);
            this.comboBox6.TabIndex = 12;
            this.comboBox6.SelectedIndexChanged += new System.EventHandler(this.comboBox6_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.comboBox6);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.comboBox5);
            this.groupBox1.Controls.Add(this.comboBox2);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.comboBox4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.comboBox3);
            this.groupBox1.Location = new System.Drawing.Point(18, 18);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(182, 309);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "PORT SETTING";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tabControl1);
            this.groupBox2.Location = new System.Drawing.Point(208, 18);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(1395, 669);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "FUNCTION";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage17);
            this.tabControl1.Controls.Add(this.tabPage14);
            this.tabControl1.Controls.Add(this.tabPage19);
            this.tabControl1.Controls.Add(this.tabPage22);
            this.tabControl1.Location = new System.Drawing.Point(9, 30);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1380, 636);
            this.tabControl1.TabIndex = 14;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.TRADE);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(1372, 604);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "TRANSACTION";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // TRADE
            // 
            this.TRADE.Controls.Add(this.tabPage5);
            this.TRADE.Controls.Add(this.tabPage6);
            this.TRADE.Controls.Add(this.tabPage11);
            this.TRADE.Controls.Add(this.tabPage12);
            this.TRADE.Controls.Add(this.tabPage20);
            this.TRADE.Location = new System.Drawing.Point(12, 9);
            this.TRADE.Margin = new System.Windows.Forms.Padding(4);
            this.TRADE.Name = "TRADE";
            this.TRADE.SelectedIndex = 0;
            this.TRADE.Size = new System.Drawing.Size(1352, 568);
            this.TRADE.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.groupBox9);
            this.tabPage5.Controls.Add(this.groupBox7);
            this.tabPage5.Controls.Add(this.label35);
            this.tabPage5.Controls.Add(this.button4);
            this.tabPage5.Controls.Add(this.listBox2);
            this.tabPage5.Location = new System.Drawing.Point(4, 28);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage5.Size = new System.Drawing.Size(1344, 536);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "NORMAL";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.textBox38);
            this.groupBox9.Location = new System.Drawing.Point(324, 330);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox9.Size = new System.Drawing.Size(1004, 192);
            this.groupBox9.TabIndex = 85;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Transaction Result";
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(9, 24);
            this.textBox38.Margin = new System.Windows.Forms.Padding(4);
            this.textBox38.Multiline = true;
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(984, 158);
            this.textBox38.TabIndex = 0;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.comboBox28);
            this.groupBox7.Controls.Add(this.textBox14);
            this.groupBox7.Controls.Add(this.button9);
            this.groupBox7.Controls.Add(this.label20);
            this.groupBox7.Controls.Add(this.label21);
            this.groupBox7.Controls.Add(this.comboBox7);
            this.groupBox7.Controls.Add(this.label22);
            this.groupBox7.Controls.Add(this.comboBox8);
            this.groupBox7.Controls.Add(this.checkBox13);
            this.groupBox7.Controls.Add(this.textBox15);
            this.groupBox7.Controls.Add(this.checkBox12);
            this.groupBox7.Controls.Add(this.label23);
            this.groupBox7.Controls.Add(this.checkBox11);
            this.groupBox7.Controls.Add(this.label24);
            this.groupBox7.Controls.Add(this.checkBox10);
            this.groupBox7.Controls.Add(this.comboBox9);
            this.groupBox7.Controls.Add(this.checkBox9);
            this.groupBox7.Controls.Add(this.textBox16);
            this.groupBox7.Controls.Add(this.label34);
            this.groupBox7.Controls.Add(this.label25);
            this.groupBox7.Controls.Add(this.textBox20);
            this.groupBox7.Controls.Add(this.textBox17);
            this.groupBox7.Controls.Add(this.comboBox13);
            this.groupBox7.Controls.Add(this.label26);
            this.groupBox7.Controls.Add(this.label32);
            this.groupBox7.Controls.Add(this.textBox18);
            this.groupBox7.Controls.Add(this.label31);
            this.groupBox7.Controls.Add(this.label27);
            this.groupBox7.Controls.Add(this.textBox19);
            this.groupBox7.Controls.Add(this.label28);
            this.groupBox7.Controls.Add(this.comboBox12);
            this.groupBox7.Controls.Add(this.comboBox10);
            this.groupBox7.Controls.Add(this.label30);
            this.groupBox7.Controls.Add(this.label29);
            this.groupBox7.Location = new System.Drawing.Point(327, 9);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox7.Size = new System.Drawing.Size(1000, 320);
            this.groupBox7.TabIndex = 84;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Options";
            // 
            // comboBox28
            // 
            this.comboBox28.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox28.FormattingEnabled = true;
            this.comboBox28.Location = new System.Drawing.Point(543, 111);
            this.comboBox28.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox28.Name = "comboBox28";
            this.comboBox28.Size = new System.Drawing.Size(190, 26);
            this.comboBox28.TabIndex = 79;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(152, 30);
            this.textBox14.Margin = new System.Windows.Forms.Padding(4);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(106, 28);
            this.textBox14.TabIndex = 44;
            this.textBox14.Text = "1.00";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(766, 276);
            this.button9.Margin = new System.Windows.Forms.Padding(4);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(225, 34);
            this.button9.TabIndex = 1;
            this.button9.Text = "Start Transaction";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(81, 34);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(62, 18);
            this.label20.TabIndex = 45;
            this.label20.Text = "Amount";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(45, 116);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(98, 18);
            this.label21.TabIndex = 46;
            this.label21.Text = "Trade Mode";
            // 
            // comboBox7
            // 
            this.comboBox7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(152, 111);
            this.comboBox7.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(224, 26);
            this.comboBox7.TabIndex = 47;
            this.comboBox7.SelectedIndexChanged += new System.EventHandler(this.comboBox7_SelectedIndexChanged_1);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(0, 154);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(143, 18);
            this.label22.TabIndex = 48;
            this.label22.Text = "Currency Symbol";
            // 
            // comboBox8
            // 
            this.comboBox8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Location = new System.Drawing.Point(152, 150);
            this.comboBox8.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(106, 26);
            this.comboBox8.TabIndex = 49;
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Location = new System.Drawing.Point(766, 192);
            this.checkBox13.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(160, 22);
            this.checkBox13.TabIndex = 78;
            this.checkBox13.Text = "Cyclic testing";
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(152, 70);
            this.textBox15.Margin = new System.Windows.Forms.Padding(4);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(106, 28);
            this.textBox15.TabIndex = 50;
            this.textBox15.Text = "0.00";
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Location = new System.Drawing.Point(766, 74);
            this.checkBox12.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(223, 22);
            this.checkBox12.TabIndex = 76;
            this.checkBox12.Text = "Display Amount On Pos";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(27, 75);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(116, 18);
            this.label23.TabIndex = 51;
            this.label23.Text = "Amount Other";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(766, 153);
            this.checkBox11.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(160, 22);
            this.checkBox11.TabIndex = 75;
            this.checkBox11.Text = "Disable Record";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(45, 194);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(98, 18);
            this.label24.TabIndex = 52;
            this.label24.Text = "Vipos Mode";
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(766, 114);
            this.checkBox10.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(214, 22);
            this.checkBox10.TabIndex = 74;
            this.checkBox10.Text = "Amount Point Display";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // comboBox9
            // 
            this.comboBox9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Location = new System.Drawing.Point(152, 189);
            this.comboBox9.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(106, 26);
            this.comboBox9.TabIndex = 53;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(766, 33);
            this.checkBox9.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(205, 22);
            this.checkBox9.TabIndex = 73;
            this.checkBox9.Text = "Input Amount On Pos";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(152, 228);
            this.textBox16.Margin = new System.Windows.Forms.Padding(4);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(106, 28);
            this.textBox16.TabIndex = 54;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(410, 272);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(125, 18);
            this.label34.TabIndex = 72;
            this.label34.Text = "Custom Record";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(45, 232);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(98, 18);
            this.label25.TabIndex = 55;
            this.label25.Text = "Time Stamp";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(543, 267);
            this.textBox20.Margin = new System.Windows.Forms.Padding(4);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(106, 28);
            this.textBox20.TabIndex = 71;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(152, 268);
            this.textBox17.Margin = new System.Windows.Forms.Padding(4);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(106, 28);
            this.textBox17.TabIndex = 56;
            // 
            // comboBox13
            // 
            this.comboBox13.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox13.FormattingEnabled = true;
            this.comboBox13.Location = new System.Drawing.Point(543, 228);
            this.comboBox13.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox13.Name = "comboBox13";
            this.comboBox13.Size = new System.Drawing.Size(106, 26);
            this.comboBox13.TabIndex = 70;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(18, 273);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(125, 18);
            this.label26.TabIndex = 57;
            this.label26.Text = "Random Number";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(464, 232);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(71, 18);
            this.label32.TabIndex = 69;
            this.label32.Text = "En-Mode";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(543, 30);
            this.textBox18.Margin = new System.Windows.Forms.Padding(4);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(106, 28);
            this.textBox18.TabIndex = 58;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(400, 192);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(134, 18);
            this.label31.TabIndex = 68;
            this.label31.Text = "Custom Display";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(446, 34);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(89, 18);
            this.label27.TabIndex = 59;
            this.label27.Text = "Addi-Data";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(543, 188);
            this.textBox19.Margin = new System.Windows.Forms.Padding(4);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(106, 28);
            this.textBox19.TabIndex = 67;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(446, 75);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(89, 18);
            this.label28.TabIndex = 60;
            this.label28.Text = "Key Index";
            // 
            // comboBox12
            // 
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Location = new System.Drawing.Point(543, 148);
            this.comboBox12.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(106, 26);
            this.comboBox12.TabIndex = 66;
            // 
            // comboBox10
            // 
            this.comboBox10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Location = new System.Drawing.Point(543, 70);
            this.comboBox10.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(106, 26);
            this.comboBox10.TabIndex = 61;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(410, 153);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(125, 18);
            this.label30.TabIndex = 65;
            this.label30.Text = "Currency Code";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(436, 114);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(98, 18);
            this.label29.TabIndex = 63;
            this.label29.Text = "Trans-Type";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(9, 488);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(89, 18);
            this.label35.TabIndex = 82;
            this.label35.Text = "Totals: 0";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(202, 480);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(112, 34);
            this.button4.TabIndex = 81;
            this.button4.Text = "CLEAR";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 18;
            this.listBox2.Location = new System.Drawing.Point(9, 9);
            this.listBox2.Margin = new System.Windows.Forms.Padding(4);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(307, 454);
            this.listBox2.TabIndex = 80;
            this.listBox2.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged_1);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.comboBox17);
            this.tabPage6.Controls.Add(this.comboBox16);
            this.tabPage6.Controls.Add(this.textBox41);
            this.tabPage6.Controls.Add(this.textBox47);
            this.tabPage6.Controls.Add(this.textBox43);
            this.tabPage6.Controls.Add(this.textBox46);
            this.tabPage6.Controls.Add(this.textBox45);
            this.tabPage6.Controls.Add(this.textBox42);
            this.tabPage6.Controls.Add(this.button20);
            this.tabPage6.Controls.Add(this.textBox44);
            this.tabPage6.Controls.Add(this.textBox39);
            this.tabPage6.Controls.Add(this.button19);
            this.tabPage6.Controls.Add(this.button18);
            this.tabPage6.Controls.Add(this.button15);
            this.tabPage6.Controls.Add(this.textBox40);
            this.tabPage6.Controls.Add(this.button13);
            this.tabPage6.Location = new System.Drawing.Point(4, 28);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage6.Size = new System.Drawing.Size(1344, 536);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "APDU";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // comboBox17
            // 
            this.comboBox17.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox17.FormattingEnabled = true;
            this.comboBox17.Location = new System.Drawing.Point(1114, 346);
            this.comboBox17.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox17.Name = "comboBox17";
            this.comboBox17.Size = new System.Drawing.Size(214, 26);
            this.comboBox17.TabIndex = 35;
            // 
            // comboBox16
            // 
            this.comboBox16.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox16.FormattingEnabled = true;
            this.comboBox16.Location = new System.Drawing.Point(1114, 308);
            this.comboBox16.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox16.Name = "comboBox16";
            this.comboBox16.Size = new System.Drawing.Size(214, 26);
            this.comboBox16.TabIndex = 13;
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(9, 9);
            this.textBox41.Margin = new System.Windows.Forms.Padding(4);
            this.textBox41.Multiline = true;
            this.textBox41.Name = "textBox41";
            this.textBox41.ReadOnly = true;
            this.textBox41.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox41.Size = new System.Drawing.Size(1320, 288);
            this.textBox41.TabIndex = 34;
            this.textBox41.TextChanged += new System.EventHandler(this.textBox41_TextChanged);
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(1036, 444);
            this.textBox47.Margin = new System.Windows.Forms.Padding(4);
            this.textBox47.MaxLength = 2;
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(67, 28);
            this.textBox47.TabIndex = 33;
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(324, 444);
            this.textBox43.Margin = new System.Windows.Forms.Padding(4);
            this.textBox43.MaxLength = 2;
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(67, 28);
            this.textBox43.TabIndex = 32;
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(242, 444);
            this.textBox46.Margin = new System.Windows.Forms.Padding(4);
            this.textBox46.MaxLength = 2;
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(67, 28);
            this.textBox46.TabIndex = 31;
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(164, 444);
            this.textBox45.Margin = new System.Windows.Forms.Padding(4);
            this.textBox45.MaxLength = 2;
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(67, 28);
            this.textBox45.TabIndex = 30;
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(86, 444);
            this.textBox42.Margin = new System.Windows.Forms.Padding(4);
            this.textBox42.MaxLength = 2;
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(67, 28);
            this.textBox42.TabIndex = 29;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(484, 484);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(150, 33);
            this.button20.TabIndex = 28;
            this.button20.Text = "GENERATE";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(408, 444);
            this.textBox44.Margin = new System.Windows.Forms.Padding(4);
            this.textBox44.MaxLength = 1024;
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(618, 28);
            this.textBox44.TabIndex = 27;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(8, 444);
            this.textBox39.Margin = new System.Windows.Forms.Padding(4);
            this.textBox39.MaxLength = 2;
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(67, 28);
            this.textBox39.TabIndex = 24;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(1148, 484);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(183, 33);
            this.button19.TabIndex = 23;
            this.button19.Text = "POWER DOWN";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(976, 484);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(165, 33);
            this.button18.TabIndex = 22;
            this.button18.Text = "TRANSMIT";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(807, 484);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(164, 33);
            this.button15.TabIndex = 21;
            this.button15.Text = "POLL CARD";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(9, 308);
            this.textBox40.Margin = new System.Windows.Forms.Padding(4);
            this.textBox40.Multiline = true;
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(1094, 126);
            this.textBox40.TabIndex = 18;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(640, 484);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(160, 33);
            this.button13.TabIndex = 17;
            this.button13.Text = "CLEAR";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.button22);
            this.tabPage11.Controls.Add(this.label61);
            this.tabPage11.Controls.Add(this.label60);
            this.tabPage11.Controls.Add(this.label59);
            this.tabPage11.Controls.Add(this.label58);
            this.tabPage11.Controls.Add(this.label57);
            this.tabPage11.Controls.Add(this.label56);
            this.tabPage11.Controls.Add(this.textBox51);
            this.tabPage11.Controls.Add(this.textBox50);
            this.tabPage11.Controls.Add(this.comboBox20);
            this.tabPage11.Controls.Add(this.comboBox19);
            this.tabPage11.Controls.Add(this.comboBox18);
            this.tabPage11.Controls.Add(this.textBox49);
            this.tabPage11.Controls.Add(this.button21);
            this.tabPage11.Controls.Add(this.textBox48);
            this.tabPage11.Location = new System.Drawing.Point(4, 28);
            this.tabPage11.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage11.Size = new System.Drawing.Size(1344, 536);
            this.tabPage11.TabIndex = 2;
            this.tabPage11.Text = "INPUT PIN";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(417, 486);
            this.button22.Margin = new System.Windows.Forms.Padding(4);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(160, 34);
            this.button22.TabIndex = 48;
            this.button22.Text = "Clear";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(588, 212);
            this.label61.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(143, 18);
            this.label61.TabIndex = 47;
            this.label61.Text = "Additional Data";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(633, 171);
            this.label60.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(35, 18);
            this.label60.TabIndex = 46;
            this.label60.Text = "PAN";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(588, 130);
            this.label59.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(134, 18);
            this.label59.TabIndex = 45;
            this.label59.Text = "Custom Display";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(588, 92);
            this.label58.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(134, 18);
            this.label58.TabIndex = 44;
            this.label58.Text = "PIN Max Length";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(588, 52);
            this.label57.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(89, 18);
            this.label57.TabIndex = 43;
            this.label57.Text = "Key Index";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(588, 14);
            this.label56.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(116, 18);
            this.label56.TabIndex = 13;
            this.label56.Text = "Encrypt Type";
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(760, 207);
            this.textBox51.Margin = new System.Windows.Forms.Padding(4);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(568, 28);
            this.textBox51.TabIndex = 42;
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(760, 166);
            this.textBox50.Margin = new System.Windows.Forms.Padding(4);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(568, 28);
            this.textBox50.TabIndex = 41;
            // 
            // comboBox20
            // 
            this.comboBox20.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox20.FormattingEnabled = true;
            this.comboBox20.Location = new System.Drawing.Point(760, 87);
            this.comboBox20.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox20.Name = "comboBox20";
            this.comboBox20.Size = new System.Drawing.Size(568, 26);
            this.comboBox20.TabIndex = 40;
            // 
            // comboBox19
            // 
            this.comboBox19.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox19.FormattingEnabled = true;
            this.comboBox19.Location = new System.Drawing.Point(760, 48);
            this.comboBox19.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox19.Name = "comboBox19";
            this.comboBox19.Size = new System.Drawing.Size(568, 26);
            this.comboBox19.TabIndex = 39;
            // 
            // comboBox18
            // 
            this.comboBox18.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox18.FormattingEnabled = true;
            this.comboBox18.Location = new System.Drawing.Point(760, 9);
            this.comboBox18.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox18.Name = "comboBox18";
            this.comboBox18.Size = new System.Drawing.Size(568, 26);
            this.comboBox18.TabIndex = 38;
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(760, 126);
            this.textBox49.Margin = new System.Windows.Forms.Padding(4);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(568, 28);
            this.textBox49.TabIndex = 37;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(760, 486);
            this.button21.Margin = new System.Windows.Forms.Padding(4);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(570, 34);
            this.button21.TabIndex = 36;
            this.button21.Text = "Request Pin";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(4, 9);
            this.textBox48.Margin = new System.Windows.Forms.Padding(4);
            this.textBox48.Multiline = true;
            this.textBox48.Name = "textBox48";
            this.textBox48.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox48.Size = new System.Drawing.Size(571, 466);
            this.textBox48.TabIndex = 35;
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.groupBox10);
            this.tabPage12.Controls.Add(this.button23);
            this.tabPage12.Controls.Add(this.button25);
            this.tabPage12.Controls.Add(this.button26);
            this.tabPage12.Controls.Add(this.textBox52);
            this.tabPage12.Location = new System.Drawing.Point(4, 28);
            this.tabPage12.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage12.Size = new System.Drawing.Size(1344, 536);
            this.tabPage12.TabIndex = 3;
            this.tabPage12.Text = "TANGEM";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.button24);
            this.groupBox10.Controls.Add(this.textBox53);
            this.groupBox10.Controls.Add(this.label62);
            this.groupBox10.Location = new System.Drawing.Point(708, 60);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox10.Size = new System.Drawing.Size(622, 460);
            this.groupBox10.TabIndex = 42;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "groupBox10";
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(314, 28);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(116, 32);
            this.button24.TabIndex = 43;
            this.button24.Text = "READ CARD";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(62, 30);
            this.textBox53.Margin = new System.Windows.Forms.Padding(4);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(242, 28);
            this.textBox53.TabIndex = 40;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(9, 34);
            this.label62.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(44, 18);
            this.label62.TabIndex = 41;
            this.label62.Text = "PIN1";
            this.label62.Click += new System.EventHandler(this.label62_Click);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(1022, 9);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(309, 45);
            this.button23.TabIndex = 39;
            this.button23.Text = "POWER DOWN";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(705, 9);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(309, 45);
            this.button25.TabIndex = 37;
            this.button25.Text = "POLL CARD";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(482, 477);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(216, 45);
            this.button26.TabIndex = 36;
            this.button26.Text = "CLEAR";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(9, 9);
            this.textBox52.Margin = new System.Windows.Forms.Padding(4);
            this.textBox52.Multiline = true;
            this.textBox52.Name = "textBox52";
            this.textBox52.ReadOnly = true;
            this.textBox52.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox52.Size = new System.Drawing.Size(686, 458);
            this.textBox52.TabIndex = 35;
            this.textBox52.TextChanged += new System.EventHandler(this.textBox52_TextChanged);
            // 
            // tabPage20
            // 
            this.tabPage20.Controls.Add(this.label83);
            this.tabPage20.Controls.Add(this.comboBox27);
            this.tabPage20.Controls.Add(this.button56);
            this.tabPage20.Controls.Add(this.button55);
            this.tabPage20.Controls.Add(this.textBox81);
            this.tabPage20.Controls.Add(this.label82);
            this.tabPage20.Location = new System.Drawing.Point(4, 28);
            this.tabPage20.Name = "tabPage20";
            this.tabPage20.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage20.Size = new System.Drawing.Size(1344, 536);
            this.tabPage20.TabIndex = 5;
            this.tabPage20.Text = "CUSTOM DISP";
            this.tabPage20.UseVisualStyleBackColor = true;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(776, 15);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(62, 18);
            this.label83.TabIndex = 4;
            this.label83.Text = "Status";
            // 
            // comboBox27
            // 
            this.comboBox27.FormattingEnabled = true;
            this.comboBox27.Location = new System.Drawing.Point(632, 10);
            this.comboBox27.Name = "comboBox27";
            this.comboBox27.Size = new System.Drawing.Size(121, 26);
            this.comboBox27.TabIndex = 3;
            // 
            // button56
            // 
            this.button56.Location = new System.Drawing.Point(489, 56);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(348, 48);
            this.button56.TabIndex = 2;
            this.button56.Text = "Cancel";
            this.button56.UseVisualStyleBackColor = true;
            this.button56.Click += new System.EventHandler(this.button56_Click_1);
            // 
            // button55
            // 
            this.button55.Location = new System.Drawing.Point(22, 56);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(460, 48);
            this.button55.TabIndex = 2;
            this.button55.Text = "Confirm";
            this.button55.UseVisualStyleBackColor = true;
            this.button55.Click += new System.EventHandler(this.button55_Click_2);
            // 
            // textBox81
            // 
            this.textBox81.Location = new System.Drawing.Point(114, 10);
            this.textBox81.Name = "textBox81";
            this.textBox81.Size = new System.Drawing.Size(494, 28);
            this.textBox81.TabIndex = 1;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(20, 15);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(89, 18);
            this.label82.TabIndex = 0;
            this.label82.Text = "Message :";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tabControl3);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(1372, 604);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "KEY INJECTION";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage8);
            this.tabControl3.Controls.Add(this.tabPage9);
            this.tabControl3.Controls.Add(this.tabPage10);
            this.tabControl3.Controls.Add(this.tabPage13);
            this.tabControl3.Controls.Add(this.tabPage27);
            this.tabControl3.Controls.Add(this.tabPage28);
            this.tabControl3.Location = new System.Drawing.Point(9, 9);
            this.tabControl3.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(1323, 584);
            this.tabControl3.TabIndex = 0;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.groupBox6);
            this.tabPage8.Location = new System.Drawing.Point(4, 28);
            this.tabPage8.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage8.Size = new System.Drawing.Size(1315, 552);
            this.tabPage8.TabIndex = 0;
            this.tabPage8.Text = "10F0";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label105);
            this.groupBox6.Controls.Add(this.checkBox16);
            this.groupBox6.Controls.Add(this.checkBox15);
            this.groupBox6.Controls.Add(this.checkBox14);
            this.groupBox6.Controls.Add(this.label42);
            this.groupBox6.Controls.Add(this.label43);
            this.groupBox6.Controls.Add(this.comboBox11);
            this.groupBox6.Controls.Add(this.button7);
            this.groupBox6.Controls.Add(this.textBox28);
            this.groupBox6.Controls.Add(this.label41);
            this.groupBox6.Controls.Add(this.textBox26);
            this.groupBox6.Controls.Add(this.label40);
            this.groupBox6.Controls.Add(this.textBox22);
            this.groupBox6.Controls.Add(this.label36);
            this.groupBox6.Controls.Add(this.textBox23);
            this.groupBox6.Controls.Add(this.button6);
            this.groupBox6.Controls.Add(this.label37);
            this.groupBox6.Controls.Add(this.label39);
            this.groupBox6.Controls.Add(this.textBox24);
            this.groupBox6.Controls.Add(this.textBox25);
            this.groupBox6.Controls.Add(this.label38);
            this.groupBox6.Location = new System.Drawing.Point(9, 9);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox6.Size = new System.Drawing.Size(938, 362);
            this.groupBox6.TabIndex = 58;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Update Work Key By TMK";
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Location = new System.Drawing.Point(614, 236);
            this.checkBox16.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(115, 22);
            this.checkBox16.TabIndex = 68;
            this.checkBox16.Text = "CV ENABLE";
            this.checkBox16.UseVisualStyleBackColor = true;
            this.checkBox16.CheckedChanged += new System.EventHandler(this.checkBox16_CheckedChanged);
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Location = new System.Drawing.Point(614, 154);
            this.checkBox15.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(115, 22);
            this.checkBox15.TabIndex = 67;
            this.checkBox15.Text = "CV ENABLE";
            this.checkBox15.UseVisualStyleBackColor = true;
            this.checkBox15.CheckedChanged += new System.EventHandler(this.checkBox15_CheckedChanged);
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Location = new System.Drawing.Point(614, 75);
            this.checkBox14.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(115, 22);
            this.checkBox14.TabIndex = 66;
            this.checkBox14.Text = "CV ENABLE";
            this.checkBox14.UseVisualStyleBackColor = true;
            this.checkBox14.CheckedChanged += new System.EventHandler(this.checkBox14_CheckedChanged);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(9, 519);
            this.label42.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(26, 18);
            this.label42.TabIndex = 64;
            this.label42.Text = "NA";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(18, 278);
            this.label43.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(53, 18);
            this.label43.TabIndex = 65;
            this.label43.Text = "INDEX";
            this.label43.Click += new System.EventHandler(this.label43_Click);
            // 
            // comboBox11
            // 
            this.comboBox11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Location = new System.Drawing.Point(108, 273);
            this.comboBox11.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(106, 26);
            this.comboBox11.TabIndex = 64;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(716, 316);
            this.button7.Margin = new System.Windows.Forms.Padding(4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(102, 34);
            this.button7.TabIndex = 13;
            this.button7.Text = "CLEAR";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(108, 232);
            this.textBox28.Margin = new System.Windows.Forms.Padding(4);
            this.textBox28.MaxLength = 16;
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(494, 28);
            this.textBox28.TabIndex = 62;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(18, 237);
            this.label41.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(62, 18);
            this.label41.TabIndex = 63;
            this.label41.Text = "MCK CV";
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(108, 152);
            this.textBox26.Margin = new System.Windows.Forms.Padding(4);
            this.textBox26.MaxLength = 16;
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(494, 28);
            this.textBox26.TabIndex = 60;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(18, 156);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(62, 18);
            this.label40.TabIndex = 61;
            this.label40.Text = "PIK CV";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(108, 70);
            this.textBox22.Margin = new System.Windows.Forms.Padding(4);
            this.textBox22.MaxLength = 16;
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(494, 28);
            this.textBox22.TabIndex = 58;
            this.textBox22.TextChanged += new System.EventHandler(this.textBox22_TextChanged);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(18, 75);
            this.label36.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(62, 18);
            this.label36.TabIndex = 59;
            this.label36.Text = "TDK CV";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(108, 30);
            this.textBox23.Margin = new System.Windows.Forms.Padding(4);
            this.textBox23.MaxLength = 32;
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(494, 28);
            this.textBox23.TabIndex = 52;
            this.textBox23.TextChanged += new System.EventHandler(this.textBox23_TextChanged);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(826, 316);
            this.button6.Margin = new System.Windows.Forms.Padding(4);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(102, 34);
            this.button6.TabIndex = 13;
            this.button6.Text = "INJECT";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(18, 34);
            this.label37.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(35, 18);
            this.label37.TabIndex = 53;
            this.label37.Text = "TDK";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(18, 196);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(35, 18);
            this.label39.TabIndex = 57;
            this.label39.Text = "MCK";
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(108, 111);
            this.textBox24.Margin = new System.Windows.Forms.Padding(4);
            this.textBox24.MaxLength = 32;
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(494, 28);
            this.textBox24.TabIndex = 54;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(108, 192);
            this.textBox25.Margin = new System.Windows.Forms.Padding(4);
            this.textBox25.MaxLength = 32;
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(494, 28);
            this.textBox25.TabIndex = 56;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(18, 116);
            this.label38.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(35, 18);
            this.label38.TabIndex = 55;
            this.label38.Text = "PIK";
            // 
            // tabPage9
            // 
            this.tabPage9.Location = new System.Drawing.Point(4, 28);
            this.tabPage9.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage9.Size = new System.Drawing.Size(1315, 552);
            this.tabPage9.TabIndex = 1;
            this.tabPage9.Text = "10F1";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.groupBox8);
            this.tabPage10.Location = new System.Drawing.Point(4, 28);
            this.tabPage10.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage10.Size = new System.Drawing.Size(1315, 552);
            this.tabPage10.TabIndex = 2;
            this.tabPage10.Text = "10F2";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label104);
            this.groupBox8.Controls.Add(this.checkBox17);
            this.groupBox8.Controls.Add(this.label55);
            this.groupBox8.Controls.Add(this.comboBox15);
            this.groupBox8.Controls.Add(this.textBox35);
            this.groupBox8.Controls.Add(this.label52);
            this.groupBox8.Controls.Add(this.textBox36);
            this.groupBox8.Controls.Add(this.label53);
            this.groupBox8.Controls.Add(this.textBox37);
            this.groupBox8.Controls.Add(this.label54);
            this.groupBox8.Controls.Add(this.textBox29);
            this.groupBox8.Controls.Add(this.label46);
            this.groupBox8.Controls.Add(this.textBox30);
            this.groupBox8.Controls.Add(this.label47);
            this.groupBox8.Controls.Add(this.textBox34);
            this.groupBox8.Controls.Add(this.label50);
            this.groupBox8.Controls.Add(this.label44);
            this.groupBox8.Controls.Add(this.label45);
            this.groupBox8.Controls.Add(this.comboBox14);
            this.groupBox8.Controls.Add(this.button8);
            this.groupBox8.Controls.Add(this.textBox31);
            this.groupBox8.Controls.Add(this.label48);
            this.groupBox8.Controls.Add(this.textBox32);
            this.groupBox8.Controls.Add(this.button10);
            this.groupBox8.Controls.Add(this.label49);
            this.groupBox8.Controls.Add(this.textBox33);
            this.groupBox8.Controls.Add(this.label51);
            this.groupBox8.Location = new System.Drawing.Point(9, 9);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox8.Size = new System.Drawing.Size(938, 498);
            this.groupBox8.TabIndex = 59;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Update IPEK/KSN By TMK";
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.Location = new System.Drawing.Point(312, 390);
            this.checkBox17.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(178, 22);
            this.checkBox17.TabIndex = 83;
            this.checkBox17.Text = "ClearIpekAndNoCV";
            this.checkBox17.UseVisualStyleBackColor = true;
            this.checkBox17.CheckedChanged += new System.EventHandler(this.checkBox17_CheckedChanged);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(9, 429);
            this.label55.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(89, 18);
            this.label55.TabIndex = 82;
            this.label55.Text = "CV LENGTH";
            // 
            // comboBox15
            // 
            this.comboBox15.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox15.FormattingEnabled = true;
            this.comboBox15.Location = new System.Drawing.Point(180, 424);
            this.comboBox15.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox15.Name = "comboBox15";
            this.comboBox15.Size = new System.Drawing.Size(106, 26);
            this.comboBox15.TabIndex = 81;
            this.comboBox15.SelectedIndexChanged += new System.EventHandler(this.comboBox15_SelectedIndexChanged);
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(180, 304);
            this.textBox35.Margin = new System.Windows.Forms.Padding(4);
            this.textBox35.MaxLength = 20;
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(494, 28);
            this.textBox35.TabIndex = 78;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(9, 309);
            this.label52.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(71, 18);
            this.label52.TabIndex = 79;
            this.label52.Text = "PIN KSN";
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(180, 264);
            this.textBox36.Margin = new System.Windows.Forms.Padding(4);
            this.textBox36.MaxLength = 32;
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(494, 28);
            this.textBox36.TabIndex = 74;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(9, 268);
            this.label53.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(80, 18);
            this.label53.TabIndex = 75;
            this.label53.Text = "PIN IPEK";
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(180, 345);
            this.textBox37.Margin = new System.Windows.Forms.Padding(4);
            this.textBox37.MaxLength = 16;
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(494, 28);
            this.textBox37.TabIndex = 76;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(9, 350);
            this.label54.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(107, 18);
            this.label54.TabIndex = 77;
            this.label54.Text = "PIN IPEK CV";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(180, 183);
            this.textBox29.Margin = new System.Windows.Forms.Padding(4);
            this.textBox29.MaxLength = 20;
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(494, 28);
            this.textBox29.TabIndex = 71;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(9, 188);
            this.label46.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(71, 18);
            this.label46.TabIndex = 72;
            this.label46.Text = "EMV KSN";
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(180, 142);
            this.textBox30.Margin = new System.Windows.Forms.Padding(4);
            this.textBox30.MaxLength = 32;
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(494, 28);
            this.textBox30.TabIndex = 67;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(9, 147);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(80, 18);
            this.label47.TabIndex = 68;
            this.label47.Text = "EMV IPEK";
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(180, 224);
            this.textBox34.Margin = new System.Windows.Forms.Padding(4);
            this.textBox34.MaxLength = 16;
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(494, 28);
            this.textBox34.TabIndex = 69;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(9, 228);
            this.label50.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(107, 18);
            this.label50.TabIndex = 70;
            this.label50.Text = "EMV IPEK CV";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(9, 519);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(26, 18);
            this.label44.TabIndex = 64;
            this.label44.Text = "NA";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(9, 390);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(53, 18);
            this.label45.TabIndex = 65;
            this.label45.Text = "INDEX";
            // 
            // comboBox14
            // 
            this.comboBox14.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox14.FormattingEnabled = true;
            this.comboBox14.Location = new System.Drawing.Point(180, 386);
            this.comboBox14.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox14.Name = "comboBox14";
            this.comboBox14.Size = new System.Drawing.Size(106, 26);
            this.comboBox14.TabIndex = 64;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(716, 454);
            this.button8.Margin = new System.Windows.Forms.Padding(4);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(102, 34);
            this.button8.TabIndex = 13;
            this.button8.Text = "CLEAR";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(180, 62);
            this.textBox31.Margin = new System.Windows.Forms.Padding(4);
            this.textBox31.MaxLength = 20;
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(494, 28);
            this.textBox31.TabIndex = 58;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(9, 66);
            this.label48.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(89, 18);
            this.label48.TabIndex = 59;
            this.label48.Text = "TRACK KSN";
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(180, 21);
            this.textBox32.Margin = new System.Windows.Forms.Padding(4);
            this.textBox32.MaxLength = 32;
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(494, 28);
            this.textBox32.TabIndex = 52;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(826, 454);
            this.button10.Margin = new System.Windows.Forms.Padding(4);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(102, 34);
            this.button10.TabIndex = 13;
            this.button10.Text = "INJECT";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(9, 26);
            this.label49.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(98, 18);
            this.label49.TabIndex = 53;
            this.label49.Text = "TRACK IPEK";
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(180, 102);
            this.textBox33.Margin = new System.Windows.Forms.Padding(4);
            this.textBox33.MaxLength = 16;
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(494, 28);
            this.textBox33.TabIndex = 54;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(9, 106);
            this.label51.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(125, 18);
            this.label51.TabIndex = 55;
            this.label51.Text = "TRACK IPEK CV";
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.button57);
            this.tabPage13.Controls.Add(this.button44);
            this.tabPage13.Controls.Add(this.label69);
            this.tabPage13.Controls.Add(this.groupBox12);
            this.tabPage13.Controls.Add(this.textBox74);
            this.tabPage13.Controls.Add(this.button42);
            this.tabPage13.Controls.Add(this.textBox58);
            this.tabPage13.Location = new System.Drawing.Point(4, 28);
            this.tabPage13.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage13.Size = new System.Drawing.Size(1315, 552);
            this.tabPage13.TabIndex = 3;
            this.tabPage13.Text = "4000/4010";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // button57
            // 
            this.button57.Location = new System.Drawing.Point(338, 438);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(164, 33);
            this.button57.TabIndex = 108;
            this.button57.Text = "Generate RSA Key";
            this.button57.UseVisualStyleBackColor = true;
            this.button57.Click += new System.EventHandler(this.button57_Click);
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(507, 438);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(174, 36);
            this.button44.TabIndex = 17;
            this.button44.Text = "Clear";
            this.button44.UseVisualStyleBackColor = true;
            this.button44.Click += new System.EventHandler(this.button44_Click);
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(9, 447);
            this.label69.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(26, 18);
            this.label69.TabIndex = 57;
            this.label69.Text = "NA";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.textBox88);
            this.groupBox12.Controls.Add(this.textBox86);
            this.groupBox12.Controls.Add(this.label96);
            this.groupBox12.Controls.Add(this.button43);
            this.groupBox12.Controls.Add(this.button53);
            this.groupBox12.Controls.Add(this.textBox59);
            this.groupBox12.Controls.Add(this.textBox63);
            this.groupBox12.Controls.Add(this.comboBox26);
            this.groupBox12.Controls.Add(this.label67);
            this.groupBox12.Controls.Add(this.textBox62);
            this.groupBox12.Controls.Add(this.label68);
            this.groupBox12.Controls.Add(this.label75);
            this.groupBox12.Controls.Add(this.comboBox25);
            this.groupBox12.Controls.Add(this.comboBox23);
            this.groupBox12.Controls.Add(this.label66);
            this.groupBox12.Controls.Add(this.label74);
            this.groupBox12.Controls.Add(this.comboBox24);
            this.groupBox12.Location = new System.Drawing.Point(690, 9);
            this.groupBox12.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox12.Size = new System.Drawing.Size(612, 534);
            this.groupBox12.TabIndex = 107;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "DIGITAL ENVELOPE GENERATION";
            // 
            // textBox88
            // 
            this.textBox88.Location = new System.Drawing.Point(46, 102);
            this.textBox88.Multiline = true;
            this.textBox88.Name = "textBox88";
            this.textBox88.Size = new System.Drawing.Size(548, 64);
            this.textBox88.TabIndex = 65;
            // 
            // textBox86
            // 
            this.textBox86.Location = new System.Drawing.Point(46, 174);
            this.textBox86.Name = "textBox86";
            this.textBox86.Size = new System.Drawing.Size(548, 28);
            this.textBox86.TabIndex = 64;
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(16, 184);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(17, 18);
            this.label96.TabIndex = 63;
            this.label96.Text = "E";
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(6, 483);
            this.button43.Margin = new System.Windows.Forms.Padding(4);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(591, 36);
            this.button43.TabIndex = 13;
            this.button43.Text = "Generate";
            this.button43.UseVisualStyleBackColor = true;
            this.button43.Click += new System.EventHandler(this.button43_Click);
            // 
            // button53
            // 
            this.button53.Location = new System.Drawing.Point(513, 440);
            this.button53.Margin = new System.Windows.Forms.Padding(4);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(84, 34);
            this.button53.TabIndex = 13;
            this.button53.Text = "APPEND";
            this.button53.UseVisualStyleBackColor = true;
            this.button53.Click += new System.EventHandler(this.button53_Click);
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(46, 28);
            this.textBox59.Margin = new System.Windows.Forms.Padding(4);
            this.textBox59.Multiline = true;
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(548, 64);
            this.textBox59.TabIndex = 58;
            // 
            // textBox63
            // 
            this.textBox63.Location = new System.Drawing.Point(114, 442);
            this.textBox63.Margin = new System.Windows.Forms.Padding(4);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(388, 28);
            this.textBox63.TabIndex = 62;
            // 
            // comboBox26
            // 
            this.comboBox26.FormattingEnabled = true;
            this.comboBox26.Location = new System.Drawing.Point(6, 442);
            this.comboBox26.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox26.Name = "comboBox26";
            this.comboBox26.Size = new System.Drawing.Size(100, 26);
            this.comboBox26.TabIndex = 13;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(16, 72);
            this.label67.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(26, 18);
            this.label67.TabIndex = 51;
            this.label67.Text = "SN";
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(4, 327);
            this.textBox62.Margin = new System.Windows.Forms.Padding(4);
            this.textBox62.Multiline = true;
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(590, 104);
            this.textBox62.TabIndex = 61;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(16, 150);
            this.label68.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(26, 18);
            this.label68.TabIndex = 50;
            this.label68.Text = "SD";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(3, 296);
            this.label75.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(116, 18);
            this.label75.TabIndex = 16;
            this.label75.Text = "EnvelopeType";
            // 
            // comboBox25
            // 
            this.comboBox25.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox25.FormattingEnabled = true;
            this.comboBox25.Location = new System.Drawing.Point(124, 288);
            this.comboBox25.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox25.Name = "comboBox25";
            this.comboBox25.Size = new System.Drawing.Size(470, 26);
            this.comboBox25.TabIndex = 17;
            // 
            // comboBox23
            // 
            this.comboBox23.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox23.FormattingEnabled = true;
            this.comboBox23.Location = new System.Drawing.Point(126, 213);
            this.comboBox23.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox23.Name = "comboBox23";
            this.comboBox23.Size = new System.Drawing.Size(469, 26);
            this.comboBox23.TabIndex = 13;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(8, 218);
            this.label66.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(107, 18);
            this.label66.TabIndex = 13;
            this.label66.Text = "EncryptType";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(6, 256);
            this.label74.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(89, 18);
            this.label74.TabIndex = 14;
            this.label74.Text = "Publisher";
            // 
            // comboBox24
            // 
            this.comboBox24.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox24.FormattingEnabled = true;
            this.comboBox24.Location = new System.Drawing.Point(123, 249);
            this.comboBox24.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox24.Name = "comboBox24";
            this.comboBox24.Size = new System.Drawing.Size(472, 26);
            this.comboBox24.TabIndex = 15;
            // 
            // textBox74
            // 
            this.textBox74.Location = new System.Drawing.Point(9, 286);
            this.textBox74.Margin = new System.Windows.Forms.Padding(4);
            this.textBox74.Multiline = true;
            this.textBox74.Name = "textBox74";
            this.textBox74.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox74.Size = new System.Drawing.Size(672, 142);
            this.textBox74.TabIndex = 57;
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(4, 483);
            this.button42.Margin = new System.Windows.Forms.Padding(4);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(676, 45);
            this.button42.TabIndex = 13;
            this.button42.Text = "DOWNLOAD";
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Click += new System.EventHandler(this.button42_Click);
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(8, 4);
            this.textBox58.Margin = new System.Windows.Forms.Padding(4);
            this.textBox58.Multiline = true;
            this.textBox58.Name = "textBox58";
            this.textBox58.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox58.Size = new System.Drawing.Size(672, 271);
            this.textBox58.TabIndex = 106;
            // 
            // tabPage27
            // 
            this.tabPage27.Controls.Add(this.groupBox15);
            this.tabPage27.Location = new System.Drawing.Point(4, 28);
            this.tabPage27.Name = "tabPage27";
            this.tabPage27.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage27.Size = new System.Drawing.Size(1315, 552);
            this.tabPage27.TabIndex = 4;
            this.tabPage27.Text = "10E4";
            this.tabPage27.UseVisualStyleBackColor = true;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.comboBox33);
            this.groupBox15.Controls.Add(this.label94);
            this.groupBox15.Controls.Add(this.label95);
            this.groupBox15.Controls.Add(this.button78);
            this.groupBox15.Controls.Add(this.button77);
            this.groupBox15.Controls.Add(this.textBox85);
            this.groupBox15.Controls.Add(this.textBox84);
            this.groupBox15.Controls.Add(this.label93);
            this.groupBox15.Controls.Add(this.label92);
            this.groupBox15.Controls.Add(this.label91);
            this.groupBox15.Location = new System.Drawing.Point(6, 14);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(699, 288);
            this.groupBox15.TabIndex = 0;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Update TMK";
            // 
            // comboBox33
            // 
            this.comboBox33.FormattingEnabled = true;
            this.comboBox33.Location = new System.Drawing.Point(140, 140);
            this.comboBox33.Name = "comboBox33";
            this.comboBox33.Size = new System.Drawing.Size(121, 26);
            this.comboBox33.TabIndex = 11;
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(21, 142);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(71, 18);
            this.label94.TabIndex = 10;
            this.label94.Text = "Index :";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(15, 258);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(26, 18);
            this.label95.TabIndex = 9;
            this.label95.Text = "NA";
            // 
            // button78
            // 
            this.button78.Location = new System.Drawing.Point(580, 198);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(102, 30);
            this.button78.TabIndex = 8;
            this.button78.Text = "Clear";
            this.button78.UseVisualStyleBackColor = true;
            this.button78.Click += new System.EventHandler(this.button78_Click);
            // 
            // button77
            // 
            this.button77.Location = new System.Drawing.Point(18, 198);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(556, 32);
            this.button77.TabIndex = 7;
            this.button77.Text = "Update";
            this.button77.UseVisualStyleBackColor = true;
            this.button77.Click += new System.EventHandler(this.button77_Click);
            // 
            // textBox85
            // 
            this.textBox85.Location = new System.Drawing.Point(140, 88);
            this.textBox85.MaxLength = 16;
            this.textBox85.Name = "textBox85";
            this.textBox85.Size = new System.Drawing.Size(541, 28);
            this.textBox85.TabIndex = 5;
            // 
            // textBox84
            // 
            this.textBox84.Location = new System.Drawing.Point(140, 40);
            this.textBox84.MaxLength = 32;
            this.textBox84.Name = "textBox84";
            this.textBox84.Size = new System.Drawing.Size(541, 28);
            this.textBox84.TabIndex = 4;
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(15, 142);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(0, 18);
            this.label93.TabIndex = 2;
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(15, 92);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(116, 18);
            this.label92.TabIndex = 1;
            this.label92.Text = "CheckValue :";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(15, 44);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(116, 18);
            this.label91.TabIndex = 0;
            this.label91.Text = "EncryptTmk :";
            // 
            // tabPage28
            // 
            this.tabPage28.Controls.Add(this.groupBox18);
            this.tabPage28.Location = new System.Drawing.Point(4, 28);
            this.tabPage28.Name = "tabPage28";
            this.tabPage28.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage28.Size = new System.Drawing.Size(1315, 552);
            this.tabPage28.TabIndex = 5;
            this.tabPage28.Text = "10E2";
            this.tabPage28.UseVisualStyleBackColor = true;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.label103);
            this.groupBox18.Controls.Add(this.button82);
            this.groupBox18.Controls.Add(this.button40);
            this.groupBox18.Controls.Add(this.comboBox34);
            this.groupBox18.Controls.Add(this.label102);
            this.groupBox18.Controls.Add(this.textBox91);
            this.groupBox18.Controls.Add(this.textBox90);
            this.groupBox18.Controls.Add(this.label101);
            this.groupBox18.Controls.Add(this.label100);
            this.groupBox18.Location = new System.Drawing.Point(28, 27);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(849, 339);
            this.groupBox18.TabIndex = 0;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Update TMK";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(17, 276);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(26, 18);
            this.label103.TabIndex = 8;
            this.label103.Text = "NA";
            // 
            // button82
            // 
            this.button82.Location = new System.Drawing.Point(537, 194);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(91, 34);
            this.button82.TabIndex = 7;
            this.button82.Text = "Clear";
            this.button82.UseVisualStyleBackColor = true;
            this.button82.Click += new System.EventHandler(this.button82_Click);
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(20, 194);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(501, 34);
            this.button40.TabIndex = 6;
            this.button40.Text = "Update";
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Click += new System.EventHandler(this.button40_Click_1);
            // 
            // comboBox34
            // 
            this.comboBox34.FormattingEnabled = true;
            this.comboBox34.Location = new System.Drawing.Point(122, 142);
            this.comboBox34.Name = "comboBox34";
            this.comboBox34.Size = new System.Drawing.Size(121, 26);
            this.comboBox34.TabIndex = 5;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(17, 142);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(71, 18);
            this.label102.TabIndex = 4;
            this.label102.Text = "Index: ";
            // 
            // textBox91
            // 
            this.textBox91.Location = new System.Drawing.Point(122, 82);
            this.textBox91.MaxLength = 16;
            this.textBox91.Name = "textBox91";
            this.textBox91.Size = new System.Drawing.Size(506, 28);
            this.textBox91.TabIndex = 3;
            // 
            // textBox90
            // 
            this.textBox90.Location = new System.Drawing.Point(122, 39);
            this.textBox90.MaxLength = 32;
            this.textBox90.Name = "textBox90";
            this.textBox90.Size = new System.Drawing.Size(506, 28);
            this.textBox90.TabIndex = 2;
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(17, 82);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(116, 18);
            this.label101.TabIndex = 1;
            this.label101.Text = "CheckValue: ";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(17, 42);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(53, 18);
            this.label100.TabIndex = 0;
            this.label100.Text = "TMK: ";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button35);
            this.tabPage3.Controls.Add(this.textBox55);
            this.tabPage3.Controls.Add(this.textBox56);
            this.tabPage3.Controls.Add(this.textBox54);
            this.tabPage3.Controls.Add(this.button34);
            this.tabPage3.Controls.Add(this.button37);
            this.tabPage3.Controls.Add(this.button38);
            this.tabPage3.Controls.Add(this.button39);
            this.tabPage3.Controls.Add(this.button33);
            this.tabPage3.Controls.Add(this.button32);
            this.tabPage3.Controls.Add(this.button31);
            this.tabPage3.Controls.Add(this.button30);
            this.tabPage3.Controls.Add(this.button29);
            this.tabPage3.Controls.Add(this.button28);
            this.tabPage3.Controls.Add(this.comboBox21);
            this.tabPage3.Controls.Add(this.button27);
            this.tabPage3.Controls.Add(this.button17);
            this.tabPage3.Controls.Add(this.button14);
            this.tabPage3.Controls.Add(this.button16);
            this.tabPage3.Controls.Add(this.listBox3);
            this.tabPage3.Location = new System.Drawing.Point(4, 28);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage3.Size = new System.Drawing.Size(1372, 604);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "EMV CONFIGURATION";
            this.tabPage3.UseVisualStyleBackColor = true;
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(1198, 546);
            this.button35.Margin = new System.Windows.Forms.Padding(4);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(158, 34);
            this.button35.TabIndex = 106;
            this.button35.Text = "DOWNLOAD XML";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button35_Click_1);
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(406, 390);
            this.textBox55.Margin = new System.Windows.Forms.Padding(4);
            this.textBox55.Multiline = true;
            this.textBox55.Name = "textBox55";
            this.textBox55.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox55.Size = new System.Drawing.Size(781, 146);
            this.textBox55.TabIndex = 105;
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(554, 549);
            this.textBox56.Margin = new System.Windows.Forms.Padding(4);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(552, 28);
            this.textBox56.TabIndex = 90;
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(406, 10);
            this.textBox54.Margin = new System.Windows.Forms.Padding(4);
            this.textBox54.Multiline = true;
            this.textBox54.Name = "textBox54";
            this.textBox54.ReadOnly = true;
            this.textBox54.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox54.Size = new System.Drawing.Size(781, 368);
            this.textBox54.TabIndex = 88;
            this.textBox54.TextChanged += new System.EventHandler(this.textBox54_TextChanged);
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(1198, 464);
            this.button34.Margin = new System.Windows.Forms.Padding(4);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(158, 34);
            this.button34.TabIndex = 104;
            this.button34.Text = "DOWNLOAD BIN";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(1198, 344);
            this.button37.Margin = new System.Windows.Forms.Padding(4);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(158, 34);
            this.button37.TabIndex = 101;
            this.button37.Text = "DELETE CAPK";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(1198, 309);
            this.button38.Margin = new System.Windows.Forms.Padding(4);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(158, 34);
            this.button38.TabIndex = 100;
            this.button38.Text = "ADD CAPK";
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(1198, 274);
            this.button39.Margin = new System.Windows.Forms.Padding(4);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(158, 34);
            this.button39.TabIndex = 99;
            this.button39.Text = "CLEAR CAPK";
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(1198, 429);
            this.button33.Margin = new System.Windows.Forms.Padding(4);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(158, 34);
            this.button33.TabIndex = 98;
            this.button33.Text = "UPLOAD BIN";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(1198, 512);
            this.button32.Margin = new System.Windows.Forms.Padding(4);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(158, 34);
            this.button32.TabIndex = 97;
            this.button32.Text = "UPLOAD XML";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(1198, 153);
            this.button31.Margin = new System.Windows.Forms.Padding(4);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(158, 34);
            this.button31.TabIndex = 96;
            this.button31.Text = "UPDATE APP";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(1198, 118);
            this.button30.Margin = new System.Windows.Forms.Padding(4);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(158, 34);
            this.button30.TabIndex = 95;
            this.button30.Text = "DELETE APP";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(1198, 82);
            this.button29.Margin = new System.Windows.Forms.Padding(4);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(158, 34);
            this.button29.TabIndex = 94;
            this.button29.Text = "ADD APP";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(1198, 46);
            this.button28.Margin = new System.Windows.Forms.Padding(4);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(158, 34);
            this.button28.TabIndex = 93;
            this.button28.Text = "CLEAR APP";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // comboBox21
            // 
            this.comboBox21.FormattingEnabled = true;
            this.comboBox21.Location = new System.Drawing.Point(406, 549);
            this.comboBox21.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox21.Name = "comboBox21";
            this.comboBox21.Size = new System.Drawing.Size(136, 26);
            this.comboBox21.TabIndex = 92;
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(1116, 546);
            this.button27.Margin = new System.Windows.Forms.Padding(4);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(74, 34);
            this.button27.TabIndex = 91;
            this.button27.Text = "Append";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click_1);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(1198, 240);
            this.button17.Margin = new System.Windows.Forms.Padding(4);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(158, 34);
            this.button17.TabIndex = 87;
            this.button17.Text = "LIST CAPK";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(1198, 10);
            this.button14.Margin = new System.Windows.Forms.Padding(4);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(158, 34);
            this.button14.TabIndex = 86;
            this.button14.Text = "LIST APP";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(9, 548);
            this.button16.Margin = new System.Windows.Forms.Padding(4);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(388, 34);
            this.button16.TabIndex = 85;
            this.button16.Text = "CLEAR";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.ItemHeight = 18;
            this.listBox3.Location = new System.Drawing.Point(9, 10);
            this.listBox3.Margin = new System.Windows.Forms.Padding(4);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(386, 526);
            this.listBox3.TabIndex = 81;
            this.listBox3.SelectedIndexChanged += new System.EventHandler(this.listBox3_SelectedIndexChanged);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox11);
            this.tabPage4.Controls.Add(this.groupBox4);
            this.tabPage4.Controls.Add(this.groupBox3);
            this.tabPage4.Location = new System.Drawing.Point(4, 28);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage4.Size = new System.Drawing.Size(1372, 604);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "POS INFO";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.button41);
            this.groupBox11.Controls.Add(this.textBox57);
            this.groupBox11.Location = new System.Drawing.Point(464, 144);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox11.Size = new System.Drawing.Size(498, 338);
            this.groupBox11.TabIndex = 56;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "MANAGER PUBLIC";
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(9, 290);
            this.button41.Margin = new System.Windows.Forms.Padding(4);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(480, 34);
            this.button41.TabIndex = 50;
            this.button41.Text = "LOAD";
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.button41_Click_1);
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(9, 21);
            this.textBox57.Margin = new System.Windows.Forms.Padding(4);
            this.textBox57.Multiline = true;
            this.textBox57.Name = "textBox57";
            this.textBox57.ReadOnly = true;
            this.textBox57.Size = new System.Drawing.Size(478, 258);
            this.textBox57.TabIndex = 50;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox27);
            this.groupBox4.Controls.Add(this.button5);
            this.groupBox4.Location = new System.Drawing.Point(464, 10);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(498, 124);
            this.groupBox4.TabIndex = 55;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "UPDATE CHECKVALUE";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(9, 30);
            this.textBox27.Margin = new System.Windows.Forms.Padding(4);
            this.textBox27.Name = "textBox27";
            this.textBox27.ReadOnly = true;
            this.textBox27.Size = new System.Drawing.Size(478, 28);
            this.textBox27.TabIndex = 53;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(9, 70);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(480, 34);
            this.button5.TabIndex = 52;
            this.button5.Text = "LOAD";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button11);
            this.groupBox3.Controls.Add(this.listBox1);
            this.groupBox3.Controls.Add(this.button3);
            this.groupBox3.Location = new System.Drawing.Point(9, 9);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(446, 477);
            this.groupBox3.TabIndex = 42;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "REPORT";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(321, 432);
            this.button11.Margin = new System.Windows.Forms.Padding(4);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(112, 34);
            this.button11.TabIndex = 5;
            this.button11.Text = "CLEAR";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 18;
            this.listBox1.Location = new System.Drawing.Point(9, 21);
            this.listBox1.Margin = new System.Windows.Forms.Padding(4);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(422, 400);
            this.listBox1.TabIndex = 4;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(9, 432);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(112, 34);
            this.button3.TabIndex = 2;
            this.button3.Text = "UPLOAD";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // tabPage17
            // 
            this.tabPage17.Controls.Add(this.progressBar1);
            this.tabPage17.Controls.Add(this.button80);
            this.tabPage17.Controls.Add(this.textBox83);
            this.tabPage17.Controls.Add(this.button50);
            this.tabPage17.Controls.Add(this.button49);
            this.tabPage17.Controls.Add(this.button48);
            this.tabPage17.Controls.Add(this.label71);
            this.tabPage17.Controls.Add(this.textBox69);
            this.tabPage17.Controls.Add(this.textBox68);
            this.tabPage17.Controls.Add(this.button47);
            this.tabPage17.Controls.Add(this.label70);
            this.tabPage17.Controls.Add(this.button46);
            this.tabPage17.Location = new System.Drawing.Point(4, 28);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Size = new System.Drawing.Size(1372, 604);
            this.tabPage17.TabIndex = 6;
            this.tabPage17.Text = "GPOS FILE SYSTEM";
            this.tabPage17.UseVisualStyleBackColor = true;
            // 
            // progressBar1
            // 
            this.progressBar1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.progressBar1.ForeColor = System.Drawing.Color.Red;
            this.progressBar1.Location = new System.Drawing.Point(16, 94);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(1173, 22);
            this.progressBar1.TabIndex = 12;
            // 
            // button80
            // 
            this.button80.Location = new System.Drawing.Point(1056, 51);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(134, 30);
            this.button80.TabIndex = 11;
            this.button80.Text = "Read File";
            this.button80.UseVisualStyleBackColor = true;
            this.button80.Click += new System.EventHandler(this.button80_Click);
            // 
            // textBox83
            // 
            this.textBox83.Location = new System.Drawing.Point(18, 128);
            this.textBox83.Margin = new System.Windows.Forms.Padding(4);
            this.textBox83.Multiline = true;
            this.textBox83.Name = "textBox83";
            this.textBox83.ReadOnly = true;
            this.textBox83.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox83.Size = new System.Drawing.Size(1171, 432);
            this.textBox83.TabIndex = 10;
            // 
            // button50
            // 
            this.button50.Location = new System.Drawing.Point(1054, 15);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(136, 27);
            this.button50.TabIndex = 9;
            this.button50.Text = "CLEAR";
            this.button50.UseVisualStyleBackColor = true;
            this.button50.Click += new System.EventHandler(this.button50_Click);
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(915, 52);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(134, 27);
            this.button49.TabIndex = 8;
            this.button49.Text = "File List";
            this.button49.UseVisualStyleBackColor = true;
            this.button49.Click += new System.EventHandler(this.button49_Click);
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(772, 52);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(136, 27);
            this.button48.TabIndex = 7;
            this.button48.Text = "Delete";
            this.button48.UseVisualStyleBackColor = true;
            this.button48.Click += new System.EventHandler(this.button48_Click);
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(14, 57);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(89, 18);
            this.label71.TabIndex = 6;
            this.label71.Text = "File Name";
            // 
            // textBox69
            // 
            this.textBox69.Location = new System.Drawing.Point(110, 51);
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(646, 28);
            this.textBox69.TabIndex = 4;
            // 
            // textBox68
            // 
            this.textBox68.Location = new System.Drawing.Point(110, 14);
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(646, 28);
            this.textBox68.TabIndex = 1;
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(915, 15);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(134, 27);
            this.button47.TabIndex = 3;
            this.button47.Text = "Upload File";
            this.button47.UseVisualStyleBackColor = true;
            this.button47.Click += new System.EventHandler(this.button47_Click);
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(14, 20);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(89, 18);
            this.label70.TabIndex = 2;
            this.label70.Text = "File Path";
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(772, 15);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(136, 27);
            this.button46.TabIndex = 0;
            this.button46.Text = "Select File";
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.tabControl2);
            this.tabPage14.Location = new System.Drawing.Point(4, 28);
            this.tabPage14.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage14.Size = new System.Drawing.Size(1372, 604);
            this.tabPage14.TabIndex = 5;
            this.tabPage14.Text = "CALCULATION";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage15);
            this.tabControl2.Controls.Add(this.tabPage16);
            this.tabControl2.Controls.Add(this.tabPage18);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage23);
            this.tabControl2.Controls.Add(this.tabPage24);
            this.tabControl2.Controls.Add(this.tabPage21);
            this.tabControl2.Controls.Add(this.tabPage25);
            this.tabControl2.Controls.Add(this.tabPage26);
            this.tabControl2.Location = new System.Drawing.Point(9, 10);
            this.tabControl2.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1484, 822);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage15
            // 
            this.tabPage15.Controls.Add(this.button45);
            this.tabPage15.Controls.Add(this.textBox67);
            this.tabPage15.Controls.Add(this.comboBox22);
            this.tabPage15.Controls.Add(this.textBox66);
            this.tabPage15.Controls.Add(this.textBox65);
            this.tabPage15.Controls.Add(this.button36);
            this.tabPage15.Controls.Add(this.textBox64);
            this.tabPage15.Location = new System.Drawing.Point(4, 28);
            this.tabPage15.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage15.Size = new System.Drawing.Size(1476, 790);
            this.tabPage15.TabIndex = 0;
            this.tabPage15.Text = "DES";
            this.tabPage15.UseVisualStyleBackColor = true;
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(9, 510);
            this.button45.Margin = new System.Windows.Forms.Padding(4);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(375, 34);
            this.button45.TabIndex = 59;
            this.button45.Text = "Encryption";
            this.button45.UseVisualStyleBackColor = true;
            this.button45.Click += new System.EventHandler(this.button45_Click);
            // 
            // textBox67
            // 
            this.textBox67.Location = new System.Drawing.Point(120, 471);
            this.textBox67.Margin = new System.Windows.Forms.Padding(4);
            this.textBox67.MaxLength = 16;
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(646, 28);
            this.textBox67.TabIndex = 58;
            this.textBox67.TextChanged += new System.EventHandler(this.textBox67_TextChanged);
            // 
            // comboBox22
            // 
            this.comboBox22.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox22.FormattingEnabled = true;
            this.comboBox22.Location = new System.Drawing.Point(9, 471);
            this.comboBox22.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox22.Name = "comboBox22";
            this.comboBox22.Size = new System.Drawing.Size(100, 26);
            this.comboBox22.TabIndex = 13;
            this.comboBox22.SelectedIndexChanged += new System.EventHandler(this.comboBox22_SelectedIndexChanged);
            // 
            // textBox66
            // 
            this.textBox66.Location = new System.Drawing.Point(9, 254);
            this.textBox66.Margin = new System.Windows.Forms.Padding(4);
            this.textBox66.MaxLength = 1024;
            this.textBox66.Multiline = true;
            this.textBox66.Name = "textBox66";
            this.textBox66.ReadOnly = true;
            this.textBox66.Size = new System.Drawing.Size(757, 206);
            this.textBox66.TabIndex = 57;
            // 
            // textBox65
            // 
            this.textBox65.Location = new System.Drawing.Point(9, 50);
            this.textBox65.Margin = new System.Windows.Forms.Padding(4);
            this.textBox65.MaxLength = 1024;
            this.textBox65.Multiline = true;
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(757, 193);
            this.textBox65.TabIndex = 55;
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(393, 512);
            this.button36.Margin = new System.Windows.Forms.Padding(4);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(375, 34);
            this.button36.TabIndex = 13;
            this.button36.Text = "Decrypt";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // textBox64
            // 
            this.textBox64.Location = new System.Drawing.Point(9, 9);
            this.textBox64.Margin = new System.Windows.Forms.Padding(4);
            this.textBox64.MaxLength = 48;
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(757, 28);
            this.textBox64.TabIndex = 53;
            // 
            // tabPage16
            // 
            this.tabPage16.Controls.Add(this.textBox71);
            this.tabPage16.Controls.Add(this.textBox72);
            this.tabPage16.Controls.Add(this.button52);
            this.tabPage16.Location = new System.Drawing.Point(4, 28);
            this.tabPage16.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage16.Size = new System.Drawing.Size(1476, 790);
            this.tabPage16.TabIndex = 1;
            this.tabPage16.Text = "SHA1";
            this.tabPage16.UseVisualStyleBackColor = true;
            // 
            // textBox71
            // 
            this.textBox71.Location = new System.Drawing.Point(4, 201);
            this.textBox71.Margin = new System.Windows.Forms.Padding(4);
            this.textBox71.MaxLength = 1024;
            this.textBox71.Multiline = true;
            this.textBox71.Name = "textBox71";
            this.textBox71.ReadOnly = true;
            this.textBox71.Size = new System.Drawing.Size(757, 186);
            this.textBox71.TabIndex = 64;
            this.textBox71.TextChanged += new System.EventHandler(this.textBox71_TextChanged);
            // 
            // textBox72
            // 
            this.textBox72.Location = new System.Drawing.Point(4, 4);
            this.textBox72.Margin = new System.Windows.Forms.Padding(4);
            this.textBox72.MaxLength = 1024;
            this.textBox72.Multiline = true;
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(757, 186);
            this.textBox72.TabIndex = 63;
            // 
            // button52
            // 
            this.button52.Location = new System.Drawing.Point(4, 398);
            this.button52.Margin = new System.Windows.Forms.Padding(4);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(759, 34);
            this.button52.TabIndex = 61;
            this.button52.Text = "Generate";
            this.button52.UseVisualStyleBackColor = true;
            this.button52.Click += new System.EventHandler(this.button52_Click);
            // 
            // tabPage18
            // 
            this.tabPage18.Controls.Add(this.label73);
            this.tabPage18.Controls.Add(this.textBox73);
            this.tabPage18.Controls.Add(this.button51);
            this.tabPage18.Controls.Add(this.label72);
            this.tabPage18.Controls.Add(this.textBox70);
            this.tabPage18.Location = new System.Drawing.Point(4, 28);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Size = new System.Drawing.Size(1476, 790);
            this.tabPage18.TabIndex = 5;
            this.tabPage18.Text = "TRACK1 DECODE";
            this.tabPage18.UseVisualStyleBackColor = true;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(20, 212);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(116, 18);
            this.label73.TabIndex = 5;
            this.label73.Text = "Decode Track";
            // 
            // textBox73
            // 
            this.textBox73.Location = new System.Drawing.Point(22, 237);
            this.textBox73.Multiline = true;
            this.textBox73.Name = "textBox73";
            this.textBox73.ReadOnly = true;
            this.textBox73.Size = new System.Drawing.Size(943, 154);
            this.textBox73.TabIndex = 4;
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(837, 418);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(129, 27);
            this.button51.TabIndex = 2;
            this.button51.Text = "Get Track";
            this.button51.UseVisualStyleBackColor = true;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(20, 14);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(116, 18);
            this.label72.TabIndex = 1;
            this.label72.Text = "Encode Track";
            // 
            // textBox70
            // 
            this.textBox70.Location = new System.Drawing.Point(22, 39);
            this.textBox70.Multiline = true;
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(943, 160);
            this.textBox70.TabIndex = 0;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.groupBox14);
            this.tabPage7.Controls.Add(this.groupBox5);
            this.tabPage7.Controls.Add(this.label10);
            this.tabPage7.Controls.Add(this.IDC_DataKey);
            this.tabPage7.Location = new System.Drawing.Point(4, 28);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1476, 790);
            this.tabPage7.TabIndex = 10;
            this.tabPage7.Text = "DUKPT";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.IDC_Data);
            this.groupBox14.Controls.Add(this.label11);
            this.groupBox14.Controls.Add(this.IDC_DesMode);
            this.groupBox14.Controls.Add(this.IDC_Decrypt);
            this.groupBox14.Controls.Add(this.label13);
            this.groupBox14.Controls.Add(this.label12);
            this.groupBox14.Controls.Add(this.IDC_Encrypt);
            this.groupBox14.Controls.Add(this.IDC_EncDec);
            this.groupBox14.Location = new System.Drawing.Point(12, 272);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(612, 243);
            this.groupBox14.TabIndex = 20;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Encryption / Decryption";
            // 
            // IDC_Data
            // 
            this.IDC_Data.Location = new System.Drawing.Point(111, 40);
            this.IDC_Data.Name = "IDC_Data";
            this.IDC_Data.Size = new System.Drawing.Size(488, 28);
            this.IDC_Data.TabIndex = 11;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 45);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 18);
            this.label11.TabIndex = 12;
            this.label11.Text = "Data";
            // 
            // IDC_DesMode
            // 
            this.IDC_DesMode.FormattingEnabled = true;
            this.IDC_DesMode.Location = new System.Drawing.Point(354, 202);
            this.IDC_DesMode.Name = "IDC_DesMode";
            this.IDC_DesMode.Size = new System.Drawing.Size(97, 26);
            this.IDC_DesMode.TabIndex = 18;
            // 
            // IDC_Decrypt
            // 
            this.IDC_Decrypt.Location = new System.Drawing.Point(111, 148);
            this.IDC_Decrypt.Name = "IDC_Decrypt";
            this.IDC_Decrypt.Size = new System.Drawing.Size(488, 28);
            this.IDC_Decrypt.TabIndex = 13;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 96);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(98, 18);
            this.label13.TabIndex = 17;
            this.label13.Text = "Encryption";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 153);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(98, 18);
            this.label12.TabIndex = 14;
            this.label12.Text = "Decryption";
            // 
            // IDC_Encrypt
            // 
            this.IDC_Encrypt.Location = new System.Drawing.Point(111, 93);
            this.IDC_Encrypt.Name = "IDC_Encrypt";
            this.IDC_Encrypt.Size = new System.Drawing.Size(488, 28);
            this.IDC_Encrypt.TabIndex = 16;
            // 
            // IDC_EncDec
            // 
            this.IDC_EncDec.Location = new System.Drawing.Point(484, 202);
            this.IDC_EncDec.Name = "IDC_EncDec";
            this.IDC_EncDec.Size = new System.Drawing.Size(116, 27);
            this.IDC_EncDec.TabIndex = 15;
            this.IDC_EncDec.Text = "Enc/Dec";
            this.IDC_EncDec.UseVisualStyleBackColor = true;
            this.IDC_EncDec.Click += new System.EventHandler(this.IDC_EncDec_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.groupBox13);
            this.groupBox5.Controls.Add(this.IDC_BDK);
            this.groupBox5.Controls.Add(this.IDC_KSN);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.IDC_IPEK);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.IDC_Generate);
            this.groupBox5.Location = new System.Drawing.Point(12, 12);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(612, 165);
            this.groupBox5.TabIndex = 19;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "DUKPT Parameter";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.IDC_UseBDK);
            this.groupBox13.Controls.Add(this.IDC_UseIPEK);
            this.groupBox13.Location = new System.Drawing.Point(500, 21);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(102, 130);
            this.groupBox13.TabIndex = 7;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Generate Key from";
            // 
            // IDC_UseBDK
            // 
            this.IDC_UseBDK.AutoSize = true;
            this.IDC_UseBDK.Location = new System.Drawing.Point(6, 50);
            this.IDC_UseBDK.Name = "IDC_UseBDK";
            this.IDC_UseBDK.Size = new System.Drawing.Size(60, 22);
            this.IDC_UseBDK.TabIndex = 9;
            this.IDC_UseBDK.TabStop = true;
            this.IDC_UseBDK.Text = "BDK";
            this.IDC_UseBDK.UseVisualStyleBackColor = true;
            this.IDC_UseBDK.CheckedChanged += new System.EventHandler(this.IDC_UseBDK_CheckedChanged);
            // 
            // IDC_UseIPEK
            // 
            this.IDC_UseIPEK.AutoSize = true;
            this.IDC_UseIPEK.Location = new System.Drawing.Point(6, 92);
            this.IDC_UseIPEK.Name = "IDC_UseIPEK";
            this.IDC_UseIPEK.Size = new System.Drawing.Size(69, 22);
            this.IDC_UseIPEK.TabIndex = 10;
            this.IDC_UseIPEK.TabStop = true;
            this.IDC_UseIPEK.Text = "IPEK";
            this.IDC_UseIPEK.UseVisualStyleBackColor = true;
            this.IDC_UseIPEK.CheckedChanged += new System.EventHandler(this.IDC_UseIPEK_CheckedChanged);
            // 
            // IDC_BDK
            // 
            this.IDC_BDK.Location = new System.Drawing.Point(66, 74);
            this.IDC_BDK.Name = "IDC_BDK";
            this.IDC_BDK.Size = new System.Drawing.Size(426, 28);
            this.IDC_BDK.TabIndex = 4;
            // 
            // IDC_KSN
            // 
            this.IDC_KSN.Location = new System.Drawing.Point(66, 21);
            this.IDC_KSN.Name = "IDC_KSN";
            this.IDC_KSN.Size = new System.Drawing.Size(302, 28);
            this.IDC_KSN.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 26);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 18);
            this.label7.TabIndex = 2;
            this.label7.Text = "KSN";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 74);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 18);
            this.label8.TabIndex = 3;
            this.label8.Text = "BDK";
            // 
            // IDC_IPEK
            // 
            this.IDC_IPEK.Location = new System.Drawing.Point(66, 123);
            this.IDC_IPEK.Name = "IDC_IPEK";
            this.IDC_IPEK.Size = new System.Drawing.Size(426, 28);
            this.IDC_IPEK.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 123);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 18);
            this.label9.TabIndex = 6;
            this.label9.Text = "IPEK";
            // 
            // IDC_Generate
            // 
            this.IDC_Generate.Location = new System.Drawing.Point(375, 21);
            this.IDC_Generate.Name = "IDC_Generate";
            this.IDC_Generate.Size = new System.Drawing.Size(117, 34);
            this.IDC_Generate.TabIndex = 0;
            this.IDC_Generate.Text = "Generate";
            this.IDC_Generate.UseVisualStyleBackColor = true;
            this.IDC_Generate.Click += new System.EventHandler(this.IDC_Generate_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(20, 207);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(80, 18);
            this.label10.TabIndex = 8;
            this.label10.Text = "Data Key";
            // 
            // IDC_DataKey
            // 
            this.IDC_DataKey.Location = new System.Drawing.Point(123, 207);
            this.IDC_DataKey.Name = "IDC_DataKey";
            this.IDC_DataKey.Size = new System.Drawing.Size(488, 28);
            this.IDC_DataKey.TabIndex = 7;
            // 
            // tabPage23
            // 
            this.tabPage23.Controls.Add(this.textBox4);
            this.tabPage23.Controls.Add(this.label18);
            this.tabPage23.Controls.Add(this.comboBox30);
            this.tabPage23.Controls.Add(this.comboBox29);
            this.tabPage23.Controls.Add(this.listBox5);
            this.tabPage23.Controls.Add(this.button67);
            this.tabPage23.Controls.Add(this.button66);
            this.tabPage23.Controls.Add(this.textBox3);
            this.tabPage23.Location = new System.Drawing.Point(4, 28);
            this.tabPage23.Name = "tabPage23";
            this.tabPage23.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage23.Size = new System.Drawing.Size(1476, 790);
            this.tabPage23.TabIndex = 11;
            this.tabPage23.Text = "FILE-CONVERSION";
            this.tabPage23.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(988, 21);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(154, 28);
            this.textBox4.TabIndex = 8;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(885, 28);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(98, 18);
            this.label18.TabIndex = 7;
            this.label18.Text = "KeyValue :";
            // 
            // comboBox30
            // 
            this.comboBox30.FormattingEnabled = true;
            this.comboBox30.Location = new System.Drawing.Point(694, 22);
            this.comboBox30.Name = "comboBox30";
            this.comboBox30.Size = new System.Drawing.Size(182, 26);
            this.comboBox30.TabIndex = 6;
            // 
            // comboBox29
            // 
            this.comboBox29.FormattingEnabled = true;
            this.comboBox29.Location = new System.Drawing.Point(566, 22);
            this.comboBox29.Name = "comboBox29";
            this.comboBox29.Size = new System.Drawing.Size(121, 26);
            this.comboBox29.TabIndex = 5;
            // 
            // listBox5
            // 
            this.listBox5.FormattingEnabled = true;
            this.listBox5.HorizontalScrollbar = true;
            this.listBox5.ItemHeight = 18;
            this.listBox5.Location = new System.Drawing.Point(24, 63);
            this.listBox5.Name = "listBox5";
            this.listBox5.ScrollAlwaysVisible = true;
            this.listBox5.Size = new System.Drawing.Size(1118, 400);
            this.listBox5.TabIndex = 4;
            // 
            // button67
            // 
            this.button67.Location = new System.Drawing.Point(417, 21);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(142, 34);
            this.button67.TabIndex = 3;
            this.button67.Text = "Conversion";
            this.button67.UseVisualStyleBackColor = true;
            this.button67.Click += new System.EventHandler(this.button67_Click);
            // 
            // button66
            // 
            this.button66.Location = new System.Drawing.Point(274, 22);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(136, 32);
            this.button66.TabIndex = 1;
            this.button66.Text = "Select File";
            this.button66.UseVisualStyleBackColor = true;
            this.button66.Click += new System.EventHandler(this.button66_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(24, 22);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(242, 28);
            this.textBox3.TabIndex = 0;
            // 
            // tabPage24
            // 
            this.tabPage24.Controls.Add(this.comboBox32);
            this.tabPage24.Controls.Add(this.label90);
            this.tabPage24.Controls.Add(this.button60);
            this.tabPage24.Controls.Add(this.label88);
            this.tabPage24.Controls.Add(this.comboBox31);
            this.tabPage24.Controls.Add(this.label84);
            this.tabPage24.Controls.Add(this.button71);
            this.tabPage24.Controls.Add(this.button70);
            this.tabPage24.Controls.Add(this.button69);
            this.tabPage24.Controls.Add(this.button68);
            this.tabPage24.Controls.Add(this.label63);
            this.tabPage24.Controls.Add(this.label33);
            this.tabPage24.Controls.Add(this.label19);
            this.tabPage24.Controls.Add(this.textBox7);
            this.tabPage24.Controls.Add(this.textBox6);
            this.tabPage24.Controls.Add(this.textBox5);
            this.tabPage24.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabPage24.Location = new System.Drawing.Point(4, 28);
            this.tabPage24.Name = "tabPage24";
            this.tabPage24.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage24.Size = new System.Drawing.Size(1476, 790);
            this.tabPage24.TabIndex = 12;
            this.tabPage24.Text = "RSA-CONVERSION";
            this.tabPage24.UseVisualStyleBackColor = true;
            // 
            // comboBox32
            // 
            this.comboBox32.FormattingEnabled = true;
            this.comboBox32.Location = new System.Drawing.Point(246, 501);
            this.comboBox32.Name = "comboBox32";
            this.comboBox32.Size = new System.Drawing.Size(224, 41);
            this.comboBox32.TabIndex = 15;
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(32, 504);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(191, 33);
            this.label90.TabIndex = 14;
            this.label90.Text = "FILE TYPE :";
            // 
            // button60
            // 
            this.button60.Location = new System.Drawing.Point(504, 498);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(796, 46);
            this.button60.TabIndex = 13;
            this.button60.Text = "Generate Rsa Key";
            this.button60.UseVisualStyleBackColor = true;
            this.button60.Click += new System.EventHandler(this.button60_Click);
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(28, 394);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(159, 33);
            this.label88.TabIndex = 12;
            this.label88.Text = "RSA Key :";
            // 
            // comboBox31
            // 
            this.comboBox31.FormattingEnabled = true;
            this.comboBox31.Location = new System.Drawing.Point(198, 390);
            this.comboBox31.Name = "comboBox31";
            this.comboBox31.Size = new System.Drawing.Size(1100, 41);
            this.comboBox31.TabIndex = 11;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(28, 450);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(335, 33);
            this.label84.TabIndex = 10;
            this.label84.Text = "RSA Type Conversion:";
            // 
            // button71
            // 
            this.button71.Location = new System.Drawing.Point(1136, 440);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(165, 50);
            this.button71.TabIndex = 9;
            this.button71.Text = "HEX-PEM";
            this.button71.UseVisualStyleBackColor = true;
            this.button71.Visible = false;
            this.button71.Click += new System.EventHandler(this.button71_Click);
            // 
            // button70
            // 
            this.button70.Location = new System.Drawing.Point(676, 441);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(164, 50);
            this.button70.TabIndex = 8;
            this.button70.Text = "PEM-XML";
            this.button70.UseVisualStyleBackColor = true;
            this.button70.Click += new System.EventHandler(this.button70_Click);
            // 
            // button69
            // 
            this.button69.Location = new System.Drawing.Point(900, 441);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(178, 50);
            this.button69.TabIndex = 7;
            this.button69.Text = "PEM-HEX";
            this.button69.UseVisualStyleBackColor = true;
            this.button69.Click += new System.EventHandler(this.button69_Click);
            // 
            // button68
            // 
            this.button68.Location = new System.Drawing.Point(429, 441);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(186, 50);
            this.button68.TabIndex = 6;
            this.button68.Text = "XML-PEM";
            this.button68.UseVisualStyleBackColor = true;
            this.button68.Click += new System.EventHandler(this.button68_Click);
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.BackColor = System.Drawing.Color.DarkGray;
            this.label63.Location = new System.Drawing.Point(1010, 14);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(175, 33);
            this.label63.TabIndex = 5;
            this.label63.Text = "Type : HEX";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.DarkGray;
            this.label33.Location = new System.Drawing.Point(594, 14);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(175, 33);
            this.label33.TabIndex = 4;
            this.label33.Text = "Type : PEM";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.DarkGray;
            this.label19.CausesValidation = false;
            this.label19.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label19.Location = new System.Drawing.Point(136, 12);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(175, 33);
            this.label19.TabIndex = 3;
            this.label19.Text = "Type : XML";
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox7.Location = new System.Drawing.Point(900, 62);
            this.textBox7.Multiline = true;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(398, 307);
            this.textBox7.TabIndex = 2;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox6.Location = new System.Drawing.Point(468, 64);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(398, 304);
            this.textBox6.TabIndex = 1;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox5.Location = new System.Drawing.Point(32, 64);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(408, 304);
            this.textBox5.TabIndex = 0;
            // 
            // tabPage21
            // 
            this.tabPage21.Controls.Add(this.button65);
            this.tabPage21.Controls.Add(this.button64);
            this.tabPage21.Controls.Add(this.button63);
            this.tabPage21.Controls.Add(this.textBox11);
            this.tabPage21.Controls.Add(this.label89);
            this.tabPage21.Controls.Add(this.label87);
            this.tabPage21.Controls.Add(this.textBox10);
            this.tabPage21.Controls.Add(this.button62);
            this.tabPage21.Controls.Add(this.button61);
            this.tabPage21.Controls.Add(this.textBox9);
            this.tabPage21.Controls.Add(this.textBox8);
            this.tabPage21.Controls.Add(this.label86);
            this.tabPage21.Controls.Add(this.label85);
            this.tabPage21.Location = new System.Drawing.Point(4, 28);
            this.tabPage21.Name = "tabPage21";
            this.tabPage21.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage21.Size = new System.Drawing.Size(1476, 790);
            this.tabPage21.TabIndex = 13;
            this.tabPage21.Text = "RSA-CALCULATION";
            this.tabPage21.UseVisualStyleBackColor = true;
            // 
            // button65
            // 
            this.button65.Location = new System.Drawing.Point(543, 458);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(240, 54);
            this.button65.TabIndex = 12;
            this.button65.Text = "Generate";
            this.button65.UseVisualStyleBackColor = true;
            this.button65.Click += new System.EventHandler(this.button65_Click_1);
            // 
            // button64
            // 
            this.button64.Location = new System.Drawing.Point(286, 458);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(250, 54);
            this.button64.TabIndex = 11;
            this.button64.Text = "Decryption";
            this.button64.UseVisualStyleBackColor = true;
            this.button64.Click += new System.EventHandler(this.button64_Click_1);
            // 
            // button63
            // 
            this.button63.Location = new System.Drawing.Point(14, 458);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(267, 54);
            this.button63.TabIndex = 10;
            this.button63.Text = "Encrypt";
            this.button63.UseVisualStyleBackColor = true;
            this.button63.Click += new System.EventHandler(this.button63_Click);
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(208, 280);
            this.textBox11.Multiline = true;
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(570, 164);
            this.textBox11.TabIndex = 9;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.BackColor = System.Drawing.Color.DarkGray;
            this.label89.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label89.Location = new System.Drawing.Point(20, 280);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(98, 21);
            this.label89.TabIndex = 8;
            this.label89.Text = "Result :";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.BackColor = System.Drawing.Color.DarkGray;
            this.label87.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label87.Location = new System.Drawing.Point(20, 135);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(142, 21);
            this.label87.TabIndex = 7;
            this.label87.Text = "Plain Data :";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(208, 132);
            this.textBox10.Multiline = true;
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(570, 134);
            this.textBox10.TabIndex = 6;
            // 
            // button62
            // 
            this.button62.Location = new System.Drawing.Point(644, 82);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(135, 34);
            this.button62.TabIndex = 5;
            this.button62.Text = "Select File";
            this.button62.UseVisualStyleBackColor = true;
            this.button62.Click += new System.EventHandler(this.button62_Click);
            // 
            // button61
            // 
            this.button61.Location = new System.Drawing.Point(644, 26);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(135, 38);
            this.button61.TabIndex = 4;
            this.button61.Text = "Select File";
            this.button61.UseVisualStyleBackColor = true;
            this.button61.Click += new System.EventHandler(this.button61_Click);
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(208, 84);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(376, 28);
            this.textBox9.TabIndex = 3;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(208, 32);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(376, 28);
            this.textBox8.TabIndex = 2;
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.BackColor = System.Drawing.Color.DarkGray;
            this.label86.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label86.Location = new System.Drawing.Point(18, 82);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(153, 21);
            this.label86.TabIndex = 1;
            this.label86.Text = "Private Key :";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.BackColor = System.Drawing.Color.DarkGray;
            this.label85.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label85.Location = new System.Drawing.Point(18, 32);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(142, 21);
            this.label85.TabIndex = 0;
            this.label85.Text = "Public Key :";
            // 
            // tabPage25
            // 
            this.tabPage25.Controls.Add(this.button75);
            this.tabPage25.Controls.Add(this.textBox21);
            this.tabPage25.Controls.Add(this.textBox13);
            this.tabPage25.Controls.Add(this.button74);
            this.tabPage25.Controls.Add(this.button73);
            this.tabPage25.Controls.Add(this.button72);
            this.tabPage25.Controls.Add(this.textBox12);
            this.tabPage25.Location = new System.Drawing.Point(4, 28);
            this.tabPage25.Name = "tabPage25";
            this.tabPage25.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage25.Size = new System.Drawing.Size(1476, 790);
            this.tabPage25.TabIndex = 14;
            this.tabPage25.Text = "ASC-TXT";
            this.tabPage25.UseVisualStyleBackColor = true;
            // 
            // button75
            // 
            this.button75.Location = new System.Drawing.Point(508, 156);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(141, 27);
            this.button75.TabIndex = 6;
            this.button75.Text = "Select File";
            this.button75.UseVisualStyleBackColor = true;
            this.button75.Click += new System.EventHandler(this.button75_Click);
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(99, 154);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(364, 28);
            this.textBox21.TabIndex = 5;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(99, 236);
            this.textBox13.Multiline = true;
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(586, 199);
            this.textBox13.TabIndex = 4;
            // 
            // button74
            // 
            this.button74.Location = new System.Drawing.Point(699, 152);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(141, 28);
            this.button74.TabIndex = 3;
            this.button74.Text = "Generate";
            this.button74.UseVisualStyleBackColor = true;
            this.button74.Click += new System.EventHandler(this.button74_Click);
            // 
            // button73
            // 
            this.button73.Location = new System.Drawing.Point(699, 64);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(141, 28);
            this.button73.TabIndex = 2;
            this.button73.Text = "Asc-Txt";
            this.button73.UseVisualStyleBackColor = true;
            this.button73.Click += new System.EventHandler(this.button73_Click);
            // 
            // button72
            // 
            this.button72.Location = new System.Drawing.Point(500, 64);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(152, 28);
            this.button72.TabIndex = 1;
            this.button72.Text = "Select File";
            this.button72.UseVisualStyleBackColor = true;
            this.button72.Click += new System.EventHandler(this.button72_Click);
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(99, 64);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(364, 28);
            this.textBox12.TabIndex = 0;
            // 
            // tabPage26
            // 
            this.tabPage26.Controls.Add(this.groupBox17);
            this.tabPage26.Controls.Add(this.groupBox16);
            this.tabPage26.Location = new System.Drawing.Point(4, 28);
            this.tabPage26.Name = "tabPage26";
            this.tabPage26.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage26.Size = new System.Drawing.Size(1476, 790);
            this.tabPage26.TabIndex = 15;
            this.tabPage26.Text = "FILE-CONVERSION";
            this.tabPage26.UseVisualStyleBackColor = true;
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.label98);
            this.groupBox17.Controls.Add(this.button81);
            this.groupBox17.Controls.Add(this.textBox87);
            this.groupBox17.Location = new System.Drawing.Point(6, 176);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(548, 350);
            this.groupBox17.TabIndex = 3;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Hex-bin";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(6, 321);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(26, 18);
            this.label98.TabIndex = 4;
            this.label98.Text = "NA";
            // 
            // button81
            // 
            this.button81.Location = new System.Drawing.Point(6, 267);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(512, 38);
            this.button81.TabIndex = 1;
            this.button81.Text = "Conversion";
            this.button81.UseVisualStyleBackColor = true;
            this.button81.Click += new System.EventHandler(this.button81_Click);
            // 
            // textBox87
            // 
            this.textBox87.Location = new System.Drawing.Point(6, 30);
            this.textBox87.Multiline = true;
            this.textBox87.Name = "textBox87";
            this.textBox87.Size = new System.Drawing.Size(510, 222);
            this.textBox87.TabIndex = 0;
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.label97);
            this.groupBox16.Controls.Add(this.button79);
            this.groupBox16.Controls.Add(this.textBox82);
            this.groupBox16.Controls.Add(this.button76);
            this.groupBox16.Location = new System.Drawing.Point(6, 12);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(548, 166);
            this.groupBox16.TabIndex = 2;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Const-bin";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(458, 40);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(26, 18);
            this.label97.TabIndex = 3;
            this.label97.Text = "NA";
            // 
            // button79
            // 
            this.button79.Location = new System.Drawing.Point(224, 92);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(146, 34);
            this.button79.TabIndex = 2;
            this.button79.Text = "Conversion";
            this.button79.UseVisualStyleBackColor = true;
            this.button79.Click += new System.EventHandler(this.button79_Click);
            // 
            // textBox82
            // 
            this.textBox82.Location = new System.Drawing.Point(6, 38);
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(414, 28);
            this.textBox82.TabIndex = 0;
            // 
            // button76
            // 
            this.button76.Location = new System.Drawing.Point(27, 92);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(148, 34);
            this.button76.TabIndex = 1;
            this.button76.Text = "Select File";
            this.button76.UseVisualStyleBackColor = true;
            this.button76.Click += new System.EventHandler(this.button76_Click);
            // 
            // tabPage19
            // 
            this.tabPage19.Controls.Add(this.textBox89);
            this.tabPage19.Controls.Add(this.label99);
            this.tabPage19.Controls.Add(this.label17);
            this.tabPage19.Controls.Add(this.button59);
            this.tabPage19.Controls.Add(this.button54);
            this.tabPage19.Controls.Add(this.label81);
            this.tabPage19.Controls.Add(this.textBox80);
            this.tabPage19.Controls.Add(this.textBox79);
            this.tabPage19.Controls.Add(this.textBox78);
            this.tabPage19.Controls.Add(this.textBox77);
            this.tabPage19.Controls.Add(this.textBox76);
            this.tabPage19.Controls.Add(this.textBox75);
            this.tabPage19.Controls.Add(this.textBox61);
            this.tabPage19.Controls.Add(this.textBox60);
            this.tabPage19.Controls.Add(this.label80);
            this.tabPage19.Controls.Add(this.label79);
            this.tabPage19.Controls.Add(this.label78);
            this.tabPage19.Controls.Add(this.label77);
            this.tabPage19.Controls.Add(this.label76);
            this.tabPage19.Controls.Add(this.label65);
            this.tabPage19.Controls.Add(this.label64);
            this.tabPage19.Location = new System.Drawing.Point(4, 28);
            this.tabPage19.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage19.Name = "tabPage19";
            this.tabPage19.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage19.Size = new System.Drawing.Size(1372, 604);
            this.tabPage19.TabIndex = 7;
            this.tabPage19.Text = "SELF-REPAIR";
            this.tabPage19.UseVisualStyleBackColor = true;
            // 
            // textBox89
            // 
            this.textBox89.Location = new System.Drawing.Point(152, 534);
            this.textBox89.Name = "textBox89";
            this.textBox89.Size = new System.Drawing.Size(502, 28);
            this.textBox89.TabIndex = 77;
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(4, 534);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(116, 18);
            this.label99.TabIndex = 76;
            this.label99.Text = "ENCRYPT MODE";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(664, 456);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(26, 18);
            this.label17.TabIndex = 75;
            this.label17.Text = "NA";
            // 
            // button59
            // 
            this.button59.Location = new System.Drawing.Point(664, 345);
            this.button59.Margin = new System.Windows.Forms.Padding(4);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(644, 34);
            this.button59.TabIndex = 74;
            this.button59.Text = "MANAGE PUBLIC KEY REPAIR";
            this.button59.UseVisualStyleBackColor = true;
            this.button59.Click += new System.EventHandler(this.button59_Click);
            // 
            // button54
            // 
            this.button54.Location = new System.Drawing.Point(664, 388);
            this.button54.Margin = new System.Windows.Forms.Padding(4);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(644, 34);
            this.button54.TabIndex = 13;
            this.button54.Text = "COMPLETE REPAIR";
            this.button54.UseVisualStyleBackColor = true;
            this.button54.Click += new System.EventHandler(this.button54_Click_1);
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(9, 141);
            this.label81.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(35, 18);
            this.label81.TabIndex = 72;
            this.label81.Text = "TMK";
            // 
            // textBox80
            // 
            this.textBox80.Location = new System.Drawing.Point(152, 130);
            this.textBox80.Margin = new System.Windows.Forms.Padding(4);
            this.textBox80.MaxLength = 1024;
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new System.Drawing.Size(502, 28);
            this.textBox80.TabIndex = 73;
            // 
            // textBox79
            // 
            this.textBox79.Location = new System.Drawing.Point(808, 176);
            this.textBox79.Margin = new System.Windows.Forms.Padding(4);
            this.textBox79.MaxLength = 1024;
            this.textBox79.Multiline = true;
            this.textBox79.Name = "textBox79";
            this.textBox79.Size = new System.Drawing.Size(498, 156);
            this.textBox79.TabIndex = 71;
            // 
            // textBox78
            // 
            this.textBox78.Location = new System.Drawing.Point(808, 9);
            this.textBox78.Margin = new System.Windows.Forms.Padding(4);
            this.textBox78.MaxLength = 1024;
            this.textBox78.Multiline = true;
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(498, 156);
            this.textBox78.TabIndex = 69;
            // 
            // textBox77
            // 
            this.textBox77.Location = new System.Drawing.Point(152, 342);
            this.textBox77.Margin = new System.Windows.Forms.Padding(4);
            this.textBox77.MaxLength = 1024;
            this.textBox77.Multiline = true;
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(502, 156);
            this.textBox77.TabIndex = 67;
            // 
            // textBox76
            // 
            this.textBox76.Location = new System.Drawing.Point(152, 176);
            this.textBox76.Margin = new System.Windows.Forms.Padding(4);
            this.textBox76.MaxLength = 1024;
            this.textBox76.Multiline = true;
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(502, 156);
            this.textBox76.TabIndex = 62;
            // 
            // textBox75
            // 
            this.textBox75.Location = new System.Drawing.Point(152, 87);
            this.textBox75.Margin = new System.Windows.Forms.Padding(4);
            this.textBox75.MaxLength = 1024;
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(502, 28);
            this.textBox75.TabIndex = 60;
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(152, 46);
            this.textBox61.Margin = new System.Windows.Forms.Padding(4);
            this.textBox61.MaxLength = 1024;
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(502, 28);
            this.textBox61.TabIndex = 58;
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(152, 3);
            this.textBox60.Margin = new System.Windows.Forms.Padding(4);
            this.textBox60.MaxLength = 1024;
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(502, 28);
            this.textBox60.TabIndex = 56;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(662, 178);
            this.label80.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(134, 18);
            this.label80.TabIndex = 70;
            this.label80.Text = "MANAGE PUB KEY";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(662, 12);
            this.label79.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(134, 18);
            this.label79.TabIndex = 68;
            this.label79.Text = "CONFIG PUB KEY";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(4, 345);
            this.label78.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(143, 18);
            this.label78.TabIndex = 63;
            this.label78.Text = "POS PRIVATE KEY";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(9, 186);
            this.label77.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(134, 18);
            this.label77.TabIndex = 61;
            this.label77.Text = "POS PUBLIC KEY";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(9, 98);
            this.label76.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(107, 18);
            this.label76.TabIndex = 59;
            this.label76.Text = "BT MAC ADDR";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(9, 57);
            this.label65.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(116, 18);
            this.label65.TabIndex = 57;
            this.label65.Text = "BT NAME HEAD";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(9, 14);
            this.label64.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(62, 18);
            this.label64.TabIndex = 13;
            this.label64.Text = "POS ID";
            // 
            // tabPage22
            // 
            this.tabPage22.Controls.Add(this.label16);
            this.tabPage22.Controls.Add(this.button58);
            this.tabPage22.Controls.Add(this.button2);
            this.tabPage22.Controls.Add(this.label15);
            this.tabPage22.Controls.Add(this.label14);
            this.tabPage22.Controls.Add(this.textBox1);
            this.tabPage22.Controls.Add(this.textBox2);
            this.tabPage22.Location = new System.Drawing.Point(4, 28);
            this.tabPage22.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage22.Name = "tabPage22";
            this.tabPage22.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage22.Size = new System.Drawing.Size(1372, 604);
            this.tabPage22.TabIndex = 8;
            this.tabPage22.Text = "BT-REPAIR";
            this.tabPage22.UseVisualStyleBackColor = true;
            this.tabPage22.Click += new System.EventHandler(this.tabPage22_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(9, 162);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(26, 18);
            this.label16.TabIndex = 65;
            this.label16.Text = "NA";
            // 
            // button58
            // 
            this.button58.Location = new System.Drawing.Point(392, 93);
            this.button58.Margin = new System.Windows.Forms.Padding(4);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(242, 34);
            this.button58.TabIndex = 64;
            this.button58.Text = "DOWN LOAD";
            this.button58.UseVisualStyleBackColor = true;
            this.button58.Click += new System.EventHandler(this.button58_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(88, 93);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(242, 34);
            this.button2.TabIndex = 63;
            this.button2.Text = "UP LOAD";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(9, 52);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 18);
            this.label15.TabIndex = 62;
            this.label15.Text = "BT ADDR";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(9, 18);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(71, 18);
            this.label14.TabIndex = 61;
            this.label14.Text = "BT NAME";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(88, 52);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.MaxLength = 12;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(542, 28);
            this.textBox1.TabIndex = 60;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(88, 9);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.MaxLength = 16;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(542, 28);
            this.textBox2.TabIndex = 59;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(18, 334);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(182, 34);
            this.button12.TabIndex = 16;
            this.button12.Text = "ResetPosStatus";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(9, 462);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(26, 18);
            this.label104.TabIndex = 84;
            this.label104.Text = "NA";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(18, 324);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(26, 18);
            this.label105.TabIndex = 69;
            this.label105.Text = "NA";
            // 
            // FormDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1605, 693);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormDemo";
            this.Text = "QPOS TOOL 1.0";
            this.Load += new System.EventHandler(this.FormDemo_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.TRADE.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage11.ResumeLayout(false);
            this.tabPage11.PerformLayout();
            this.tabPage12.ResumeLayout(false);
            this.tabPage12.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.tabPage20.ResumeLayout(false);
            this.tabPage20.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage8.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tabPage10.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.tabPage13.ResumeLayout(false);
            this.tabPage13.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.tabPage27.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.tabPage28.ResumeLayout(false);
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.tabPage17.ResumeLayout(false);
            this.tabPage17.PerformLayout();
            this.tabPage14.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage15.ResumeLayout(false);
            this.tabPage15.PerformLayout();
            this.tabPage16.ResumeLayout(false);
            this.tabPage16.PerformLayout();
            this.tabPage18.ResumeLayout(false);
            this.tabPage18.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.tabPage23.ResumeLayout(false);
            this.tabPage23.PerformLayout();
            this.tabPage24.ResumeLayout(false);
            this.tabPage24.PerformLayout();
            this.tabPage21.ResumeLayout(false);
            this.tabPage21.PerformLayout();
            this.tabPage25.ResumeLayout(false);
            this.tabPage25.PerformLayout();
            this.tabPage26.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.tabPage19.ResumeLayout(false);
            this.tabPage19.PerformLayout();
            this.tabPage22.ResumeLayout(false);
            this.tabPage22.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl TRADE;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.ComboBox comboBox28;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.ComboBox comboBox13;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.ComboBox comboBox17;
        private System.Windows.Forms.ComboBox comboBox16;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.ComboBox comboBox20;
        private System.Windows.Forms.ComboBox comboBox19;
        private System.Windows.Forms.ComboBox comboBox18;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TabPage tabPage20;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.ComboBox comboBox27;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.TextBox textBox81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.ComboBox comboBox15;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.ComboBox comboBox14;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.ComboBox comboBox26;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.ComboBox comboBox25;
        private System.Windows.Forms.ComboBox comboBox23;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.ComboBox comboBox24;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.ComboBox comboBox21;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TabPage tabPage17;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.ComboBox comboBox22;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.TabPage tabPage18;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.TextBox IDC_Data;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox IDC_DesMode;
        private System.Windows.Forms.TextBox IDC_Decrypt;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox IDC_Encrypt;
        private System.Windows.Forms.Button IDC_EncDec;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.RadioButton IDC_UseBDK;
        private System.Windows.Forms.RadioButton IDC_UseIPEK;
        private System.Windows.Forms.TextBox IDC_BDK;
        private System.Windows.Forms.TextBox IDC_KSN;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox IDC_IPEK;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button IDC_Generate;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox IDC_DataKey;
        private System.Windows.Forms.TabPage tabPage23;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox comboBox30;
        private System.Windows.Forms.ComboBox comboBox29;
        private System.Windows.Forms.ListBox listBox5;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TabPage tabPage24;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.ComboBox comboBox31;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TabPage tabPage19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.TextBox textBox80;
        private System.Windows.Forms.TextBox textBox79;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.TextBox textBox77;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TabPage tabPage22;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TabPage tabPage21;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.ComboBox comboBox32;
        private System.Windows.Forms.TabPage tabPage25;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TabPage tabPage26;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.TextBox textBox82;
        private System.Windows.Forms.TextBox textBox83;
        private System.Windows.Forms.TabPage tabPage27;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.TextBox textBox84;
        private System.Windows.Forms.TextBox textBox85;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.ComboBox comboBox33;
        private System.Windows.Forms.TextBox textBox86;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.TextBox textBox88;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.TextBox textBox87;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.TextBox textBox89;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.TabPage tabPage28;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.TextBox textBox91;
        private System.Windows.Forms.TextBox textBox90;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.ComboBox comboBox34;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
    }
}

